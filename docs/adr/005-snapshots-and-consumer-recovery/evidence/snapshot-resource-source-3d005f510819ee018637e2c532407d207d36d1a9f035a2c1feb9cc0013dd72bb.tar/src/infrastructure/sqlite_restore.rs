use super::sqlite::{
    inspect_existing_format, inspect_restore_format, validate_lifecycle_counters, Ownership,
};
use crate::{
    application::{
        MappingPage, RestoreBackend, RestoreConfig, RestoreError, RestoreManager, RestoreReceipt,
        RestoreRequest, RestoreResult,
    },
    domain::*,
};
use async_trait::async_trait;
use rusqlite::{params, Connection, OpenFlags, OptionalExtension, TransactionBehavior};
use sha2::{Digest, Sha256};
use std::{
    fs::{File, OpenOptions},
    io::Read,
    path::{Component, Path, PathBuf},
    sync::{
        atomic::{AtomicU8, Ordering},
        Arc,
    },
};

pub type SqliteRestoreManager = RestoreManager<SqliteRestoreBackend>;

#[derive(Clone, Debug)]
pub struct SqliteRestoreBackend {
    root: PathBuf,
    failure: Arc<AtomicU8>,
    #[cfg(feature = "test-support")]
    pause_marker: Option<Arc<PathBuf>>,
    #[cfg(feature = "test-support")]
    observer: Option<Arc<dyn SqliteRestoreObserver>>,
}

#[doc(hidden)]
#[cfg(feature = "test-support")]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SqliteRestoreStage {
    SourceValidated,
    OwnerReserved,
    StagingCreated,
    IdentityMappingsImported,
    LifetimesImported,
    RecordPageCommitted,
    RecordsImported,
    NamesImported,
    ReceiptsImported,
    RelationalValidationCompleted,
    StagingCompleted,
    StagingSynced,
    DestinationPublished,
}

#[doc(hidden)]
#[cfg(feature = "test-support")]
pub trait SqliteRestoreObserver: std::fmt::Debug + Send + Sync + 'static {
    fn observe(&self, stage: SqliteRestoreStage);
}

#[doc(hidden)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SqliteRestoreFailureInjection {
    AfterOwnerReservation,
    AfterStagingFileReservation,
    AfterStagingCompletion,
    AfterDestinationLink,
    AfterPublishedMarker,
    #[cfg(feature = "test-support")]
    DuringCleanupUnlink,
    #[cfg(feature = "test-support")]
    DuringCleanupDirectorySync,
}

impl SqliteRestoreBackend {
    pub fn new(root: impl AsRef<Path>) -> RestoreResult<Self> {
        let root = root
            .as_ref()
            .canonicalize()
            .map_err(|error| RestoreError::InvalidConfig(format!("restore root: {error}")))?;
        let metadata = std::fs::symlink_metadata(&root)
            .map_err(|error| RestoreError::InvalidConfig(format!("restore root: {error}")))?;
        if !metadata.is_dir() || metadata.file_type().is_symlink() {
            return Err(RestoreError::InvalidConfig(
                "restore root must be a real directory".into(),
            ));
        }
        Ok(Self {
            root,
            failure: Arc::new(AtomicU8::new(0)),
            #[cfg(feature = "test-support")]
            pause_marker: None,
            #[cfg(feature = "test-support")]
            observer: None,
        })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    #[doc(hidden)]
    pub fn with_failure_injection(self, failure: SqliteRestoreFailureInjection) -> Self {
        self.failure.store(failure as u8 + 1, Ordering::Release);
        self
    }

    #[doc(hidden)]
    #[cfg(feature = "test-support")]
    pub fn with_pause_injection(
        mut self,
        boundary: SqliteRestoreFailureInjection,
        marker: impl Into<PathBuf>,
    ) -> Self {
        self.failure.store(boundary as u8 + 1, Ordering::Release);
        self.pause_marker = Some(Arc::new(marker.into()));
        self
    }

    #[doc(hidden)]
    #[cfg(feature = "test-support")]
    pub fn with_observer(mut self, observer: Arc<dyn SqliteRestoreObserver>) -> Self {
        self.observer = Some(observer);
        self
    }
}

#[async_trait]
impl RestoreBackend for SqliteRestoreBackend {
    async fn inspect_backup(
        &self,
        source: PathBuf,
        config: RestoreConfig,
    ) -> RestoreResult<BackupIdentity> {
        #[cfg(feature = "test-support")]
        let observer = self.observer.clone();
        tokio::task::spawn_blocking(move || {
            let identity = inspect_backup_blocking(&source, &config)?;
            #[cfg(feature = "test-support")]
            observe(observer.as_deref(), SqliteRestoreStage::SourceValidated);
            Ok(identity)
        })
        .await
        .map_err(|_| RestoreError::StorageFailure("backup inspection worker panicked".into()))?
    }

    async fn restore(
        &self,
        request: RestoreRequest,
        config: RestoreConfig,
    ) -> RestoreResult<RestoreReceipt> {
        let root = self.root.clone();
        let failure = self.failure.clone();
        #[cfg(feature = "test-support")]
        let pause_marker = self.pause_marker.clone();
        #[cfg(feature = "test-support")]
        let observer = self.observer.clone();
        #[cfg(not(feature = "test-support"))]
        let pause_marker: Option<Arc<PathBuf>> = None;
        let panic_request = request.clone();
        tokio::task::spawn_blocking(move || {
            restore_blocking(
                &root,
                &request,
                &config,
                &failure,
                pause_marker.as_deref().map(PathBuf::as_path),
                #[cfg(feature = "test-support")]
                observer.as_deref(),
            )
        })
        .await
        .map_err(|_| RestoreError::PublicationUnknown {
            operation_id: panic_request.operation_id,
            destination: Box::new(panic_request.destination),
        })?
    }

    async fn read_mapping(
        &self,
        receipt: RestoreReceipt,
        after: Option<StreamKey>,
        limits: PageLimits,
        config: RestoreConfig,
    ) -> RestoreResult<MappingPage> {
        let root = self.root.clone();
        tokio::task::spawn_blocking(move || {
            read_mapping_blocking(&root, &receipt, after.as_ref(), limits, &config)
        })
        .await
        .map_err(|_| RestoreError::StorageFailure("mapping reader worker panicked".into()))?
    }

    async fn cleanup_staging(
        &self,
        request: RestoreRequest,
        config: RestoreConfig,
    ) -> RestoreResult<()> {
        let root = self.root.clone();
        let failure = self.failure.clone();
        tokio::task::spawn_blocking(move || {
            cleanup_staging_blocking(&root, &request, &config, &failure)
        })
        .await
        .map_err(|_| RestoreError::StorageFailure("staging cleanup worker panicked".into()))?
    }
}

fn map_store_error(error: crate::application::Error) -> RestoreError {
    match error {
        crate::application::Error::StoreInUse => RestoreError::OwnershipConflict,
        crate::application::Error::UnsupportedFormat(version) => {
            RestoreError::UnsupportedBackup(version)
        }
        crate::application::Error::StoreCorrupt(message) => RestoreError::CorruptBackup(message),
        other => RestoreError::StorageFailure(other.to_string()),
    }
}

fn inspect_backup_blocking(source: &Path, config: &RestoreConfig) -> RestoreResult<BackupIdentity> {
    let ownership = Ownership::acquire(source).map_err(map_store_error)?;
    let (_connection, identity) = open_locked_source(ownership.path(), config)?;
    Ok(identity)
}

fn open_locked_source(
    source: &Path,
    config: &RestoreConfig,
) -> RestoreResult<(Connection, BackupIdentity)> {
    reject_recovery_sidecars(source)?;
    let metadata = std::fs::metadata(source)
        .map_err(|error| RestoreError::StorageFailure(format!("inspect backup: {error}")))?;
    if !metadata.is_file() || metadata.len() > config.max_source_bytes {
        return Err(RestoreError::CapacityExceeded);
    }
    let conn = Connection::open_with_flags(
        source,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::CorruptBackup(format!("open backup read-only: {error}")))?;
    let cache_kib = config.copy_buffer_bytes.div_ceil(1024).clamp(1, 16 * 1024);
    conn.pragma_update(None, "query_only", true)
        .map_err(|error| RestoreError::CorruptBackup(format!("make backup query-only: {error}")))?;
    conn.pragma_update(
        None,
        "cache_size",
        -i64::try_from(cache_kib).map_err(|_| RestoreError::CapacityExceeded)?,
    )
    .map_err(|error| RestoreError::CorruptBackup(format!("bound backup cache: {error}")))?;
    conn.pragma_update(None, "temp_store", "FILE")
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("bound backup temp memory: {error}"))
        })?;
    conn.execute_batch("BEGIN;")
        .map_err(|error| RestoreError::CorruptBackup(format!("begin backup snapshot: {error}")))?;
    conn.query_row("SELECT count(*) FROM sqlite_schema", [], |row| {
        row.get::<_, u64>(0)
    })
    .map_err(|error| RestoreError::CorruptBackup(format!("establish backup snapshot: {error}")))?;
    let identity = hash_file(source, config.copy_buffer_bytes, config.max_source_bytes)?;
    match inspect_existing_format(&conn).map_err(map_store_error)? {
        Some(2) => {}
        Some(version) => return Err(RestoreError::UnsupportedBackup(version)),
        None => {
            return Err(RestoreError::CorruptBackup(
                "backup has no storage format".into(),
            ))
        }
    }
    validate_lifecycle_counters(&conn).map_err(map_store_error)?;
    let journal: String = conn
        .pragma_query_value(None, "journal_mode", |row| row.get(0))
        .map_err(|error| RestoreError::CorruptBackup(format!("read journal mode: {error}")))?;
    if !journal.eq_ignore_ascii_case("delete") {
        return Err(RestoreError::CorruptBackup(
            "backup must use DELETE journal mode".into(),
        ));
    }
    let quick: String = conn
        .query_row("PRAGMA quick_check", [], |row| row.get(0))
        .map_err(|error| RestoreError::CorruptBackup(format!("SQLite quick_check: {error}")))?;
    if quick != "ok" {
        return Err(RestoreError::CorruptBackup(format!(
            "SQLite quick_check failed: {quick}"
        )));
    }
    let foreign_violation: bool = conn
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
            [],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("foreign-key check: {error}")))?;
    if foreign_violation {
        return Err(RestoreError::CorruptBackup(
            "backup contains a foreign-key violation".into(),
        ));
    }
    let orphan_record: bool = conn
        .query_row(
            "SELECT EXISTS(
               SELECT 1 FROM event_records AS r
               WHERE NOT EXISTS(
                 SELECT 1 FROM event_streams AS s WHERE s.stream_key=r.stream_key
               )
               LIMIT 1
             )",
            [],
            |row| row.get(0),
        )
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("check record stream ownership: {error}"))
        })?;
    if orphan_record {
        return Err(RestoreError::CorruptBackup(
            "backup contains a record without a stream lifetime".into(),
        ));
    }
    Ok((conn, identity))
}

fn reject_recovery_sidecars(source: &Path) -> RestoreResult<()> {
    for suffix in ["-wal", "-journal"] {
        let mut sidecar = source.as_os_str().to_os_string();
        sidecar.push(suffix);
        let path = PathBuf::from(sidecar);
        match std::fs::metadata(&path) {
            Ok(metadata) if metadata.len() > 0 => {
                return Err(RestoreError::CorruptBackup(format!(
                    "backup has a nonempty recovery sidecar: {}",
                    path.display()
                )))
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(RestoreError::StorageFailure(format!(
                    "inspect recovery sidecar: {error}"
                )))
            }
        }
    }
    Ok(())
}

fn hash_file(path: &Path, buffer_bytes: usize, max_bytes: u64) -> RestoreResult<BackupIdentity> {
    let mut file = File::open(path).map_err(|error| {
        RestoreError::StorageFailure(format!("open backup for hashing: {error}"))
    })?;
    let mut buffer = vec![0; buffer_bytes];
    let mut total = 0_u64;
    let mut hash = Sha256::new();
    loop {
        let read = file
            .read(&mut buffer)
            .map_err(|error| RestoreError::StorageFailure(format!("hash backup: {error}")))?;
        if read == 0 {
            break;
        }
        total = total
            .checked_add(read as u64)
            .filter(|total| *total <= max_bytes)
            .ok_or(RestoreError::CapacityExceeded)?;
        hash.update(&buffer[..read]);
    }
    Ok(BackupIdentity(hash.finalize().into()))
}

fn resolve_destination(root: &Path, relative: &Path) -> RestoreResult<PathBuf> {
    if relative.is_absolute()
        || relative.components().any(|component| {
            matches!(
                component,
                Component::ParentDir | Component::RootDir | Component::Prefix(_)
            )
        })
    {
        return Err(RestoreError::InvalidConfig(
            "destination must remain inside the restore root".into(),
        ));
    }
    let name = relative
        .file_name()
        .ok_or_else(|| RestoreError::InvalidConfig("destination needs a file name".into()))?;
    let parent = root.join(relative).parent().unwrap_or(root).to_path_buf();
    let parent = parent.canonicalize().map_err(|error| {
        RestoreError::InvalidConfig(format!("destination parent is unavailable: {error}"))
    })?;
    if !parent.starts_with(root) {
        return Err(RestoreError::InvalidConfig(
            "destination parent escapes the restore root".into(),
        ));
    }
    Ok(parent.join(name))
}

fn staging_path(destination: &Path, request: &RestoreRequest) -> RestoreResult<PathBuf> {
    destination
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| RestoreError::InvalidConfig("destination name must be UTF-8".into()))?;
    let operation = operation_hash(destination, &request.operation_id);
    let request_hash = request_hash(destination, request);
    Ok(destination.with_file_name(format!(
        ".event-stream-restore-{operation}-{request_hash}.sqlite3"
    )))
}

fn request_hash(destination: &Path, request: &RestoreRequest) -> String {
    let mut request_hash = Sha256::new();
    update_path_hash(&mut request_hash, destination);
    request_hash.update([0]);
    request_hash.update(request.operation_id.as_str().as_bytes());
    request_hash.update([0]);
    request_hash.update(request.backup_identity.0);
    hex_prefix(&request_hash.finalize(), 32)
}

fn owner_path(destination: &Path, operation_id: &RestoreOperationId) -> PathBuf {
    destination.with_file_name(format!(
        ".event-stream-restore-{}.owner",
        operation_hash(destination, operation_id)
    ))
}

fn operation_hash(destination: &Path, operation_id: &RestoreOperationId) -> String {
    let mut hash = Sha256::new();
    update_path_hash(&mut hash, destination);
    hash.update([0]);
    hash.update(operation_id.as_str().as_bytes());
    hex_prefix(&hash.finalize(), 32)
}

#[cfg(unix)]
fn update_path_hash(hash: &mut Sha256, path: &Path) {
    use std::os::unix::ffi::OsStrExt;
    hash.update(path.as_os_str().as_bytes());
}

#[cfg(not(unix))]
fn update_path_hash(hash: &mut Sha256, path: &Path) {
    hash.update(path.as_os_str().to_string_lossy().as_bytes());
}

fn ensure_owner_reservation(
    request: &RestoreRequest,
    destination: &Path,
    max_staging_bytes: u64,
    failure: &AtomicU8,
    pause_marker: Option<&Path>,
) -> RestoreResult<usize> {
    let owner = owner_path(destination, &request.operation_id);
    match std::fs::create_dir(&owner) {
        Ok(()) => {
            sync_directory(destination.parent().unwrap())?;
        }
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
            let metadata = std::fs::symlink_metadata(&owner).map_err(|error| {
                RestoreError::StorageFailure(format!("inspect restore owner directory: {error}"))
            })?;
            if metadata.file_type().is_symlink() || !metadata.is_dir() {
                return Err(RestoreError::StagingCleanupFailed {
                    paths: vec![owner.clone()],
                });
            }
        }
        Err(error) => {
            return Err(RestoreError::StorageFailure(format!(
                "reserve restore owner directory: {error}"
            )))
        }
    }
    let charge = request
        .operation_id
        .as_str()
        .len()
        .checked_add(destination.as_os_str().len())
        .and_then(|value| value.checked_add(512))
        .ok_or(RestoreError::CapacityExceeded)?;
    if u64::try_from(charge).map_err(|_| RestoreError::CapacityExceeded)? > max_staging_bytes {
        return Err(RestoreError::CapacityExceeded);
    }
    let expected = owner.join(format!("request-{}", request_hash(destination, request)));
    let entries = bounded_directory_entries(&owner)?;
    if entries.is_empty() {
        std::fs::create_dir(&expected).map_err(|error| {
            RestoreError::StorageFailure(format!("bind restore request identity: {error}"))
        })?;
        sync_directory(&owner)?;
        sync_directory(destination.parent().unwrap())?;
        if consume_or_pause(
            failure,
            SqliteRestoreFailureInjection::AfterOwnerReservation,
            pause_marker,
        ) {
            return Err(RestoreError::StorageFailure(
                "injected failure after restore owner reservation".into(),
            ));
        }
    } else if entries.len() != 1 || entries[0] != expected {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    }
    validate_owner_reservation(request, destination)?;
    Ok(charge)
}

fn validate_owner_reservation(request: &RestoreRequest, destination: &Path) -> RestoreResult<()> {
    let owner = owner_path(destination, &request.operation_id);
    let owner_metadata = std::fs::symlink_metadata(&owner).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect restore owner directory: {error}"))
    })?;
    if owner_metadata.file_type().is_symlink() || !owner_metadata.is_dir() {
        return Err(RestoreError::StagingCleanupFailed { paths: vec![owner] });
    }
    let expected = owner.join(format!("request-{}", request_hash(destination, request)));
    let entries = bounded_directory_entries(&owner)?;
    if entries.len() != 1 || entries[0] != expected {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    }
    let metadata = std::fs::symlink_metadata(&expected).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect restore request binding: {error}"))
    })?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(RestoreError::StagingCleanupFailed {
            paths: vec![expected],
        });
    }
    let unexpected = bounded_directory_entries(&expected)?;
    if !unexpected.is_empty() {
        return Err(RestoreError::StagingCleanupFailed { paths: unexpected });
    }
    Ok(())
}

fn bounded_directory_entries(directory: &Path) -> RestoreResult<Vec<PathBuf>> {
    let mut entries = Vec::with_capacity(2);
    for entry in std::fs::read_dir(directory).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect restore reservation: {error}"))
    })? {
        entries.push(
            entry
                .map_err(|error| {
                    RestoreError::StorageFailure(format!("read restore reservation: {error}"))
                })?
                .path(),
        );
        if entries.len() == 2 {
            break;
        }
    }
    Ok(entries)
}

fn remove_owner_files(destination: &Path, request: &RestoreRequest) -> RestoreResult<()> {
    let owner = owner_path(destination, &request.operation_id);
    if !path_entry_exists(&owner)? {
        return Ok(());
    }
    validate_owner_reservation(request, destination)?;
    let binding = owner.join(format!("request-{}", request_hash(destination, request)));
    std::fs::remove_dir(&binding).map_err(|_| RestoreError::StagingCleanupFailed {
        paths: vec![binding],
    })?;
    std::fs::remove_dir(&owner)
        .map_err(|_| RestoreError::StagingCleanupFailed { paths: vec![owner] })?;
    sync_directory(destination.parent().unwrap())
}

fn path_entry_exists(path: &Path) -> RestoreResult<bool> {
    match std::fs::symlink_metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(RestoreError::StorageFailure(format!(
            "inspect restore control path {}: {error}",
            path.display()
        ))),
    }
}

fn hex_prefix(bytes: &[u8], count: usize) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut value = String::with_capacity(count * 2);
    for byte in bytes.iter().take(count) {
        value.push(char::from(HEX[usize::from(byte >> 4)]));
        value.push(char::from(HEX[usize::from(byte & 0x0f)]));
    }
    value
}

fn restore_blocking(
    root: &Path,
    request: &RestoreRequest,
    config: &RestoreConfig,
    failure: &AtomicU8,
    pause_marker: Option<&Path>,
    #[cfg(feature = "test-support")] observer: Option<&dyn SqliteRestoreObserver>,
) -> RestoreResult<RestoreReceipt> {
    let destination = resolve_destination(root, &request.destination)?;
    let _destination_ownership =
        Ownership::acquire_restore_destination(&destination).map_err(map_store_error)?;
    let staging = staging_path(&destination, request)?;

    if destination.exists() {
        let receipt = read_published_receipt(&destination, request, true)?;
        finish_staging_alias_if_owned(&staging, &destination, request)?;
        return Ok(receipt);
    }
    let owner = owner_path(&destination, &request.operation_id);
    let mut staging_present = path_entry_exists(&staging)?;
    if staging_present {
        validate_staging_file_boundary(&staging)?;
    }
    if staging_present
        && path_entry_exists(&owner)?
        && std::fs::metadata(&staging)
            .map_err(|error| {
                RestoreError::StorageFailure(format!("inspect reserved staging file: {error}"))
            })?
            .len()
            == 0
    {
        validate_owner_reservation(request, &destination)?;
        std::fs::remove_file(&staging).map_err(|error| {
            RestoreError::StorageFailure(format!("remove empty reserved staging file: {error}"))
        })?;
        sync_directory(destination.parent().unwrap())?;
        staging_present = false;
    }
    if staging_present {
        let incomplete = validate_staging_owner(&staging, request, &destination)?;
        ensure_owner_reservation(
            request,
            &destination,
            config.max_staging_bytes,
            failure,
            pause_marker,
        )?;
        #[cfg(feature = "test-support")]
        observe(observer, SqliteRestoreStage::OwnerReserved);
        if incomplete {
            return Err(RestoreError::IncompleteStaging {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination),
            });
        }
        validate_stored_mapping_count(
            &Connection::open_with_flags(
                &staging,
                OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
            )
            .map_err(|error| {
                RestoreError::CorruptBackup(format!(
                    "open completed staging for validation: {error}"
                ))
            })?,
        )?;
        sync_file(&staging)?;
        publish_no_replace(&staging, &destination, request, failure, pause_marker)?;
        return read_published_receipt(&destination, request, true);
    }

    let source_ownership = Ownership::acquire(&request.source).map_err(map_store_error)?;
    let (source, actual) = open_locked_source(source_ownership.path(), config)?;
    if actual != request.backup_identity {
        return Err(RestoreError::IdentityMismatch {
            expected: request.backup_identity,
            actual,
        });
    }
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::SourceValidated);

    let owner_charge = ensure_owner_reservation(
        request,
        &destination,
        config.max_staging_bytes,
        failure,
        pause_marker,
    )?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::OwnerReserved);

    let mut target = create_incomplete_staging(
        &staging,
        request,
        &destination,
        config,
        owner_charge,
        failure,
        pause_marker,
    )?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::StagingCreated);
    let result = (|| {
        import_all(
            &source,
            &mut target,
            request,
            config,
            #[cfg(feature = "test-support")]
            observer,
        )?;
        validate_import(&target)?;
        #[cfg(feature = "test-support")]
        observe(observer, SqliteRestoreStage::RelationalValidationCompleted);
        complete_staging(&mut target, request, &destination)?;
        validate_stored_mapping_count(&target)?;
        #[cfg(feature = "test-support")]
        observe(observer, SqliteRestoreStage::StagingCompleted);
        enforce_staging_limit(&target, config.max_staging_bytes)?;
        Ok(())
    })();
    if let Err(error) = result {
        drop(target);
        return Err(error);
    }
    target
        .close()
        .map_err(|(_, error)| RestoreError::StorageFailure(format!("close staging: {error}")))?;
    sync_file(&staging)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::StagingSynced);
    if consume_or_pause(
        failure,
        SqliteRestoreFailureInjection::AfterStagingCompletion,
        pause_marker,
    ) {
        return Err(RestoreError::StorageFailure(
            "injected failure after staging completion".into(),
        ));
    }
    publish_no_replace(&staging, &destination, request, failure, pause_marker)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::DestinationPublished);
    read_published_receipt(&destination, request, true)
}

#[cfg(feature = "test-support")]
fn observe(observer: Option<&dyn SqliteRestoreObserver>, stage: SqliteRestoreStage) {
    if let Some(observer) = observer {
        observer.observe(stage);
    }
}

fn open_read_only(path: &Path) -> RestoreResult<Connection> {
    Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::CorruptBackup(format!("open backup read-only: {error}")))
}

fn create_incomplete_staging(
    path: &Path,
    request: &RestoreRequest,
    destination: &Path,
    config: &RestoreConfig,
    owner_charge: usize,
    failure: &AtomicU8,
    pause_marker: Option<&Path>,
) -> RestoreResult<Connection> {
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|error| RestoreError::StorageFailure(format!("reserve staging: {error}")))?;
    if consume_or_pause(
        failure,
        SqliteRestoreFailureInjection::AfterStagingFileReservation,
        pause_marker,
    ) {
        return Err(RestoreError::StorageFailure(
            "injected failure after staging file reservation".into(),
        ));
    }
    let flags = OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX;
    let conn = Connection::open_with_flags(path, flags)
        .map_err(|error| RestoreError::StorageFailure(format!("create staging: {error}")))?;
    conn.pragma_update(None, "journal_mode", "DELETE")
        .map_err(|error| RestoreError::StorageFailure(format!("set staging journal: {error}")))?;
    conn.pragma_update(None, "synchronous", "FULL")
        .map_err(|error| RestoreError::StorageFailure(format!("set staging sync: {error}")))?;
    conn.pragma_update(None, "foreign_keys", true)
        .map_err(|error| {
            RestoreError::StorageFailure(format!("set staging foreign keys: {error}"))
        })?;
    let cache_kib = config.copy_buffer_bytes.div_ceil(1024).clamp(1, 16 * 1024);
    conn.pragma_update(
        None,
        "cache_size",
        -i64::try_from(cache_kib).map_err(|_| RestoreError::CapacityExceeded)?,
    )
    .map_err(|error| RestoreError::StorageFailure(format!("bound staging cache: {error}")))?;
    conn.pragma_update(None, "temp_store", "FILE")
        .map_err(|error| {
            RestoreError::StorageFailure(format!("bound staging temp memory: {error}"))
        })?;
    let page_size: u64 = conn
        .pragma_query_value(None, "page_size", |row| row.get(0))
        .map_err(|error| {
            RestoreError::StorageFailure(format!("read staging page size: {error}"))
        })?;
    let database_bytes = config
        .max_staging_bytes
        .checked_sub(u64::try_from(owner_charge).map_err(|_| RestoreError::CapacityExceeded)?)
        .ok_or(RestoreError::CapacityExceeded)?;
    let pages = database_bytes / page_size;
    if pages == 0 || pages > i32::MAX as u64 {
        return Err(RestoreError::InvalidConfig(
            "staging byte limit cannot be represented as SQLite pages".into(),
        ));
    }
    conn.pragma_update(None, "max_page_count", pages)
        .map_err(|error| {
            RestoreError::StorageFailure(format!("set staging page limit: {error}"))
        })?;
    let destination = destination
        .to_str()
        .ok_or_else(|| RestoreError::InvalidConfig("canonical destination must be UTF-8".into()))?;
    let schema_result = conn.execute_batch(
        "BEGIN IMMEDIATE;
         CREATE TABLE event_stream_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),format_version INTEGER NOT NULL,lifecycle_receipt_count INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_count>=0),lifecycle_receipt_bytes INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_bytes>=0),retired_lifetime_count INTEGER NOT NULL DEFAULT 0 CHECK(retired_lifetime_count>=0),retired_metadata_bytes INTEGER NOT NULL DEFAULT 0 CHECK(retired_metadata_bytes>=0),restore_incomplete INTEGER NOT NULL DEFAULT 1 CHECK(restore_incomplete IN (0,1,2)));
         CREATE TABLE event_streams(stream_key INTEGER PRIMARY KEY,public_id TEXT NOT NULL,incarnation BLOB NOT NULL CHECK(length(incarnation)=16),floor BLOB NOT NULL CHECK(length(floor)=8),tail BLOB NOT NULL CHECK(length(tail)=8),retired INTEGER NOT NULL DEFAULT 0 CHECK(retired IN (0,1)),UNIQUE(public_id,incarnation));
         CREATE TABLE event_records(stream_key INTEGER NOT NULL,offset BLOB NOT NULL CHECK(length(offset)=8),event_id TEXT NOT NULL,schema_id TEXT NOT NULL,schema_version INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(stream_key,offset),UNIQUE(stream_key,event_id),FOREIGN KEY(stream_key) REFERENCES event_streams(stream_key));
         CREATE TABLE event_stream_names(public_id TEXT PRIMARY KEY,latest_incarnation BLOB NOT NULL CHECK(length(latest_incarnation)=16),active_stream_key INTEGER);
         CREATE TABLE lifecycle_receipts(operation_id TEXT PRIMARY KEY,action INTEGER NOT NULL CHECK(action IN (0,1)),expected_public_id TEXT NOT NULL,expected_incarnation BLOB NOT NULL CHECK(length(expected_incarnation)=16),replacement_incarnation BLOB CHECK(replacement_incarnation IS NULL OR length(replacement_incarnation)=16),charge INTEGER NOT NULL CHECK(charge>=0));
         CREATE TABLE restore_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),operation_id TEXT NOT NULL,backup_identity BLOB NOT NULL CHECK(length(backup_identity)=32),destination TEXT NOT NULL,mapping_count INTEGER NOT NULL CHECK(mapping_count>=0));
         CREATE TABLE restore_mappings(old_public_id TEXT NOT NULL,old_incarnation BLOB NOT NULL CHECK(length(old_incarnation)=16),new_incarnation BLOB NOT NULL CHECK(length(new_incarnation)=16),PRIMARY KEY(old_public_id,old_incarnation));
         CREATE TABLE restore_lifetime_keys(old_stream_key INTEGER PRIMARY KEY,new_stream_key INTEGER NOT NULL UNIQUE);
         CREATE INDEX event_streams_retired_idx ON event_streams(retired,stream_key);",
    );
    if let Err(error) = schema_result {
        return Err(map_sql_write("create staging schema", error));
    }
    #[cfg(feature = "snapshots")]
    conn.execute_batch(
        "CREATE TABLE snapshot_metadata(
           singleton INTEGER PRIMARY KEY CHECK(singleton=1),
           staged_count INTEGER NOT NULL CHECK(staged_count>=0), staged_bytes INTEGER NOT NULL CHECK(staged_bytes>=0),
           published_count INTEGER NOT NULL CHECK(published_count>=0), published_bytes INTEGER NOT NULL CHECK(published_bytes>=0),
           chunk_count INTEGER NOT NULL CHECK(chunk_count>=0), chunk_metadata_bytes INTEGER NOT NULL CHECK(chunk_metadata_bytes>=0),
           descriptor_metadata_bytes INTEGER NOT NULL CHECK(descriptor_metadata_bytes>=0),
           receipt_count INTEGER NOT NULL CHECK(receipt_count>=0), receipt_bytes INTEGER NOT NULL CHECK(receipt_bytes>=0));
         CREATE TABLE snapshots(
           snapshot_id BLOB PRIMARY KEY CHECK(typeof(snapshot_id)='blob' AND length(snapshot_id)=16),
           public_id TEXT NOT NULL, incarnation BLOB NOT NULL CHECK(typeof(incarnation)='blob' AND length(incarnation)=16),
           covered BLOB NOT NULL CHECK(typeof(covered)='blob' AND length(covered)=8), schema_id TEXT NOT NULL,
           schema_version INTEGER NOT NULL, content_bytes BLOB NOT NULL CHECK(typeof(content_bytes)='blob' AND length(content_bytes)=8),
           digest BLOB NOT NULL CHECK(typeof(digest)='blob' AND length(digest)=32), state INTEGER NOT NULL CHECK(state BETWEEN 0 AND 4),
           accepted_bytes BLOB NOT NULL CHECK(typeof(accepted_bytes)='blob' AND length(accepted_bytes)=8),
           verified_bytes BLOB NOT NULL CHECK(typeof(verified_bytes)='blob' AND length(verified_bytes)=8),
           checksum_failed INTEGER NOT NULL DEFAULT 0 CHECK(checksum_failed IN (0,1)), cleaned INTEGER NOT NULL DEFAULT 0 CHECK(cleaned IN (0,1)),
           descriptor_charge INTEGER NOT NULL CHECK(descriptor_charge>=0), receipt_reserved INTEGER NOT NULL DEFAULT 0 CHECK(receipt_reserved IN (0,1)));
         CREATE TABLE snapshot_chunks(snapshot_id BLOB NOT NULL,offset BLOB NOT NULL CHECK(typeof(offset)='blob' AND length(offset)=8),bytes BLOB NOT NULL,
           PRIMARY KEY(snapshot_id,offset),FOREIGN KEY(snapshot_id) REFERENCES snapshots(snapshot_id));
         CREATE INDEX snapshots_published_idx ON snapshots(public_id,incarnation,state,covered,snapshot_id);
         CREATE INDEX snapshots_cleanup_idx ON snapshots(state,cleaned,snapshot_id);
         INSERT INTO snapshot_metadata VALUES(1,0,0,0,0,0,0,0,0,0);",
    )
    .map_err(|error| map_sql_write("create staging snapshot schema", error))?;
    conn.execute(
        "INSERT INTO event_stream_metadata(singleton,format_version,restore_incomplete) VALUES(1,2,1)",
        [],
    )
    .map_err(|error| map_sql_write("mark staging incomplete", error))?;
    conn.execute(
        "INSERT INTO restore_metadata(singleton,operation_id,backup_identity,destination,mapping_count) VALUES(1,?1,?2,?3,0)",
        params![request.operation_id.as_str(), request.backup_identity.0.as_slice(), destination],
    )
    .map_err(|error| map_sql_write("store restore identity", error))?;
    conn.execute_batch("COMMIT;")
        .map_err(|error| map_sql_write("commit incomplete staging marker", error))?;
    sync_file(path)?;
    Ok(conn)
}

fn map_sql_write(action: &str, error: rusqlite::Error) -> RestoreError {
    if let rusqlite::Error::SqliteFailure(code, _) = &error {
        if code.code == rusqlite::ErrorCode::DiskFull {
            return RestoreError::CapacityExceeded;
        }
    }
    RestoreError::StorageFailure(format!("{action}: {error}"))
}

fn enforce_staging_limit(conn: &Connection, max_bytes: u64) -> RestoreResult<()> {
    let (pages, page_size): (u64, u64) = conn
        .query_row(
            "SELECT page_count,page_size FROM pragma_page_count(),pragma_page_size()",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .map_err(|error| RestoreError::StorageFailure(format!("measure staging: {error}")))?;
    pages
        .checked_mul(page_size)
        .filter(|bytes| *bytes <= max_bytes)
        .ok_or(RestoreError::CapacityExceeded)?;
    Ok(())
}

fn import_all(
    source: &Connection,
    target: &mut Connection,
    request: &RestoreRequest,
    config: &RestoreConfig,
    #[cfg(feature = "test-support")] observer: Option<&dyn SqliteRestoreObserver>,
) -> RestoreResult<()> {
    let mapping_count = import_identity_mappings(source, target, config)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::IdentityMappingsImported);
    import_lifetimes(source, target, config)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::LifetimesImported);
    import_records(
        source,
        target,
        config,
        #[cfg(feature = "test-support")]
        observer,
    )?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::RecordsImported);
    import_names(source, target, config)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::NamesImported);
    import_receipts(source, target, config)?;
    #[cfg(feature = "test-support")]
    observe(observer, SqliteRestoreStage::ReceiptsImported);
    import_snapshots(source, target, config)?;
    let counters: (i64, i64, i64, i64) = source
        .query_row(
            "SELECT lifecycle_receipt_count,lifecycle_receipt_bytes,retired_lifetime_count,retired_metadata_bytes FROM event_stream_metadata WHERE singleton=1",
            [],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("read source counters: {error}")))?;
    target
        .execute(
            "UPDATE event_stream_metadata SET lifecycle_receipt_count=?1,lifecycle_receipt_bytes=?2,retired_lifetime_count=?3,retired_metadata_bytes=?4 WHERE singleton=1",
            params![counters.0, counters.1, counters.2, counters.3],
        )
        .map_err(|error| map_sql_write("copy lifecycle counters", error))?;
    target
        .execute(
            "UPDATE restore_metadata SET mapping_count=?1 WHERE singleton=1 AND operation_id=?2",
            params![
                i64::try_from(mapping_count).map_err(|_| RestoreError::CapacityExceeded)?,
                request.operation_id.as_str()
            ],
        )
        .map_err(|error| map_sql_write("store mapping count", error))?;
    Ok(())
}

fn import_identity_mappings(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<u64> {
    let mut count = 0_u64;
    #[cfg(feature = "snapshots")]
    let include_snapshots = snapshot_schema_present(source)?;
    #[cfg(feature = "snapshots")]
    let identity_sql = if include_snapshots {
        "SELECT octet_length(public_id),
                CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END
         FROM (
           SELECT public_id,incarnation FROM event_streams
           UNION SELECT public_id,latest_incarnation FROM event_stream_names
           UNION SELECT expected_public_id,expected_incarnation FROM lifecycle_receipts
           UNION SELECT expected_public_id,replacement_incarnation FROM lifecycle_receipts WHERE replacement_incarnation IS NOT NULL
           UNION SELECT public_id,incarnation FROM snapshots
         ) ORDER BY public_id,incarnation"
    } else {
        IDENTITY_UNION_SQL
    };
    #[cfg(not(feature = "snapshots"))]
    let identity_sql = IDENTITY_UNION_SQL;
    let mut statement = source
        .prepare(identity_sql)
        .map_err(|error| RestoreError::CorruptBackup(format!("prepare identity union: {error}")))?;
    let mut rows = statement
        .query([])
        .map_err(|error| RestoreError::CorruptBackup(format!("query identity union: {error}")))?;
    let mut pending = None;
    loop {
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while batch.len() < config.page.max_records {
            let item = if let Some(item) = pending.take() {
                item
            } else {
                let Some(row) = rows.next().map_err(|error| {
                    RestoreError::CorruptBackup(format!("step identity union: {error}"))
                })?
                else {
                    break;
                };
                let length: i64 = row.get(0).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read identity length: {error}"))
                })?;
                let id: Option<String> = row.get(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read mapped stream name: {error}"))
                })?;
                let incarnation: Option<Vec<u8>> = row.get(2).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read mapped incarnation: {error}"))
                })?;
                let length = usize::try_from(length).map_err(|_| {
                    RestoreError::CorruptBackup("invalid stream-name length".into())
                })?;
                let id = StreamId::new(id.ok_or_else(|| {
                    RestoreError::CorruptBackup("invalid stream name in identity union".into())
                })?)
                .map_err(|_| RestoreError::CorruptBackup("invalid stream name".into()))?;
                let incarnation = fixed::<16>(incarnation, "incarnation")?;
                (id, incarnation, length)
            };
            let (id, incarnation, length) = item;
            let charge = length
                .checked_mul(2)
                .and_then(|value| value.checked_add(128))
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                pending = Some((id, incarnation, length));
                break;
            }
            bytes += charge;
            batch.push((id, incarnation));
        }
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin mapping page", error))?;
        for (id, old) in &batch {
            let new = super::new_incarnation();
            transaction
                .execute(
                    "INSERT INTO restore_mappings(old_public_id,old_incarnation,new_incarnation) VALUES(?1,?2,?3)",
                    params![id.as_str(), old.as_slice(), new.0.as_slice()],
                )
                .map_err(|error| map_sql_write("insert incarnation mapping", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit mapping page", error))?;
        count = count
            .checked_add(batch.len() as u64)
            .ok_or(RestoreError::CapacityExceeded)?;
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(count)
}

const IDENTITY_UNION_SQL: &str =
    "SELECT octet_length(public_id),
            CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
            CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END
     FROM (
       SELECT public_id,incarnation FROM event_streams
       UNION SELECT public_id,latest_incarnation FROM event_stream_names
       UNION SELECT expected_public_id,expected_incarnation FROM lifecycle_receipts
       UNION SELECT expected_public_id,replacement_incarnation FROM lifecycle_receipts WHERE replacement_incarnation IS NOT NULL
     ) ORDER BY public_id,incarnation";

fn mapped_incarnation(target: &Connection, id: &str, old: &[u8; 16]) -> RestoreResult<[u8; 16]> {
    let value: Vec<u8> = target
        .query_row(
            "SELECT new_incarnation FROM restore_mappings WHERE old_public_id=?1 AND old_incarnation=?2",
            params![id, old.as_slice()],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("missing identity mapping: {error}")))?;
    fixed(Some(value), "mapped incarnation")
}

fn import_lifetimes(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = 0_i64;
    loop {
        let mut statement = source.prepare(
            "SELECT stream_key,
                    CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                    CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END,
                    CASE WHEN typeof(floor)='blob' AND length(floor)=8 THEN floor END,
                    CASE WHEN typeof(tail)='blob' AND length(tail)=8 THEN tail END,
                    CASE WHEN typeof(retired)='integer' AND retired IN (0,1) THEN retired END
             FROM event_streams WHERE stream_key>?1 ORDER BY stream_key LIMIT ?2",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare lifetimes: {error}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| RestoreError::CorruptBackup(format!("query lifetimes: {error}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step lifetimes: {error}")))?
        {
            let key: i64 = row.get(0).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime key: {error}"))
            })?;
            let id: Option<String> = row.get(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime name: {error}"))
            })?;
            let old: Option<Vec<u8>> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime incarnation: {error}"))
            })?;
            let floor: Option<Vec<u8>> = row.get(3).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime floor: {error}"))
            })?;
            let tail: Option<Vec<u8>> = row.get(4).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime tail: {error}"))
            })?;
            let retired: Option<i64> = row.get(5).map_err(|error| {
                RestoreError::CorruptBackup(format!("read retired flag: {error}"))
            })?;
            let id = StreamId::new(
                id.ok_or_else(|| RestoreError::CorruptBackup("invalid lifetime name".into()))?,
            )
            .map_err(|_| RestoreError::CorruptBackup("invalid lifetime name".into()))?;
            let old = fixed::<16>(old, "lifetime incarnation")?;
            let floor = fixed::<8>(floor, "lifetime floor")?;
            let tail = fixed::<8>(tail, "lifetime tail")?;
            if floor > tail || retired.is_none() {
                return Err(RestoreError::CorruptBackup(
                    "invalid lifetime metadata".into(),
                ));
            }
            let charge = id
                .as_str()
                .len()
                .checked_add(256)
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                break;
            }
            bytes += charge;
            batch.push((key, id, old, floor, tail, retired.unwrap()));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin lifetime page", error))?;
        for (old_key, id, old, floor, tail, retired) in &batch {
            let new = mapped_incarnation(&transaction, id.as_str(), old)?;
            transaction.execute(
                "INSERT INTO event_streams(public_id,incarnation,floor,tail,retired) VALUES(?1,?2,?3,?4,?5)",
                params![id.as_str(),new.as_slice(),floor.as_slice(),tail.as_slice(),retired],
            ).map_err(|error| map_sql_write("insert restored lifetime", error))?;
            let new_key = transaction.last_insert_rowid();
            transaction.execute("INSERT INTO restore_lifetime_keys(old_stream_key,new_stream_key) VALUES(?1,?2)", params![old_key,new_key])
                .map_err(|error| map_sql_write("map lifetime key", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit lifetime page", error))?;
        after = batch.last().unwrap().0;
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn fixed<const N: usize>(value: Option<Vec<u8>>, label: &str) -> RestoreResult<[u8; N]> {
    value
        .ok_or_else(|| RestoreError::CorruptBackup(format!("invalid {label}")))?
        .try_into()
        .map_err(|_| RestoreError::CorruptBackup(format!("invalid {label}")))
}

fn import_records(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
    #[cfg(feature = "test-support")] observer: Option<&dyn SqliteRestoreObserver>,
) -> RestoreResult<()> {
    struct Lifetime {
        old_key: i64,
        new_key: i64,
        floor: u64,
        tail: u64,
        next: u64,
    }

    type PendingRecord = (i64, [u8; 8], String, String, i64, Vec<u8>);

    fn finish_lifetime(lifetime: &Lifetime) -> RestoreResult<()> {
        if lifetime.next != lifetime.tail {
            return Err(RestoreError::CorruptBackup(
                "record history ends before declared tail".into(),
            ));
        }
        Ok(())
    }

    fn flush(
        target: &mut Connection,
        batch: &mut Vec<PendingRecord>,
        batch_bytes: &mut usize,
        config: &RestoreConfig,
        #[cfg(feature = "test-support")] observer: Option<&dyn SqliteRestoreObserver>,
    ) -> RestoreResult<()> {
        if batch.is_empty() {
            return Ok(());
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin record page", error))?;
        for (new_key, offset, event, schema, version, payload) in batch.iter() {
            transaction.execute(
                "INSERT INTO event_records(stream_key,offset,event_id,schema_id,schema_version,payload) VALUES(?1,?2,?3,?4,?5,?6)",
                params![new_key,offset.as_slice(),event,schema,version,payload],
            ).map_err(|error| map_sql_write("insert restored record", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit record page", error))?;
        #[cfg(feature = "test-support")]
        observe(observer, SqliteRestoreStage::RecordPageCommitted);
        enforce_staging_limit(target, config.max_staging_bytes)?;
        batch.clear();
        *batch_bytes = 0;
        Ok(())
    }

    let payload_limit =
        i64::try_from(config.page.max_bytes).map_err(|_| RestoreError::CapacityExceeded)?;
    let mut statement = source.prepare(
        "SELECT s.stream_key,
                CASE WHEN typeof(s.floor)='blob' AND length(s.floor)=8 THEN s.floor END,
                CASE WHEN typeof(s.tail)='blob' AND length(s.tail)=8 THEN s.tail END,
                r.rowid,
                octet_length(r.event_id),octet_length(r.schema_id),octet_length(r.payload),
                CASE WHEN typeof(r.offset)='blob' AND length(r.offset)=8 THEN r.offset END,
                CASE WHEN typeof(r.event_id)='text' AND octet_length(r.event_id) BETWEEN 1 AND 256 THEN r.event_id END,
                CASE WHEN typeof(r.schema_id)='text' AND octet_length(r.schema_id) BETWEEN 1 AND 256 THEN r.schema_id END,
                CASE WHEN typeof(r.schema_version)='integer' THEN r.schema_version END,
                CASE WHEN typeof(r.payload)='blob' AND octet_length(r.payload)<=?1 THEN r.payload END
         FROM event_streams AS s
         LEFT JOIN event_records AS r ON r.stream_key=s.stream_key
         ORDER BY s.stream_key,r.offset",
    ).map_err(|error| RestoreError::CorruptBackup(format!("prepare record import: {error}")))?;
    let mut rows = statement
        .query(params![payload_limit])
        .map_err(|error| RestoreError::CorruptBackup(format!("query record import: {error}")))?;
    let mut current: Option<Lifetime> = None;
    let mut batch = Vec::with_capacity(config.page.max_records.min(256));
    let mut batch_bytes = 0usize;

    while let Some(row) = rows
        .next()
        .map_err(|error| RestoreError::CorruptBackup(format!("step record import: {error}")))?
    {
        let old_key: i64 = row.get(0).map_err(|error| {
            RestoreError::CorruptBackup(format!("read record lifetime key: {error}"))
        })?;
        if current
            .as_ref()
            .is_none_or(|state| state.old_key != old_key)
        {
            if let Some(state) = current.as_ref() {
                finish_lifetime(state)?;
            }
            let floor = u64::from_be_bytes(fixed::<8>(
                row.get::<_, Option<Vec<u8>>>(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read record floor: {error}"))
                })?,
                "record floor",
            )?);
            let tail = u64::from_be_bytes(fixed::<8>(
                row.get::<_, Option<Vec<u8>>>(2).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read record tail: {error}"))
                })?,
                "record tail",
            )?);
            if floor > tail {
                return Err(RestoreError::CorruptBackup(
                    "record floor exceeds tail".into(),
                ));
            }
            let new_key = target
                .query_row(
                    "SELECT new_stream_key FROM restore_lifetime_keys WHERE old_stream_key=?1",
                    params![old_key],
                    |target_row| target_row.get(0),
                )
                .map_err(|error| {
                    RestoreError::CorruptBackup(format!("missing lifetime key mapping: {error}"))
                })?;
            current = Some(Lifetime {
                old_key,
                new_key,
                floor,
                tail,
                next: floor,
            });
        }
        let state = current.as_mut().expect("record lifetime initialized");
        let record_rowid: Option<i64> = row.get(3).map_err(|error| {
            RestoreError::CorruptBackup(format!("read record row identifier: {error}"))
        })?;
        if record_rowid.is_none() {
            if state.floor != state.tail {
                return Err(RestoreError::CorruptBackup(
                    "record history ends before declared tail".into(),
                ));
            }
            continue;
        }

        let event_len =
            usize::try_from(row.get::<_, i64>(4).map_err(|error| {
                RestoreError::CorruptBackup(format!("read event length: {error}"))
            })?)
            .map_err(|_| RestoreError::CorruptBackup("invalid event length".into()))?;
        let schema_len = usize::try_from(row.get::<_, i64>(5).map_err(|error| {
            RestoreError::CorruptBackup(format!("read schema length: {error}"))
        })?)
        .map_err(|_| RestoreError::CorruptBackup("invalid schema length".into()))?;
        let payload_len = usize::try_from(row.get::<_, i64>(6).map_err(|error| {
            RestoreError::CorruptBackup(format!("read payload length: {error}"))
        })?)
        .map_err(|_| RestoreError::CorruptBackup("invalid payload length".into()))?;
        let charge = event_len
            .checked_add(schema_len)
            .and_then(|value| value.checked_add(payload_len))
            .and_then(|value| value.checked_add(128))
            .ok_or(RestoreError::CapacityExceeded)?;
        if charge > config.page.max_bytes {
            return Err(RestoreError::CapacityExceeded);
        }
        if batch.len() == config.page.max_records
            || batch_bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
        {
            flush(
                target,
                &mut batch,
                &mut batch_bytes,
                config,
                #[cfg(feature = "test-support")]
                observer,
            )?;
        }

        let offset = fixed::<8>(
            row.get::<_, Option<Vec<u8>>>(7).map_err(|error| {
                RestoreError::CorruptBackup(format!("read record offset: {error}"))
            })?,
            "record offset",
        )?;
        let offset_value = u64::from_be_bytes(offset);
        let expected = state
            .next
            .checked_add(1)
            .ok_or_else(|| RestoreError::CorruptBackup("record offset overflow".into()))?;
        if offset_value != expected || offset_value <= state.floor || offset_value > state.tail {
            return Err(RestoreError::CorruptBackup(
                "invalid or noncontiguous record history".into(),
            ));
        }
        let event = row
            .get::<_, Option<String>>(8)
            .map_err(|error| RestoreError::CorruptBackup(format!("read event ID: {error}")))?;
        let schema = row
            .get::<_, Option<String>>(9)
            .map_err(|error| RestoreError::CorruptBackup(format!("read schema ID: {error}")))?;
        let version = row.get::<_, Option<i64>>(10).map_err(|error| {
            RestoreError::CorruptBackup(format!("read schema version: {error}"))
        })?;
        let payload = row.get::<_, Option<Vec<u8>>>(11).map_err(|error| {
            RestoreError::CorruptBackup(format!("read record payload: {error}"))
        })?;
        let (event, schema, version, payload) = match (event, schema, version, payload) {
            (Some(event), Some(schema), Some(version), Some(payload)) => {
                let version = u32::try_from(version).map_err(|_| {
                    RestoreError::CorruptBackup("invalid restored schema version".into())
                })?;
                (event, schema, i64::from(version), payload)
            }
            _ => {
                return Err(RestoreError::CorruptBackup(
                    "invalid restored record value".into(),
                ))
            }
        };
        batch_bytes = batch_bytes
            .checked_add(charge)
            .ok_or(RestoreError::CapacityExceeded)?;
        batch.push((state.new_key, offset, event, schema, version, payload));
        state.next = offset_value;
    }
    if let Some(state) = current.as_ref() {
        finish_lifetime(state)?;
    }
    drop(rows);
    drop(statement);
    flush(
        target,
        &mut batch,
        &mut batch_bytes,
        config,
        #[cfg(feature = "test-support")]
        observer,
    )
}

fn import_names(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = String::new();
    loop {
        let mut statement = source.prepare(
            "SELECT CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                    CASE WHEN typeof(latest_incarnation)='blob' AND length(latest_incarnation)=16 THEN latest_incarnation END,
                    active_stream_key
             FROM event_stream_names WHERE public_id>?1 ORDER BY public_id LIMIT ?2",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare names: {error}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| RestoreError::CorruptBackup(format!("query names: {error}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step names: {error}")))?
        {
            let id: Option<String> = row
                .get(0)
                .map_err(|error| RestoreError::CorruptBackup(format!("read name: {error}")))?;
            let incarnation = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read latest incarnation: {error}"))
                })?,
                "latest incarnation",
            )?;
            let active: Option<i64> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read active lifetime: {error}"))
            })?;
            let id = StreamId::new(
                id.ok_or_else(|| RestoreError::CorruptBackup("invalid stream name".into()))?,
            )
            .map_err(|_| RestoreError::CorruptBackup("invalid stream name".into()))?;
            let charge = id
                .as_str()
                .len()
                .checked_add(256)
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|v| v > config.page.max_bytes)
            {
                break;
            }
            bytes += charge;
            batch.push((id, incarnation, active));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| map_sql_write("begin name page", e))?;
        for (id, old, active) in &batch {
            let new = mapped_incarnation(&transaction, id.as_str(), old)?;
            let new_active = active
                .map(|key| {
                    transaction.query_row(
                        "SELECT new_stream_key FROM restore_lifetime_keys WHERE old_stream_key=?1",
                        params![key],
                        |r| r.get::<_, i64>(0),
                    )
                })
                .transpose()
                .map_err(|e| {
                    RestoreError::CorruptBackup(format!("missing active lifetime mapping: {e}"))
                })?;
            transaction.execute("INSERT INTO event_stream_names(public_id,latest_incarnation,active_stream_key) VALUES(?1,?2,?3)",params![id.as_str(),new.as_slice(),new_active]).map_err(|e|map_sql_write("insert restored name",e))?;
        }
        transaction
            .commit()
            .map_err(|e| map_sql_write("commit name page", e))?;
        after = batch.last().unwrap().0.as_str().to_owned();
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn import_receipts(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = String::new();
    loop {
        let mut statement=source.prepare("SELECT octet_length(operation_id),octet_length(expected_public_id),
                    CASE WHEN typeof(operation_id)='text' AND octet_length(operation_id) BETWEEN 1 AND 256 THEN operation_id END,
                    CASE WHEN typeof(action)='integer' AND action IN (0,1) THEN action END,
                    CASE WHEN typeof(expected_public_id)='text' AND octet_length(expected_public_id) BETWEEN 1 AND 256 THEN expected_public_id END,
                    CASE WHEN typeof(expected_incarnation)='blob' AND length(expected_incarnation)=16 THEN expected_incarnation END,
                    CASE WHEN replacement_incarnation IS NULL OR (typeof(replacement_incarnation)='blob' AND length(replacement_incarnation)=16) THEN 1 ELSE 0 END,
                    CASE WHEN typeof(replacement_incarnation)='blob' AND length(replacement_incarnation)=16 THEN replacement_incarnation END,
                    CASE WHEN typeof(charge)='integer' AND charge>=0 THEN charge END
                 FROM lifecycle_receipts WHERE operation_id>?1 ORDER BY operation_id LIMIT ?2")
            .map_err(|e|RestoreError::CorruptBackup(format!("prepare receipts: {e}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|e| RestoreError::CorruptBackup(format!("query receipts: {e}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|e| RestoreError::CorruptBackup(format!("step receipts: {e}")))?
        {
            let op_len: i64 = row.get(0).map_err(|e| {
                RestoreError::CorruptBackup(format!("read receipt operation length: {e}"))
            })?;
            let id_len: i64 = row.get(1).map_err(|e| {
                RestoreError::CorruptBackup(format!("read receipt name length: {e}"))
            })?;
            let op: Option<String> = row.get(2).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt op: {e}"))
            })?;
            let action: Option<i64> = row.get(3).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt action: {e}"))
            })?;
            let id: Option<String> = row.get(4).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt name: {e}"))
            })?;
            let expected = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(5).map_err(|e| {
                    RestoreError::CorruptBackup(format!("read expected incarnation: {e}"))
                })?,
                "expected incarnation",
            )?;
            let replacement_valid: i64 = row.get(6).map_err(|e| {
                RestoreError::CorruptBackup(format!("read replacement validity: {e}"))
            })?;
            let replacement: Option<Vec<u8>> = row.get(7).map_err(|e| {
                RestoreError::CorruptBackup(format!("read replacement incarnation: {e}"))
            })?;
            let charge: Option<i64> = row
                .get(8)
                .map_err(|e| RestoreError::CorruptBackup(format!("read receipt charge: {e}")))?;
            let logical = usize::try_from(op_len)
                .ok()
                .and_then(|op| {
                    usize::try_from(id_len)
                        .ok()
                        .and_then(|id| op.checked_add(id))
                })
                .and_then(|v| v.checked_add(256))
                .ok_or_else(|| {
                    RestoreError::CorruptBackup("invalid lifecycle receipt lengths".into())
                })?;
            if batch.is_empty() && logical > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(logical)
                .is_none_or(|v| v > config.page.max_bytes)
            {
                break;
            }
            let op = op.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle operation ID".into())
            })?;
            let id = id.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle stream name".into())
            })?;
            let action = action
                .ok_or_else(|| RestoreError::CorruptBackup("invalid lifecycle action".into()))?;
            let charge = charge.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle receipt charge".into())
            })?;
            if replacement_valid != 1
                || (action == 0 && replacement.is_some())
                || (action == 1 && replacement.is_none())
                || RestoreOperationId::new(&op).is_err()
                || StreamId::new(&id).is_err()
                || usize::try_from(charge).ok() != Some(logical)
            {
                return Err(RestoreError::CorruptBackup(
                    "invalid lifecycle receipt".into(),
                ));
            }
            bytes += logical;
            batch.push((op, action, id, expected, replacement, charge));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| map_sql_write("begin receipt page", e))?;
        for (op, action, id, expected, replacement, charge) in &batch {
            let new_expected = mapped_incarnation(&transaction, id, expected)?;
            let new_replacement = replacement
                .as_ref()
                .map(|old| {
                    fixed::<16>(Some(old.clone()), "replacement incarnation")
                        .and_then(|old| mapped_incarnation(&transaction, id, &old))
                })
                .transpose()?;
            transaction.execute("INSERT INTO lifecycle_receipts(operation_id,action,expected_public_id,expected_incarnation,replacement_incarnation,charge) VALUES(?1,?2,?3,?4,?5,?6)",params![op,action,id,new_expected.as_slice(),new_replacement.as_ref().map(|v|v.as_slice()),charge]).map_err(|e|map_sql_write("insert restored receipt",e))?;
        }
        transaction
            .commit()
            .map_err(|e| map_sql_write("commit receipt page", e))?;
        after = batch.last().unwrap().0.clone();
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn snapshot_schema_present(source: &Connection) -> RestoreResult<bool> {
    let count: u32 = source
        .query_row(
            "SELECT count(*) FROM sqlite_schema WHERE type='table' AND name IN ('snapshot_metadata','snapshots','snapshot_chunks')",
            [],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("inspect snapshot schema: {error}")))?;
    match count {
        0 => Ok(false),
        3 => Ok(true),
        _ => Err(RestoreError::CorruptBackup(
            "snapshot schema is only partially present".into(),
        )),
    }
}

#[cfg(not(feature = "snapshots"))]
fn import_snapshots(
    source: &Connection,
    _target: &mut Connection,
    _config: &RestoreConfig,
) -> RestoreResult<()> {
    if snapshot_schema_present(source)? {
        return Err(RestoreError::UnsupportedBackup(2));
    }
    Ok(())
}

#[cfg(feature = "snapshots")]
fn import_snapshots(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    if !snapshot_schema_present(source)? {
        return Ok(());
    }
    super::sqlite_snapshot::validate_snapshot_counters(source).map_err(|error| {
        RestoreError::CorruptBackup(format!("invalid snapshot accounting: {error}"))
    })?;

    let mut after: Option<[u8; 16]> = None;
    loop {
        let mut statement = source.prepare(
            "SELECT CASE WHEN typeof(snapshot_id)='blob' AND length(snapshot_id)=16 THEN snapshot_id END,
                    CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                    CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END,
                    CASE WHEN typeof(covered)='blob' AND length(covered)=8 THEN covered END,
                    CASE WHEN typeof(schema_id)='text' AND octet_length(schema_id) BETWEEN 1 AND 256 THEN schema_id END,
                    CASE WHEN typeof(schema_version)='integer' THEN schema_version END,
                    CASE WHEN typeof(content_bytes)='blob' AND length(content_bytes)=8 THEN content_bytes END,
                    CASE WHEN typeof(digest)='blob' AND length(digest)=32 THEN digest END,
                    CASE WHEN typeof(state)='integer' AND state BETWEEN 0 AND 4 THEN state END,
                    CASE WHEN typeof(accepted_bytes)='blob' AND length(accepted_bytes)=8 THEN accepted_bytes END,
                    CASE WHEN typeof(verified_bytes)='blob' AND length(verified_bytes)=8 THEN verified_bytes END,
                    CASE WHEN typeof(checksum_failed)='integer' AND checksum_failed IN (0,1) THEN checksum_failed END,
                    CASE WHEN typeof(cleaned)='integer' AND cleaned IN (0,1) THEN cleaned END,
                    CASE WHEN typeof(descriptor_charge)='integer' AND descriptor_charge>=0 THEN descriptor_charge END,
                    CASE WHEN typeof(receipt_reserved)='integer' AND receipt_reserved IN (0,1) THEN receipt_reserved END
             FROM snapshots WHERE (?1 IS NULL OR snapshot_id>?1) ORDER BY snapshot_id LIMIT ?2",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare snapshots: {error}")))?;
        let limit =
            i64::try_from(config.page.max_records).map_err(|_| RestoreError::CapacityExceeded)?;
        let mut rows = statement
            .query(params![after.as_ref().map(|value| value.as_slice()), limit])
            .map_err(|error| RestoreError::CorruptBackup(format!("query snapshots: {error}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut batch_bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step snapshots: {error}")))?
        {
            let id = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(0).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read snapshot ID: {error}"))
                })?,
                "snapshot ID",
            )?;
            let public_id: Option<String> = row.get(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot stream: {error}"))
            })?;
            let public_id = public_id
                .ok_or_else(|| RestoreError::CorruptBackup("invalid snapshot stream".into()))?;
            let old_incarnation = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(2).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read snapshot incarnation: {error}"))
                })?,
                "snapshot incarnation",
            )?;
            let new_incarnation = mapped_incarnation(target, &public_id, &old_incarnation)?;
            let covered = fixed::<8>(
                row.get::<_, Option<Vec<u8>>>(3).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read snapshot cursor: {error}"))
                })?,
                "snapshot cursor",
            )?;
            let schema_id: Option<String> = row.get(4).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot schema: {error}"))
            })?;
            let schema_id = schema_id
                .ok_or_else(|| RestoreError::CorruptBackup("invalid snapshot schema".into()))?;
            let values = (
                row.get::<_, Option<i64>>(5)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!(
                            "read snapshot schema version: {error}"
                        ))
                    })?
                    .ok_or_else(|| {
                        RestoreError::CorruptBackup("invalid snapshot schema version".into())
                    })?,
                fixed::<8>(
                    row.get::<_, Option<Vec<u8>>>(6).map_err(|error| {
                        RestoreError::CorruptBackup(format!("read snapshot length: {error}"))
                    })?,
                    "snapshot length",
                )?,
                fixed::<32>(
                    row.get::<_, Option<Vec<u8>>>(7).map_err(|error| {
                        RestoreError::CorruptBackup(format!("read snapshot digest: {error}"))
                    })?,
                    "snapshot digest",
                )?,
                row.get::<_, Option<i64>>(8)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!("read snapshot state: {error}"))
                    })?
                    .ok_or_else(|| RestoreError::CorruptBackup("invalid snapshot state".into()))?,
                fixed::<8>(
                    row.get::<_, Option<Vec<u8>>>(9).map_err(|error| {
                        RestoreError::CorruptBackup(format!("read accepted bytes: {error}"))
                    })?,
                    "accepted bytes",
                )?,
                fixed::<8>(
                    row.get::<_, Option<Vec<u8>>>(10).map_err(|error| {
                        RestoreError::CorruptBackup(format!("read verified bytes: {error}"))
                    })?,
                    "verified bytes",
                )?,
                row.get::<_, Option<i64>>(11)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!("read checksum state: {error}"))
                    })?
                    .ok_or_else(|| RestoreError::CorruptBackup("invalid checksum state".into()))?,
                row.get::<_, Option<i64>>(12)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!("read cleaned state: {error}"))
                    })?
                    .ok_or_else(|| RestoreError::CorruptBackup("invalid cleaned state".into()))?,
                row.get::<_, Option<i64>>(13)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!("read descriptor charge: {error}"))
                    })?
                    .ok_or_else(|| {
                        RestoreError::CorruptBackup("invalid descriptor charge".into())
                    })?,
                row.get::<_, Option<i64>>(14)
                    .map_err(|error| {
                        RestoreError::CorruptBackup(format!("read receipt reservation: {error}"))
                    })?
                    .ok_or_else(|| {
                        RestoreError::CorruptBackup("invalid receipt reservation".into())
                    })?,
            );
            let charge = public_id
                .len()
                .checked_add(schema_id.len())
                .and_then(|value| value.checked_add(256))
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if batch_bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                break;
            }
            batch_bytes += charge;
            batch.push((id, public_id, new_incarnation, covered, schema_id, values));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin snapshot descriptor page", error))?;
        for (id, public_id, incarnation, covered, schema_id, values) in &batch {
            transaction.execute(
                "INSERT INTO snapshots VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15)",
                params![id.as_slice(), public_id, incarnation.as_slice(), covered.as_slice(), schema_id, values.0, values.1.as_slice(), values.2.as_slice(), values.3, values.4.as_slice(), values.5.as_slice(), values.6, values.7, values.8, values.9],
            ).map_err(|error| map_sql_write("insert restored snapshot", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit snapshot descriptor page", error))?;
        after = Some(batch.last().expect("nonempty snapshot batch").0);
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }

    let mut after_id: Option<[u8; 16]> = None;
    let mut after_offset = [0_u8; 8];
    loop {
        let mut statement = source.prepare(
            "SELECT CASE WHEN typeof(snapshot_id)='blob' AND length(snapshot_id)=16 THEN snapshot_id END,
                    CASE WHEN typeof(offset)='blob' AND length(offset)=8 THEN offset END,
                    CASE WHEN typeof(bytes)='blob' AND octet_length(bytes)<=?3 THEN bytes END
             FROM snapshot_chunks
             WHERE ?1 IS NULL OR snapshot_id>?1 OR (snapshot_id=?1 AND offset>?2)
             ORDER BY snapshot_id,offset LIMIT ?4",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare snapshot chunks: {error}")))?;
        let mut rows = statement
            .query(params![
                after_id.as_ref().map(|value| value.as_slice()),
                after_offset.as_slice(),
                i64::try_from(config.page.max_bytes).map_err(|_| RestoreError::CapacityExceeded)?,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("query snapshot chunks: {error}"))
            })?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows.next().map_err(|error| {
            RestoreError::CorruptBackup(format!("step snapshot chunks: {error}"))
        })? {
            let id = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(0).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read chunk snapshot ID: {error}"))
                })?,
                "chunk snapshot ID",
            )?;
            let offset = fixed::<8>(
                row.get::<_, Option<Vec<u8>>>(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read chunk offset: {error}"))
                })?,
                "chunk offset",
            )?;
            let data: Option<Vec<u8>> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot chunk: {error}"))
            })?;
            let data =
                data.ok_or_else(|| RestoreError::CorruptBackup("invalid snapshot chunk".into()))?;
            let charge = data
                .len()
                .checked_add(64)
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                break;
            }
            bytes += charge;
            batch.push((id, offset, data));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin snapshot chunk page", error))?;
        for (id, offset, data) in &batch {
            transaction
                .execute(
                    "INSERT INTO snapshot_chunks VALUES(?1,?2,?3)",
                    params![id.as_slice(), offset.as_slice(), data],
                )
                .map_err(|error| map_sql_write("insert restored snapshot chunk", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit snapshot chunk page", error))?;
        let last = batch.last().expect("nonempty chunk batch");
        after_id = Some(last.0);
        after_offset = last.1;
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }

    let counters: (i64,i64,i64,i64,i64,i64,i64,i64,i64) = source.query_row(
        "SELECT staged_count,staged_bytes,published_count,published_bytes,chunk_count,chunk_metadata_bytes,descriptor_metadata_bytes,receipt_count,receipt_bytes FROM snapshot_metadata WHERE singleton=1",
        [], |row| Ok((row.get(0)?,row.get(1)?,row.get(2)?,row.get(3)?,row.get(4)?,row.get(5)?,row.get(6)?,row.get(7)?,row.get(8)?)),
    ).map_err(|error| RestoreError::CorruptBackup(format!("read snapshot counters: {error}")))?;
    target.execute("UPDATE snapshot_metadata SET staged_count=?1,staged_bytes=?2,published_count=?3,published_bytes=?4,chunk_count=?5,chunk_metadata_bytes=?6,descriptor_metadata_bytes=?7,receipt_count=?8,receipt_bytes=?9 WHERE singleton=1", params![counters.0,counters.1,counters.2,counters.3,counters.4,counters.5,counters.6,counters.7,counters.8]).map_err(|error| map_sql_write("copy snapshot counters", error))?;
    validate_restored_snapshot_semantics(target, config)?;
    super::sqlite_snapshot::validate_snapshot_counters(target).map_err(|error| {
        RestoreError::CorruptBackup(format!("restored snapshot accounting is invalid: {error}"))
    })?;
    Ok(())
}

#[cfg(feature = "snapshots")]
fn validate_restored_snapshot_semantics(
    target: &Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut statement = target
        .prepare(
            "SELECT snapshot_id,public_id,incarnation,covered,schema_id,schema_version,
                content_bytes,digest,state,accepted_bytes,verified_bytes,checksum_failed,
                cleaned,descriptor_charge,receipt_reserved
         FROM snapshots ORDER BY snapshot_id",
        )
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("prepare restored snapshot validation: {error}"))
        })?;
    let mut rows = statement.query([]).map_err(|error| {
        RestoreError::CorruptBackup(format!("query restored snapshots: {error}"))
    })?;
    while let Some(row) = rows
        .next()
        .map_err(|error| RestoreError::CorruptBackup(format!("step restored snapshots: {error}")))?
    {
        let id = fixed::<16>(
            Some(row.get::<_, Vec<u8>>(0).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot ID: {error}"))
            })?),
            "snapshot ID",
        )?;
        let public: String = row.get(1).map_err(|error| {
            RestoreError::CorruptBackup(format!("read snapshot stream: {error}"))
        })?;
        let incarnation = fixed::<16>(
            Some(row.get::<_, Vec<u8>>(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot incarnation: {error}"))
            })?),
            "snapshot incarnation",
        )?;
        let covered = decode_restore_u64(
            row.get(3).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot cursor: {error}"))
            })?,
            "snapshot cursor",
        )?;
        let schema: String = row.get(4).map_err(|error| {
            RestoreError::CorruptBackup(format!("read snapshot schema: {error}"))
        })?;
        let version: i64 = row.get(5).map_err(|error| {
            RestoreError::CorruptBackup(format!("read snapshot schema version: {error}"))
        })?;
        u32::try_from(version).map_err(|_| {
            RestoreError::CorruptBackup("snapshot schema version is out of range".into())
        })?;
        let content = decode_restore_u64(
            row.get(6).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot length: {error}"))
            })?,
            "snapshot length",
        )?;
        let digest = fixed::<32>(
            Some(row.get::<_, Vec<u8>>(7).map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot digest: {error}"))
            })?),
            "snapshot digest",
        )?;
        let state: i64 = row.get(8).map_err(|error| {
            RestoreError::CorruptBackup(format!("read snapshot state: {error}"))
        })?;
        let accepted = decode_restore_u64(
            row.get(9).map_err(|error| {
                RestoreError::CorruptBackup(format!("read accepted bytes: {error}"))
            })?,
            "accepted bytes",
        )?;
        let verified = decode_restore_u64(
            row.get(10).map_err(|error| {
                RestoreError::CorruptBackup(format!("read verified bytes: {error}"))
            })?,
            "verified bytes",
        )?;
        let checksum_failed: i64 = row.get(11).map_err(|error| {
            RestoreError::CorruptBackup(format!("read checksum state: {error}"))
        })?;
        let cleaned: i64 = row
            .get(12)
            .map_err(|error| RestoreError::CorruptBackup(format!("read cleaned state: {error}")))?;
        let charge: i64 = row.get(13).map_err(|error| {
            RestoreError::CorruptBackup(format!("read descriptor charge: {error}"))
        })?;
        let receipt: i64 = row
            .get(14)
            .map_err(|error| RestoreError::CorruptBackup(format!("read receipt state: {error}")))?;
        let expected_charge = public
            .len()
            .checked_add(schema.len())
            .and_then(|value| value.checked_add(SNAPSHOT_DESCRIPTOR_ENVELOPE_BYTES))
            .ok_or(RestoreError::CapacityExceeded)?;
        if charge != i64::try_from(expected_charge).map_err(|_| RestoreError::CapacityExceeded)?
            || accepted > content
            || verified > accepted
            || !(0..=4).contains(&state)
            || !(0..=1).contains(&checksum_failed)
            || !(0..=1).contains(&cleaned)
            || !(0..=1).contains(&receipt)
        {
            return Err(RestoreError::CorruptBackup(
                "snapshot progress metadata is inconsistent".into(),
            ));
        }
        let bounds: Option<(Vec<u8>, Vec<u8>)> = target
            .query_row(
                "SELECT floor,tail FROM event_streams WHERE public_id=?1 AND incarnation=?2",
                params![public, incarnation.as_slice()],
                |bounds| Ok((bounds.get(0)?, bounds.get(1)?)),
            )
            .optional()
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("read snapshot stream bounds: {error}"))
            })?;
        if let Some((floor, tail)) = bounds {
            decode_restore_u64(floor, "snapshot stream floor")?;
            if covered > decode_restore_u64(tail, "snapshot stream tail")? {
                return Err(RestoreError::CorruptBackup(
                    "snapshot cursor is outside its stream bounds".into(),
                ));
            }
        }

        let mut chunks_statement = target.prepare(
            "SELECT offset,CASE WHEN typeof(bytes)='blob' AND octet_length(bytes)<=?2 THEN bytes END
             FROM snapshot_chunks WHERE snapshot_id=?1 ORDER BY offset",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare restored snapshot chunks: {error}")))?;
        let mut chunks = chunks_statement
            .query(params![
                id.as_slice(),
                i64::try_from(config.page.max_bytes).map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("query restored snapshot chunks: {error}"))
            })?;
        let mut next = 0_u64;
        let mut saw_chunk = false;
        let mut hasher = Sha256::new();
        while let Some(chunk) = chunks.next().map_err(|error| {
            RestoreError::CorruptBackup(format!("step restored snapshot chunks: {error}"))
        })? {
            let offset = decode_restore_u64(
                chunk.get(0).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read chunk offset: {error}"))
                })?,
                "chunk offset",
            )?;
            let bytes: Option<Vec<u8>> = chunk.get(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read chunk bytes: {error}"))
            })?;
            let bytes = bytes.ok_or(RestoreError::CapacityExceeded)?;
            if !saw_chunk && state == 4 && cleaned == 0 {
                next = offset;
            }
            if bytes.is_empty() || offset != next {
                return Err(RestoreError::CorruptBackup(
                    "snapshot chunks are empty or noncontiguous".into(),
                ));
            }
            saw_chunk = true;
            next = next
                .checked_add(bytes.len() as u64)
                .ok_or(RestoreError::CapacityExceeded)?;
            if next > accepted {
                return Err(RestoreError::CorruptBackup(
                    "snapshot chunks exceed accepted bytes".into(),
                ));
            }
            hasher.update(&bytes);
        }
        if cleaned == 1 {
            if state != 4 || accepted != 0 || verified != 0 || next != 0 || receipt != 1 {
                return Err(RestoreError::CorruptBackup(
                    "cleaned snapshot receipt is inconsistent".into(),
                ));
            }
        } else if next != accepted && !(state == 4 && !saw_chunk) {
            return Err(RestoreError::CorruptBackup(
                "snapshot chunks do not cover accepted bytes".into(),
            ));
        }
        if state == 2 || state == 3 {
            if accepted != content
                || verified != content
                || checksum_failed != 0
                || cleaned != 0
                || hasher.finalize().as_slice() != digest
            {
                return Err(RestoreError::CorruptBackup(
                    "published or verified snapshot has invalid content".into(),
                ));
            }
        } else if state == 0 && verified != 0 {
            return Err(RestoreError::CorruptBackup(
                "uploading snapshot has verified bytes".into(),
            ));
        } else if state == 4 && receipt != 1 {
            return Err(RestoreError::CorruptBackup(
                "aborted snapshot is missing its durable receipt".into(),
            ));
        }
    }
    Ok(())
}

#[cfg(feature = "snapshots")]
fn decode_restore_u64(value: Vec<u8>, label: &str) -> RestoreResult<u64> {
    Ok(u64::from_be_bytes(fixed::<8>(Some(value), label)?))
}

fn validate_import(target: &Connection) -> RestoreResult<()> {
    validate_lifecycle_counters(target).map_err(map_store_error)?;
    let foreign_violation: bool = target
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
            [],
            |row| row.get(0),
        )
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("validate restored foreign keys: {error}"))
        })?;
    if foreign_violation {
        return Err(RestoreError::CorruptBackup(
            "restored database contains a foreign-key violation".into(),
        ));
    }
    let quick: String = target
        .query_row("PRAGMA quick_check", [], |row| row.get(0))
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("validate restored SQLite: {error}"))
        })?;
    if quick != "ok" {
        return Err(RestoreError::CorruptBackup(format!(
            "restored SQLite quick_check failed: {quick}"
        )));
    }
    Ok(())
}

fn complete_staging(
    target: &mut Connection,
    request: &RestoreRequest,
    destination: &Path,
) -> RestoreResult<()> {
    let destination = destination
        .to_str()
        .ok_or_else(|| RestoreError::InvalidConfig("canonical destination must be UTF-8".into()))?;
    let transaction = target
        .transaction_with_behavior(TransactionBehavior::Immediate)
        .map_err(|error| map_sql_write("begin staging completion", error))?;
    let matches: bool = transaction
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM restore_metadata WHERE singleton=1 AND operation_id=?1 AND backup_identity=?2 AND destination=?3)",
            params![request.operation_id.as_str(),request.backup_identity.0.as_slice(),destination],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("validate restore identity: {error}")))?;
    if !matches {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    }
    transaction
        .execute("DROP TABLE restore_lifetime_keys", [])
        .map_err(|error| map_sql_write("drop staging key map", error))?;
    transaction
        .execute(
            "UPDATE event_stream_metadata SET restore_incomplete=2 WHERE singleton=1 AND restore_incomplete=1",
            [],
        )
        .map_err(|error| map_sql_write("mark restore complete", error))?;
    transaction
        .commit()
        .map_err(|error| map_sql_write("commit staging completion", error))
}

fn read_published_receipt(
    destination: &Path,
    request: &RestoreRequest,
    recover_publication: bool,
) -> RestoreResult<RestoreReceipt> {
    let conn = open_read_only(destination)?;
    let row: Option<(Option<i64>, Option<i64>)> = conn
        .query_row(
            "SELECT CASE WHEN typeof(mapping_count)='integer' AND mapping_count>=0 THEN mapping_count END,
                    CASE WHEN typeof(restore_incomplete)='integer' AND restore_incomplete BETWEEN 0 AND 2 THEN restore_incomplete END
             FROM restore_metadata,event_stream_metadata
             WHERE restore_metadata.singleton=1 AND event_stream_metadata.singleton=1
               AND operation_id=?1 AND backup_identity=?2 AND destination=?3",
            params![
                request.operation_id.as_str(),
                request.backup_identity.0.as_slice(),
                destination.to_str()
            ],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()
        .map_err(|_| RestoreError::DestinationExists(Box::new(destination.to_owned())))?;
    let Some((mapping_count, state)) = row else {
        let same_operation: bool = conn
            .query_row(
                "SELECT EXISTS(SELECT 1 FROM restore_metadata WHERE operation_id=?1)",
                params![request.operation_id.as_str()],
                |row| row.get(0),
            )
            .unwrap_or(false);
        if same_operation {
            return Err(RestoreError::RequestConflict {
                operation_id: request.operation_id.clone(),
            });
        }
        return Err(RestoreError::DestinationExists(Box::new(
            destination.to_owned(),
        )));
    };
    let mapping_count =
        mapping_count.ok_or_else(|| RestoreError::CorruptBackup("invalid mapping count".into()))?;
    let state = state.ok_or_else(|| RestoreError::CorruptBackup("invalid restore state".into()))?;
    if recover_publication {
        validate_mapping_count(&conn, mapping_count)?;
    }
    drop(conn);
    match state {
        0 => {
            let conn = open_read_only(destination)?;
            if inspect_existing_format(&conn).map_err(map_store_error)? != Some(2) {
                return Err(RestoreError::CorruptBackup(
                    "published restore format is invalid".into(),
                ));
            }
            if recover_publication {
                validate_lifecycle_counters(&conn).map_err(map_store_error)?;
            }
        }
        2 if recover_publication => {
            let conn = open_read_only(destination)?;
            inspect_restore_format(&conn, 2).map_err(map_store_error)?;
            validate_lifecycle_counters(&conn).map_err(map_store_error)?;
            let quick: String = conn
                .query_row("PRAGMA quick_check", [], |row| row.get(0))
                .map_err(|error| {
                    RestoreError::CorruptBackup(format!(
                        "check completed restore before publication recovery: {error}"
                    ))
                })?;
            if quick != "ok" {
                return Err(RestoreError::CorruptBackup(
                    "completed restore failed integrity validation".into(),
                ));
            }
            let foreign_violation: bool = conn
                .query_row(
                    "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
                    [],
                    |row| row.get(0),
                )
                .map_err(|error| {
                    RestoreError::CorruptBackup(format!(
                        "check completed restore references: {error}"
                    ))
                })?;
            if foreign_violation {
                return Err(RestoreError::CorruptBackup(
                    "completed restore has a foreign-key violation".into(),
                ));
            }
            drop(conn);
            finalize_published_marker(destination).map_err(|_| {
                RestoreError::PublicationUnknown {
                    operation_id: request.operation_id.clone(),
                    destination: Box::new(destination.to_owned()),
                }
            })?;
        }
        _ => {
            return Err(RestoreError::PublicationUnknown {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination.to_owned()),
            })
        }
    }
    Ok(RestoreReceipt {
        operation_id: request.operation_id.clone(),
        backup_identity: request.backup_identity,
        destination: destination.to_owned(),
        mapping_count: u64::try_from(mapping_count)
            .map_err(|_| RestoreError::CorruptBackup("invalid mapping count".into()))?,
    })
}

fn validate_staging_owner(
    staging: &Path,
    request: &RestoreRequest,
    destination: &Path,
) -> RestoreResult<bool> {
    validate_staging_file_boundary(staging)?;
    // A failed import can leave a hot DELETE journal. Validation owns the
    // deterministic staging name, so it opens read-write to let SQLite roll
    // that transaction back before reading the last committed owner marker.
    let conn = Connection::open_with_flags(
        staging,
        OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| {
        RestoreError::CorruptBackup(format!("recover staging for validation: {error}"))
    })?;
    let row: Option<i64> = conn
        .query_row(
            "SELECT restore_incomplete FROM restore_metadata,event_stream_metadata
             WHERE restore_metadata.singleton=1 AND event_stream_metadata.singleton=1
               AND operation_id=?1 AND backup_identity=?2 AND destination=?3",
            params![
                request.operation_id.as_str(),
                request.backup_identity.0.as_slice(),
                destination.to_str()
            ],
            |row| row.get(0),
        )
        .optional()
        .map_err(|error| RestoreError::CorruptBackup(format!("read staging identity: {error}")))?;
    let Some(incomplete) = row else {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    };
    if !matches!(incomplete, 1 | 2) {
        return Err(RestoreError::CorruptBackup("invalid staging state".into()));
    }
    Ok(incomplete == 1)
}

fn validate_stored_mapping_count(conn: &Connection) -> RestoreResult<()> {
    let expected: Option<i64> = conn
        .query_row(
            "SELECT CASE WHEN typeof(mapping_count)='integer' AND mapping_count>=0 THEN mapping_count END
             FROM restore_metadata WHERE singleton=1",
            [],
            |row| row.get(0),
        )
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("read restored mapping count: {error}"))
        })?;
    validate_mapping_count(
        conn,
        expected.ok_or_else(|| RestoreError::CorruptBackup("invalid mapping count".into()))?,
    )
}

fn validate_mapping_count(conn: &Connection, expected: i64) -> RestoreResult<()> {
    let actual: i64 = conn
        .query_row("SELECT COUNT(*) FROM restore_mappings", [], |row| {
            row.get(0)
        })
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("count restored mappings: {error}"))
        })?;
    if actual != expected {
        return Err(RestoreError::CorruptBackup(
            "restore mapping count does not match mapping rows".into(),
        ));
    }
    Ok(())
}

fn validate_staging_file_boundary(staging: &Path) -> RestoreResult<()> {
    let metadata = std::fs::symlink_metadata(staging).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect restore staging file: {error}"))
    })?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(RestoreError::StagingCleanupFailed {
            paths: vec![staging.to_owned()],
        });
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        if metadata.nlink() != 1 {
            return Err(RestoreError::StagingCleanupFailed {
                paths: vec![staging.to_owned()],
            });
        }
    }
    Ok(())
}

fn publish_no_replace(
    staging: &Path,
    destination: &Path,
    request: &RestoreRequest,
    failure: &AtomicU8,
    pause_marker: Option<&Path>,
) -> RestoreResult<()> {
    match std::fs::hard_link(staging, destination) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
            return Err(RestoreError::DestinationExists(Box::new(
                destination.to_owned(),
            )))
        }
        Err(error) => {
            return Err(RestoreError::StorageFailure(format!(
                "publish destination without replacement: {error}"
            )))
        }
    }
    if consume_or_pause(
        failure,
        SqliteRestoreFailureInjection::AfterDestinationLink,
        pause_marker,
    ) {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if sync_file(destination).is_err()
        || sync_directory(destination.parent().unwrap()).is_err()
        || finalize_published_marker(destination).is_err()
    {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if consume_or_pause(
        failure,
        SqliteRestoreFailureInjection::AfterPublishedMarker,
        pause_marker,
    ) {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if std::fs::remove_file(staging).is_err()
        || sync_directory(destination.parent().unwrap()).is_err()
    {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    remove_owner_files(destination, request).map_err(|_| RestoreError::PublicationUnknown {
        operation_id: request.operation_id.clone(),
        destination: Box::new(destination.to_owned()),
    })?;
    Ok(())
}

fn consume_or_pause(
    failure: &AtomicU8,
    expected: SqliteRestoreFailureInjection,
    pause_marker: Option<&Path>,
) -> bool {
    let consumed = failure
        .compare_exchange(expected as u8 + 1, 0, Ordering::AcqRel, Ordering::Acquire)
        .is_ok();
    if consumed {
        #[cfg(feature = "test-support")]
        if let Some(marker) = pause_marker {
            let file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(marker)
                .expect("test-only restore pause marker must be creatable");
            file.sync_all()
                .expect("test-only restore pause marker must be durable");
            loop {
                std::thread::park();
            }
        }
        #[cfg(not(feature = "test-support"))]
        let _ = pause_marker;
    }
    consumed
}

fn finalize_published_marker(destination: &Path) -> RestoreResult<()> {
    let conn = Connection::open_with_flags(
        destination,
        OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::StorageFailure(format!("open published restore: {error}")))?;
    let changed = conn
        .execute(
            "UPDATE event_stream_metadata SET restore_incomplete=0 WHERE singleton=1 AND restore_incomplete=2",
            [],
        )
        .map_err(|error| map_sql_write("mark restore published", error))?;
    if changed != 1 {
        let state: i64 = conn
            .query_row(
                "SELECT restore_incomplete FROM event_stream_metadata WHERE singleton=1",
                [],
                |row| row.get(0),
            )
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("read publication state: {error}"))
            })?;
        if state != 0 {
            return Err(RestoreError::CorruptBackup(
                "published restore has an invalid state".into(),
            ));
        }
    }
    conn.close().map_err(|(_, error)| {
        RestoreError::StorageFailure(format!("close published restore: {error}"))
    })?;
    sync_file(destination)
}

fn finish_staging_alias_if_owned(
    staging: &Path,
    destination: &Path,
    request: &RestoreRequest,
) -> RestoreResult<()> {
    if !staging.exists() {
        return remove_owner_files(destination, request).map_err(|_| {
            RestoreError::PublicationUnknown {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination.to_owned()),
            }
        });
    }
    if same_file(staging, destination)? {
        std::fs::remove_file(staging).map_err(|_| RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        })?;
        sync_directory(destination.parent().unwrap()).map_err(|_| {
            RestoreError::PublicationUnknown {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination.to_owned()),
            }
        })?;
        remove_owner_files(destination, request).map_err(|_| RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        })?;
        return Ok(());
    }
    Err(RestoreError::IncompleteStaging {
        operation_id: request.operation_id.clone(),
        destination: Box::new(destination.to_owned()),
    })
}

#[cfg(unix)]
fn same_file(left: &Path, right: &Path) -> RestoreResult<bool> {
    use std::os::unix::fs::MetadataExt;
    let left = std::fs::metadata(left)
        .map_err(|error| RestoreError::StorageFailure(format!("inspect staging alias: {error}")))?;
    let right = std::fs::metadata(right).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect destination alias: {error}"))
    })?;
    Ok(left.dev() == right.dev() && left.ino() == right.ino())
}

#[cfg(not(unix))]
fn same_file(_left: &Path, _right: &Path) -> RestoreResult<bool> {
    Ok(false)
}

fn sync_file(path: &Path) -> RestoreResult<()> {
    OpenOptions::new()
        .read(true)
        .write(true)
        .open(path)
        .and_then(|file| file.sync_all())
        .map_err(|error| {
            RestoreError::StorageFailure(format!("synchronize {}: {error}", path.display()))
        })
}

fn sync_directory(path: &Path) -> RestoreResult<()> {
    File::open(path)
        .and_then(|file| file.sync_all())
        .map_err(|error| {
            RestoreError::StorageFailure(format!(
                "synchronize directory {}: {error}",
                path.display()
            ))
        })
}

fn read_mapping_blocking(
    root: &Path,
    receipt: &RestoreReceipt,
    after: Option<&StreamKey>,
    limits: PageLimits,
    _config: &RestoreConfig,
) -> RestoreResult<MappingPage> {
    let destination = resolve_receipt_destination(root, &receipt.destination)?;
    let _ownership = Ownership::acquire(&destination).map_err(map_store_error)?;
    let request = RestoreRequest {
        operation_id: receipt.operation_id.clone(),
        backup_identity: receipt.backup_identity,
        source: PathBuf::from("unused-for-mapping"),
        destination: destination.clone(),
    };
    let stored = read_published_receipt(&destination, &request, false)?;
    if &stored != receipt {
        return Err(RestoreError::RequestConflict {
            operation_id: receipt.operation_id.clone(),
        });
    }
    let conn = open_read_only(&destination)?;
    let (after_id, after_incarnation) = after
        .map(|key| (key.id.as_str(), key.incarnation.0))
        .unwrap_or(("", [0; 16]));
    let mut statement = conn
        .prepare(
            "SELECT CASE WHEN typeof(old_public_id)='text' AND octet_length(old_public_id) BETWEEN 1 AND 256 THEN old_public_id END,
                    CASE WHEN typeof(old_incarnation)='blob' AND length(old_incarnation)=16 THEN old_incarnation END,
                    CASE WHEN typeof(new_incarnation)='blob' AND length(new_incarnation)=16 THEN new_incarnation END
             FROM restore_mappings
         WHERE (old_public_id,old_incarnation)>(?1,?2)
         ORDER BY old_public_id,old_incarnation LIMIT ?3",
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("prepare mapping page: {error}")))?;
    let mut rows = statement
        .query(params![
            after_id,
            after_incarnation.as_slice(),
            i64::try_from(limits.max_records).map_err(|_| RestoreError::CapacityExceeded)?
        ])
        .map_err(|error| RestoreError::CorruptBackup(format!("query mapping page: {error}")))?;
    let mut entries = Vec::with_capacity(limits.max_records.min(256));
    let mut bytes = 0usize;
    while let Some(row) = rows
        .next()
        .map_err(|error| RestoreError::CorruptBackup(format!("step mapping page: {error}")))?
    {
        let id: Option<String> = row
            .get(0)
            .map_err(|error| RestoreError::CorruptBackup(format!("read mapped name: {error}")))?;
        let old = fixed::<16>(
            row.get::<_, Option<Vec<u8>>>(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read old mapping: {error}"))
            })?,
            "old mapping",
        )?;
        let new = fixed::<16>(
            row.get::<_, Option<Vec<u8>>>(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read new mapping: {error}"))
            })?,
            "new mapping",
        )?;
        if old == new {
            return Err(RestoreError::CorruptBackup(
                "restored incarnation was not refreshed".into(),
            ));
        }
        let id = StreamId::new(
            id.ok_or_else(|| RestoreError::CorruptBackup("invalid mapping name".into()))?,
        )
        .map_err(|_| RestoreError::CorruptBackup("invalid mapping name".into()))?;
        let entry = IncarnationMapping {
            old: StreamKey {
                id: id.clone(),
                incarnation: IncarnationId(old),
            },
            new: StreamKey {
                id,
                incarnation: IncarnationId(new),
            },
        };
        let charge = entry
            .accounted_bytes()
            .ok_or(RestoreError::CapacityExceeded)?;
        if entries.is_empty() && charge > limits.max_bytes {
            return Err(RestoreError::CapacityExceeded);
        }
        if bytes
            .checked_add(charge)
            .is_none_or(|v| v > limits.max_bytes)
        {
            break;
        }
        bytes += charge;
        entries.push(entry);
    }
    drop(rows);
    drop(statement);
    let next_after = entries.last().map(|entry| entry.old.clone());
    let complete=match &next_after {
        None=>true,
        Some(last)=>!conn.query_row("SELECT EXISTS(SELECT 1 FROM restore_mappings WHERE (old_public_id,old_incarnation)>(?1,?2))",params![last.id.as_str(),last.incarnation.0.as_slice()],|r|r.get::<_,bool>(0)).map_err(|e|RestoreError::CorruptBackup(format!("check mapping completion: {e}")))?,
    };
    Ok(MappingPage {
        entries,
        next_after,
        complete,
    })
}

fn resolve_receipt_destination(root: &Path, path: &Path) -> RestoreResult<PathBuf> {
    if !path.is_absolute() {
        return resolve_destination(root, path);
    }
    let name = path.file_name().ok_or_else(|| {
        RestoreError::InvalidConfig("mapping destination needs a file name".into())
    })?;
    let parent = path
        .parent()
        .ok_or_else(|| RestoreError::InvalidConfig("mapping destination has no parent".into()))?
        .canonicalize()
        .map_err(|error| {
            RestoreError::InvalidConfig(format!("mapping destination parent: {error}"))
        })?;
    if !parent.starts_with(root) {
        return Err(RestoreError::InvalidConfig(
            "mapping destination escapes root".into(),
        ));
    }
    Ok(parent.join(name))
}

fn cleanup_staging_blocking(
    root: &Path,
    request: &RestoreRequest,
    _config: &RestoreConfig,
    failure: &AtomicU8,
) -> RestoreResult<()> {
    #[cfg(not(feature = "test-support"))]
    let _ = failure;
    let destination = resolve_destination(root, &request.destination)?;
    let _ownership =
        Ownership::acquire_restore_destination(&destination).map_err(map_store_error)?;
    let staging = staging_path(&destination, request)?;
    let staging_present = path_entry_exists(&staging)?;
    let owner = owner_path(&destination, &request.operation_id);
    let binding = owner.join(format!("request-{}", request_hash(&destination, request)));
    if destination.exists() {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination),
        });
    }
    if !path_entry_exists(&owner)? {
        if staging_present {
            validate_staging_owner(&staging, request, &destination)?;
        } else {
            return Ok(());
        }
    } else {
        let metadata = std::fs::symlink_metadata(&owner).map_err(|error| {
            RestoreError::StorageFailure(format!("inspect restore owner directory: {error}"))
        })?;
        if metadata.file_type().is_symlink() || !metadata.is_dir() {
            return Err(RestoreError::StagingCleanupFailed {
                paths: vec![owner.clone()],
            });
        }
        let entries = bounded_directory_entries(&owner)?;
        if entries.len() > 1 || entries.first().is_some_and(|path| path != &binding) {
            return Err(RestoreError::RequestConflict {
                operation_id: request.operation_id.clone(),
            });
        }
        if entries.is_empty() && staging_present {
            return Err(RestoreError::StagingCleanupFailed {
                paths: vec![staging],
            });
        }
        if path_entry_exists(&binding)? {
            let metadata = std::fs::symlink_metadata(&binding).map_err(|error| {
                RestoreError::StorageFailure(format!("inspect restore request binding: {error}"))
            })?;
            if metadata.file_type().is_symlink() || !metadata.is_dir() {
                return Err(RestoreError::StagingCleanupFailed {
                    paths: vec![binding.clone()],
                });
            }
            let unexpected = bounded_directory_entries(&binding)?;
            if !unexpected.is_empty() {
                return Err(RestoreError::StagingCleanupFailed { paths: unexpected });
            }
        }
        if staging_present {
            validate_staging_file_boundary(&staging)?;
            if std::fs::symlink_metadata(&staging)
                .map_err(|error| {
                    RestoreError::StorageFailure(format!(
                        "inspect owned restore staging file: {error}"
                    ))
                })?
                .len()
                > 0
            {
                validate_staging_owner(&staging, request, &destination)?;
            }
        }
    }
    let mut failed = Vec::new();
    for path in [
        staging.clone(),
        PathBuf::from(format!("{}-journal", staging.display())),
        PathBuf::from(format!("{}-wal", staging.display())),
        PathBuf::from(format!("{}-shm", staging.display())),
    ] {
        #[cfg(feature = "test-support")]
        if path == staging
            && consume_or_pause(
                failure,
                SqliteRestoreFailureInjection::DuringCleanupUnlink,
                None,
            )
        {
            failed.push(path);
            continue;
        }
        if let Err(error) = std::fs::remove_file(&path) {
            if error.kind() != std::io::ErrorKind::NotFound {
                failed.push(path)
            }
        }
    }
    if !failed.is_empty() {
        return Err(RestoreError::StagingCleanupFailed { paths: failed });
    }
    if let Err(error) = std::fs::remove_dir(&binding) {
        if error.kind() != std::io::ErrorKind::NotFound {
            return Err(RestoreError::StagingCleanupFailed {
                paths: vec![binding],
            });
        }
    }
    if let Err(error) = std::fs::remove_dir(&owner) {
        if error.kind() != std::io::ErrorKind::NotFound {
            return Err(RestoreError::StagingCleanupFailed { paths: vec![owner] });
        }
    }
    #[cfg(feature = "test-support")]
    if consume_or_pause(
        failure,
        SqliteRestoreFailureInjection::DuringCleanupDirectorySync,
        None,
    ) {
        return Err(RestoreError::StagingCleanupFailed {
            paths: vec![destination.parent().unwrap().to_owned()],
        });
    }
    sync_directory(destination.parent().unwrap())?;
    Ok(())
}
