use super::MemoryStore;
use crate::{application::*, domain::*};
use async_trait::async_trait;
use std::{collections::BTreeMap, sync::Arc};

const STORED_RECORD_OVERHEAD: usize = 256;
const RECEIPT_OVERHEAD: usize = 192;

#[derive(Debug)]
pub(super) struct MemoryOriginReplica {
    status: ReplicaStatus,
    max_backlog_bytes: u64,
    max_backlog_age: std::time::Duration,
    pending: Option<ReplicaBatch>,
}

#[derive(Clone, Debug)]
pub(super) enum MemoryOriginReceipt {
    Attach(AttachReplicaReceipt),
    Prepare(PrepareReplicaBatchReceipt),
    Acknowledge(AcknowledgeReplicaBatchReceipt),
    Detach(DetachReplicaReceipt),
}

fn record_charge(record: &Record) -> ReplicationResult<usize> {
    record
        .event
        .accounted_bytes()
        .checked_add(STORED_RECORD_OVERHEAD)
        .ok_or(ReplicationError::CapacityExceeded)
}

fn batch_payload_charge(batch: &ReplicaBatch) -> ReplicationResult<usize> {
    batch.records.iter().try_fold(0usize, |total, record| {
        total
            .checked_add(record_charge(record)?)
            .ok_or(ReplicationError::CapacityExceeded)
    })
}

fn batch_receipt_charge(batch: &ReplicaBatch) -> ReplicationResult<usize> {
    batch
        .records
        .len()
        .checked_mul(std::mem::size_of::<Arc<Record>>())
        .and_then(|bytes| {
            bytes.checked_add(
                batch
                    .after
                    .stream
                    .stream
                    .id
                    .as_str()
                    .len()
                    .saturating_mul(2),
            )
        })
        .and_then(|bytes| bytes.checked_add(RECEIPT_OVERHEAD))
        .ok_or(ReplicationError::CapacityExceeded)
}

fn validate_batch(
    batch: &ReplicaBatch,
    max_records: usize,
    max_bytes: usize,
) -> ReplicationResult<usize> {
    if batch.records.is_empty() || batch.records.len() > max_records {
        return Err(ReplicationError::InvalidInput(
            "replica batch record count is outside its finite limit".into(),
        ));
    }
    let bytes = batch_payload_charge(batch)?;
    if bytes > max_bytes {
        return Err(ReplicationError::CapacityExceeded);
    }
    for (index, record) in batch.records.iter().enumerate() {
        let distance = u64::try_from(index)
            .ok()
            .and_then(|index| index.checked_add(1))
            .ok_or_else(|| ReplicationError::InvalidInput("replica cursor overflow".into()))?;
        let expected = batch
            .after
            .offset
            .checked_add(distance)
            .ok_or_else(|| ReplicationError::InvalidInput("replica cursor overflow".into()))?;
        if record.cursor.version != CURSOR_VERSION
            || record.cursor.stream != batch.after.stream.stream
            || record.cursor.offset != expected
        {
            return Err(ReplicationError::InvalidInput(
                "replica batch must be a contiguous prefix for one exact stream lifetime".into(),
            ));
        }
    }
    Ok(bytes)
}

#[async_trait]
impl ReplicaBatchDestinationStore for MemoryStore {
    async fn destination_epoch(&self) -> ReplicationResult<DestinationEpoch> {
        let state = self
            .state
            .lock()
            .map_err(|_| ReplicationError::CorruptStorage("memory store lock poisoned".into()))?;
        if state.closed {
            return Err(ReplicationError::Closed);
        }
        Ok(state.replica_destination_epoch)
    }

    async fn commit_replica_batch(&self, batch: ReplicaBatch) -> ReplicationResult<ReplicaReceipt> {
        let bytes = validate_batch(
            &batch,
            self.options.replica_destination.storage.max_batch_records,
            self.options.replica_destination.storage.max_batch_bytes,
        )?;
        let mut state = self
            .state
            .lock()
            .map_err(|_| ReplicationError::CorruptStorage("memory store lock poisoned".into()))?;
        if state.closed {
            return Err(ReplicationError::Closed);
        }
        if batch.destination_epoch != state.replica_destination_epoch {
            return Err(ReplicationError::DestinationReplaced {
                current: state.replica_destination_epoch,
            });
        }
        if batch.after.offset
            < state
                .replica_receipt_floors
                .get(&batch.after.stream)
                .copied()
                .unwrap_or(0)
        {
            return Err(ReplicationError::ReceiptExpired);
        }
        if let Some((prior, receipt)) = state.replica_receipts.get(&batch.id) {
            if prior == &batch {
                return Ok(receipt.clone());
            }
            return Err(ReplicationError::BatchConflict { batch: batch.id });
        }
        let current = state
            .replica_histories
            .get(&batch.after.stream)
            .and_then(BTreeMap::last_key_value)
            .map_or(0, |(&offset, _)| offset);
        if current != batch.after.offset {
            return Err(ReplicationError::StaleProgress {
                current: Box::new(ReplicaPosition {
                    stream: batch.after.stream.clone(),
                    offset: current,
                }),
            });
        }
        let new_records = batch.records.len();
        let new_history_bytes = state
            .replica_history_bytes
            .checked_add(u64::try_from(bytes).map_err(|_| ReplicationError::CapacityExceeded)?)
            .ok_or(ReplicationError::CapacityExceeded)?;
        let receipt_bytes = batch_receipt_charge(&batch)?;
        if state.replica_histories.len()
            + usize::from(!state.replica_histories.contains_key(&batch.after.stream))
            > self.options.replica_destination.storage.max_origin_streams
            || state
                .replica_history_records
                .checked_add(new_records)
                .is_none_or(|n| n > self.options.replica_destination.storage.max_history_records)
            || new_history_bytes > self.options.replica_destination.storage.max_history_bytes
            || state
                .replica_receipts
                .len()
                .checked_add(state.replica_floor_receipts.len())
                .is_none_or(|rows| {
                    rows >= self.options.replica_destination.receipts.max_batch_receipts
                })
            || state
                .replica_receipt_bytes
                .checked_add(receipt_bytes)
                .is_none_or(|n| {
                    n > self
                        .options
                        .replica_destination
                        .receipts
                        .max_batch_receipt_bytes
                })
        {
            return Err(ReplicationError::CapacityExceeded);
        }
        let committed_through = ReplicaPosition {
            stream: batch.after.stream.clone(),
            offset: batch
                .records
                .last()
                .expect("nonempty validated batch")
                .cursor
                .offset,
        };
        let receipt = ReplicaReceipt {
            batch: batch.id,
            destination_epoch: batch.destination_epoch,
            committed_through,
        };
        let history = state
            .replica_histories
            .entry(batch.after.stream.clone())
            .or_default();
        for record in &batch.records {
            history.insert(record.cursor.offset, Arc::clone(record));
        }
        state.replica_history_records += new_records;
        state.replica_history_bytes = new_history_bytes;
        state.replica_receipt_bytes += receipt_bytes;
        let mut stored_records = Vec::with_capacity(batch.records.len());
        stored_records.extend(batch.records.iter().cloned());
        let stored_batch = ReplicaBatch {
            id: batch.id,
            destination_epoch: batch.destination_epoch,
            after: batch.after,
            records: stored_records,
        };
        state
            .replica_receipts
            .insert(stored_batch.id, (stored_batch, receipt.clone()));
        Ok(receipt)
    }

    async fn read_replica_after(
        &self,
        after: &ReplicaPosition,
        limits: ReplicaBatchLimits,
    ) -> ReplicationResult<ReplicaPage> {
        if limits.max_records == 0 || limits.max_bytes == 0 {
            return Err(ReplicationError::InvalidInput(
                "replica page limits must be nonzero".into(),
            ));
        }
        if limits.max_records > self.options.replica_destination.storage.max_batch_records
            || limits.max_bytes > self.options.replica_destination.storage.max_batch_bytes
        {
            return Err(ReplicationError::InvalidInput(
                "replica page limits exceed configured store limits".into(),
            ));
        }
        let state = self
            .state
            .lock()
            .map_err(|_| ReplicationError::CorruptStorage("memory store lock poisoned".into()))?;
        if state.closed {
            return Err(ReplicationError::Closed);
        }
        let history = state.replica_histories.get(&after.stream);
        let tail = history
            .and_then(BTreeMap::last_key_value)
            .map_or(0, |(&offset, _)| offset);
        if after.offset > tail {
            return Err(ReplicationError::StaleProgress {
                current: Box::new(ReplicaPosition {
                    stream: after.stream.clone(),
                    offset: tail,
                }),
            });
        }
        let mut records = Vec::new();
        let mut bytes = 0usize;
        if let Some(history) = history.filter(|_| after.offset < tail) {
            let first = after
                .offset
                .checked_add(1)
                .ok_or_else(|| ReplicationError::InvalidInput("replica cursor overflow".into()))?;
            for (&offset, record) in history.range(first..) {
                let charge = record_charge(record)?;
                if records.is_empty() && charge > limits.max_bytes {
                    return Err(ReplicationError::CapacityExceeded);
                }
                if records.len() == limits.max_records
                    || bytes
                        .checked_add(charge)
                        .is_none_or(|n| n > limits.max_bytes)
                {
                    break;
                }
                let expected = first
                    .checked_add(u64::try_from(records.len()).unwrap_or(u64::MAX))
                    .ok_or_else(|| {
                        ReplicationError::CorruptStorage("replica cursor overflow".into())
                    })?;
                if offset != expected {
                    return Err(ReplicationError::CorruptStorage(
                        "replica history contains a gap".into(),
                    ));
                }
                bytes += charge;
                records.push(Arc::clone(record));
            }
        }
        let next_offset = records
            .last()
            .map_or(after.offset, |record| record.cursor.offset);
        Ok(ReplicaPage {
            after: after.clone(),
            records,
            next: ReplicaPosition {
                stream: after.stream.clone(),
                offset: next_offset,
            },
            complete: next_offset == tail,
        })
    }

    async fn advance_replica_receipt_floor(
        &self,
        request: AdvanceReplicaReceiptFloor,
    ) -> ReplicationResult<AdvanceReplicaReceiptFloorReceipt> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| ReplicationError::CorruptStorage("memory store lock poisoned".into()))?;
        if state.closed {
            return Err(ReplicationError::Closed);
        }
        if request.destination_epoch != state.replica_destination_epoch {
            return Err(ReplicationError::DestinationReplaced {
                current: state.replica_destination_epoch,
            });
        }
        if let Some(prior) = state.replica_floor_receipts.get(&request.operation_id) {
            return if prior.request == request {
                Ok(prior.clone())
            } else {
                Err(ReplicationError::InvalidInput(
                    "replica receipt-floor operation identity was reused".into(),
                ))
            };
        }
        if !state.replica_histories.contains_key(&request.stream) {
            return Err(ReplicationError::InvalidInput(
                "cannot create a receipt floor for an unknown origin stream".into(),
            ));
        }
        let current = state
            .replica_receipt_floors
            .get(&request.stream)
            .copied()
            .unwrap_or(0);
        if request.expected_floor.stream != request.stream
            || request.new_floor.stream != request.stream
            || request.expected_floor.offset != current
            || request.new_floor.offset < current
        {
            return Err(ReplicationError::StaleProgress {
                current: Box::new(ReplicaPosition {
                    stream: request.stream.clone(),
                    offset: current,
                }),
            });
        }
        let tail = state
            .replica_histories
            .get(&request.stream)
            .and_then(BTreeMap::last_key_value)
            .map_or(0, |(&offset, _)| offset);
        if request.new_floor.offset > tail {
            return Err(ReplicationError::InvalidInput(
                "replica receipt floor is beyond committed history".into(),
            ));
        }
        let receipt = AdvanceReplicaReceiptFloorReceipt {
            request: request.clone(),
        };
        let receipt_charge = request
            .stream
            .stream
            .id
            .as_str()
            .len()
            .checked_add(
                request
                    .operation_id
                    .as_str()
                    .len()
                    .saturating_add(RECEIPT_OVERHEAD),
            )
            .ok_or(ReplicationError::CapacityExceeded)?;
        if state
            .replica_receipts
            .len()
            .checked_add(state.replica_floor_receipts.len())
            .is_none_or(|rows| rows > self.options.replica_destination.receipts.max_batch_receipts)
            || state
                .replica_receipt_bytes
                .checked_add(receipt_charge)
                .is_none_or(|bytes| {
                    bytes
                        > self
                            .options
                            .replica_destination
                            .receipts
                            .max_batch_receipt_bytes
                })
        {
            return Err(ReplicationError::CapacityExceeded);
        }
        state
            .replica_receipt_floors
            .insert(request.stream.clone(), request.new_floor.offset);
        state
            .replica_floor_receipts
            .insert(request.operation_id.clone(), receipt.clone());
        state.replica_receipt_bytes += receipt_charge;
        Ok(receipt)
    }

    async fn close(&self) -> ReplicationResult<()> {
        self.state
            .lock()
            .map_err(|_| ReplicationError::CorruptStorage("memory store lock poisoned".into()))?
            .closed = true;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn stream(origin: OriginId) -> OriginStream {
        OriginStream {
            origin,
            stream: StreamKey {
                id: StreamId::new("replicated").unwrap(),
                incarnation: IncarnationId([7; 16]),
            },
        }
    }

    fn record(stream: &OriginStream, offset: u64, value: u8) -> Arc<Record> {
        Arc::new(Record {
            cursor: Cursor::new(stream.stream.clone(), offset),
            event: NewEvent {
                id: EventId::new(format!("event-{offset}")).unwrap(),
                schema: SchemaRef {
                    id: SchemaId::new("test.bytes").unwrap(),
                    version: 1,
                },
                payload: Payload::copy_from_slice(&[value]),
            },
        })
    }

    #[tokio::test]
    async fn destination_commits_one_exact_bounded_batch_and_reconciles_it() {
        let store = MemoryStore::open(Default::default()).await.unwrap();
        let epoch = ReplicaBatchDestinationStore::destination_epoch(&store)
            .await
            .unwrap();
        let origin_stream = stream(OriginId([3; 16]));
        let batch = ReplicaBatch {
            id: BatchId([4; 16]),
            destination_epoch: epoch,
            after: ReplicaPosition {
                stream: origin_stream.clone(),
                offset: 0,
            },
            records: vec![record(&origin_stream, 1, 1), record(&origin_stream, 2, 2)],
        };
        let receipt = store.commit_replica_batch(batch.clone()).await.unwrap();
        assert_eq!(receipt.committed_through.offset, 2);
        assert_eq!(
            store.commit_replica_batch(batch.clone()).await.unwrap(),
            receipt
        );

        let mut conflict = batch.clone();
        conflict.records[1] = record(&origin_stream, 2, 9);
        assert!(matches!(
            store.commit_replica_batch(conflict).await,
            Err(ReplicationError::BatchConflict { .. })
        ));
        let page = store
            .read_replica_after(
                &batch.after,
                ReplicaBatchLimits {
                    max_records: 2,
                    max_bytes: 1024,
                },
            )
            .await
            .unwrap();
        assert_eq!(page.records.len(), 2);
        assert_eq!(page.records[1].event.payload.as_bytes(), &[2]);
        assert!(page.complete);

        let floor = AdvanceReplicaReceiptFloor {
            operation_id: ReplicationOperationId::new("floor-1").unwrap(),
            stream: origin_stream.clone(),
            destination_epoch: epoch,
            expected_floor: ReplicaPosition {
                stream: origin_stream.clone(),
                offset: 0,
            },
            new_floor: ReplicaPosition {
                stream: origin_stream,
                offset: 2,
            },
        };
        let first = store
            .advance_replica_receipt_floor(floor.clone())
            .await
            .unwrap();
        assert_eq!(
            store.advance_replica_receipt_floor(floor).await.unwrap(),
            first
        );
        assert!(matches!(
            store.commit_replica_batch(batch).await,
            Err(ReplicationError::ReceiptExpired)
        ));
    }

    #[tokio::test]
    async fn destination_accepts_a_final_max_offset_and_reads_at_tail() {
        let store = MemoryStore::open(Default::default()).await.unwrap();
        let epoch = ReplicaBatchDestinationStore::destination_epoch(&store)
            .await
            .unwrap();
        let origin_stream = stream(OriginId([8; 16]));
        {
            let mut state = store.state.lock().unwrap();
            state
                .replica_histories
                .entry(origin_stream.clone())
                .or_default()
                .insert(u64::MAX - 1, record(&origin_stream, u64::MAX - 1, 1));
            state.replica_history_records = 1;
        }
        let batch = ReplicaBatch {
            id: BatchId([9; 16]),
            destination_epoch: epoch,
            after: ReplicaPosition {
                stream: origin_stream.clone(),
                offset: u64::MAX - 1,
            },
            records: vec![record(&origin_stream, u64::MAX, 2)],
        };
        store.commit_replica_batch(batch).await.unwrap();
        let page = store
            .read_replica_after(
                &ReplicaPosition {
                    stream: origin_stream,
                    offset: u64::MAX,
                },
                ReplicaBatchLimits {
                    max_records: 1,
                    max_bytes: 1024,
                },
            )
            .await
            .unwrap();
        assert!(page.records.is_empty());
        assert!(page.complete);
    }
}
