use super::{RetentionStore, SnapshotStore};
use crate::domain::*;
use async_trait::async_trait;
use std::time::Duration;

pub type ReplicationResult<T> = std::result::Result<T, ReplicationError>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReplicaMode {
    Required,
    DetachedNeedsBootstrap,
    Bootstrapping,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReplicaStart {
    /// Protect and transfer complete retained history from offset zero.
    FromBeginning,
    /// Attach without claiming an existing prefix is replayable.
    NeedsBootstrap,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaStatus {
    pub replica: ReplicaId,
    pub stream: OriginStream,
    pub destination_epoch: DestinationEpoch,
    pub acknowledged: ReplicaPosition,
    pub backlog_records: usize,
    pub backlog_bytes: u64,
    /// Persisted wall-clock observation for the oldest unacknowledged record.
    pub oldest_backlog_at: Option<DurableTimestampMillis>,
    pub mode: ReplicaMode,
    pub pending_batch: Option<BatchId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AttachReplica {
    pub operation_id: ReplicationOperationId,
    pub replica: ReplicaId,
    pub stream: OriginStream,
    pub destination_epoch: DestinationEpoch,
    pub max_backlog_bytes: u64,
    pub max_backlog_age: Duration,
    pub start: ReplicaStart,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AttachReplicaReceipt {
    pub request: AttachReplica,
    pub status: ReplicaStatus,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DetachReplica {
    pub operation_id: ReplicationOperationId,
    pub replica: ReplicaId,
    pub stream: OriginStream,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DetachReplicaReceipt {
    pub request: DetachReplica,
    pub status: ReplicaStatus,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcknowledgeReplicaBatch {
    pub operation_id: ReplicationOperationId,
    pub replica: ReplicaId,
    pub expected_after: ReplicaPosition,
    pub receipt: ReplicaReceipt,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcknowledgeReplicaBatchReceipt {
    pub request: AcknowledgeReplicaBatch,
    pub status: ReplicaStatus,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReplicaBatchLimits {
    pub max_records: usize,
    pub max_bytes: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PrepareReplicaBatch {
    pub operation_id: ReplicationOperationId,
    pub batch_id: BatchId,
    pub replica: ReplicaId,
    pub stream: OriginStream,
    pub expected_after: ReplicaPosition,
    pub limits: ReplicaBatchLimits,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PrepareReplicaBatchReceipt {
    pub request: PrepareReplicaBatch,
    pub batch: Option<ReplicaBatch>,
    pub status: ReplicaStatus,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdvanceReplicaReceiptFloor {
    pub operation_id: ReplicationOperationId,
    pub stream: OriginStream,
    pub destination_epoch: DestinationEpoch,
    pub expected_floor: ReplicaPosition,
    pub new_floor: ReplicaPosition,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdvanceReplicaReceiptFloorReceipt {
    pub request: AdvanceReplicaReceiptFloor,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrap {
    pub operation_id: ReplicationOperationId,
    pub id: BootstrapId,
    pub replica: ReplicaId,
    pub destination_epoch: DestinationEpoch,
    pub stream: OriginStream,
    pub snapshot: SnapshotDescriptor,
    pub through: ReplicaPosition,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapChunk {
    pub id: BootstrapId,
    pub chunk: SnapshotChunk,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapBatch {
    pub id: BootstrapId,
    pub batch: ReplicaBatch,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapBatchReceipt {
    pub id: BootstrapId,
    pub committed_through: ReplicaPosition,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapReceipt {
    pub request: ReplicaBootstrap,
    pub committed_through: ReplicaPosition,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReplicaBootstrapState {
    Staging,
    Verified,
    Published,
    Aborted,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BeginReplicaBootstrapReceipt {
    pub request: ReplicaBootstrap,
    pub state: ReplicaBootstrapState,
    pub accepted_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapChunkReceipt {
    pub id: BootstrapId,
    pub offset: u64,
    pub end: u64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapVerificationLimits {
    pub max_chunks: usize,
    pub max_records: usize,
    pub max_bytes: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifyReplicaBootstrap {
    pub id: BootstrapId,
    pub limits: ReplicaBootstrapVerificationLimits,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapVerificationProgress {
    pub id: BootstrapId,
    pub verified_snapshot_bytes: u64,
    pub verified_suffix_records: usize,
    pub verified_suffix_bytes: u64,
    pub complete: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PublishReplicaBootstrap {
    pub operation_id: ReplicationOperationId,
    pub id: BootstrapId,
    pub destination_epoch: DestinationEpoch,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PublishedReplicaBootstrap {
    pub request: ReplicaBootstrap,
    pub committed_through: ReplicaPosition,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicaBootstrapBytePage {
    pub id: BootstrapId,
    pub offset: u64,
    pub bytes: Payload,
    pub next_offset: u64,
    pub complete: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BeginOriginBootstrap {
    pub operation_id: ReplicationOperationId,
    pub replica: ReplicaId,
    pub stream: OriginStream,
    pub destination_epoch: DestinationEpoch,
    pub snapshot: SnapshotDescriptor,
    pub captured_tail: ReplicaPosition,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BeginOriginBootstrapReceipt {
    pub request: BeginOriginBootstrap,
    pub status: ReplicaStatus,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcknowledgeOriginBootstrap {
    pub operation_id: ReplicationOperationId,
    pub replica: ReplicaId,
    pub stream: OriginStream,
    pub receipt: ReplicaBootstrapReceipt,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcknowledgeOriginBootstrapReceipt {
    pub request: AcknowledgeOriginBootstrap,
    pub status: ReplicaStatus,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AbortReplicaBootstrapReceipt {
    pub request: AbortReplicaBootstrap,
    pub state: ReplicaBootstrapState,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AbortReplicaBootstrap {
    pub operation_id: ReplicationOperationId,
    pub id: BootstrapId,
    pub destination_epoch: DestinationEpoch,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReplicaCleanupLimits {
    pub max_receipt_rows: usize,
    pub max_staging_rows: usize,
    pub max_bytes: usize,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReplicaCleanupProgress {
    pub removed_receipt_rows: usize,
    pub removed_staging_rows: usize,
    pub removed_bytes: usize,
    pub remaining: bool,
}

#[derive(Clone, Debug)]
pub struct ReplicationStoreConfig {
    pub attachments: ReplicaAttachmentLimits,
    pub batches: ReplicaPendingBatchLimits,
    pub receipts: ReplicaReceiptLimits,
    pub cleanup: ReplicaCleanupLimits,
}

#[derive(Clone, Debug)]
pub struct ReplicaAttachmentLimits {
    pub max_replicas: usize,
    pub max_replicas_per_stream: usize,
}

#[derive(Clone, Debug)]
pub struct ReplicaPendingBatchLimits {
    pub max_pending_batches: usize,
    pub max_pending_batch_bytes: usize,
    pub max_batch_records: usize,
    pub max_batch_bytes: usize,
}

#[derive(Clone, Debug)]
pub struct ReplicaReceiptLimits {
    pub max_operation_receipts: usize,
    pub max_operation_receipt_bytes: usize,
}

#[derive(Clone, Debug)]
pub struct ReplicaDestinationConfig {
    pub storage: ReplicaDestinationStorageLimits,
    pub receipts: ReplicaDestinationReceiptLimits,
    pub staging: ReplicaDestinationStagingLimits,
    pub cleanup: ReplicaCleanupLimits,
}

#[derive(Clone, Debug)]
pub struct ReplicaDestinationStorageLimits {
    pub max_origin_streams: usize,
    pub max_history_records: usize,
    pub max_history_bytes: u64,
    pub max_batch_records: usize,
    pub max_batch_bytes: usize,
}

#[derive(Clone, Debug)]
pub struct ReplicaDestinationReceiptLimits {
    pub max_batch_receipts: usize,
    pub max_batch_receipt_bytes: usize,
}

#[derive(Clone, Debug)]
pub struct ReplicaDestinationStagingLimits {
    pub max_staging_bootstraps: usize,
    pub max_staging_chunks: usize,
    pub max_staging_bytes: u64,
    pub max_staging_records: usize,
    pub max_staging_record_bytes: u64,
}

impl Default for ReplicationStoreConfig {
    fn default() -> Self {
        Self {
            attachments: ReplicaAttachmentLimits {
                max_replicas: 1024,
                max_replicas_per_stream: 16,
            },
            batches: ReplicaPendingBatchLimits {
                max_pending_batches: 1024,
                max_pending_batch_bytes: 64 * 1024 * 1024,
                max_batch_records: 256,
                max_batch_bytes: 2 * 1024 * 1024,
            },
            receipts: ReplicaReceiptLimits {
                max_operation_receipts: 4096,
                max_operation_receipt_bytes: 4 * 1024 * 1024,
            },
            cleanup: ReplicaCleanupLimits {
                max_receipt_rows: 256,
                max_staging_rows: 256,
                max_bytes: 2 * 1024 * 1024,
            },
        }
    }
}

impl Default for ReplicaDestinationConfig {
    fn default() -> Self {
        Self {
            storage: ReplicaDestinationStorageLimits {
                max_origin_streams: 10_000,
                max_history_records: 100_000,
                max_history_bytes: 1024 * 1024 * 1024,
                max_batch_records: 256,
                max_batch_bytes: 2 * 1024 * 1024,
            },
            receipts: ReplicaDestinationReceiptLimits {
                max_batch_receipts: 4096,
                max_batch_receipt_bytes: 4 * 1024 * 1024,
            },
            staging: ReplicaDestinationStagingLimits {
                max_staging_bootstraps: 16,
                max_staging_chunks: 1024 * 1024,
                max_staging_bytes: 256 * 1024 * 1024,
                max_staging_records: 100_000,
                max_staging_record_bytes: 1024 * 1024 * 1024,
            },
            cleanup: ReplicaCleanupLimits {
                max_receipt_rows: 256,
                max_staging_rows: 256,
                max_bytes: 2 * 1024 * 1024,
            },
        }
    }
}

impl ReplicationStoreConfig {
    pub fn validate(&self) -> ReplicationResult<()> {
        if self.attachments.max_replicas == 0
            || self.attachments.max_replicas_per_stream == 0
            || self.batches.max_pending_batches == 0
            || self.batches.max_pending_batch_bytes == 0
            || self.batches.max_batch_records == 0
            || self.batches.max_batch_bytes == 0
            || self.receipts.max_operation_receipts == 0
            || self.receipts.max_operation_receipt_bytes == 0
            || self.cleanup.max_receipt_rows == 0
            || self.cleanup.max_staging_rows == 0
            || self.cleanup.max_bytes == 0
        {
            return Err(ReplicationError::InvalidConfig(
                "origin replication limits must be nonzero and finite".into(),
            ));
        }
        Ok(())
    }
}

impl ReplicaDestinationConfig {
    pub fn validate(&self) -> ReplicationResult<()> {
        if self.storage.max_origin_streams == 0
            || self.storage.max_history_records == 0
            || self.storage.max_history_bytes == 0
            || self.storage.max_batch_records == 0
            || self.storage.max_batch_bytes == 0
            || self.receipts.max_batch_receipts == 0
            || self.receipts.max_batch_receipt_bytes == 0
            || self.staging.max_staging_bootstraps == 0
            || self.staging.max_staging_chunks == 0
            || self.staging.max_staging_bytes == 0
            || self.staging.max_staging_records == 0
            || self.staging.max_staging_record_bytes == 0
            || self.cleanup.max_receipt_rows == 0
            || self.cleanup.max_staging_rows == 0
            || self.cleanup.max_bytes == 0
        {
            return Err(ReplicationError::InvalidConfig(
                "destination replication limits must be nonzero and finite".into(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReplicationError {
    InvalidConfig(String),
    InvalidInput(String),
    NotFound {
        replica: ReplicaId,
    },
    StaleProgress {
        current: Box<ReplicaPosition>,
    },
    DestinationReplaced {
        current: DestinationEpoch,
    },
    ClockRollback {
        last: DurableTimestampMillis,
        observed: DurableTimestampMillis,
    },
    NeedsBootstrap,
    BacklogExceeded {
        limit_bytes: u64,
    },
    BatchConflict {
        batch: BatchId,
    },
    ReceiptExpired,
    InvalidReceipt(String),
    CapacityExceeded,
    Overloaded,
    AdmissionTimeout,
    Closed,
    CorruptStorage(String),
    StorageFailure(String),
    CommitUnknown(Box<ReplicaBatch>),
    AttachUnknown(Box<AttachReplica>),
    PrepareUnknown(Box<PrepareReplicaBatch>),
    AcknowledgeUnknown(Box<AcknowledgeReplicaBatch>),
    DetachUnknown(Box<DetachReplica>),
    ReceiptFloorUnknown(Box<AdvanceReplicaReceiptFloor>),
    BootstrapUnknown(Box<ReplicaBootstrap>),
    BootstrapBatchUnknown(Box<ReplicaBootstrapBatch>),
    BootstrapPublishUnknown(Box<PublishReplicaBootstrap>),
    BootstrapAbortUnknown(Box<AbortReplicaBootstrap>),
}

impl std::fmt::Display for ReplicationError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::CommitUnknown(batch) => write!(
                formatter,
                "replica batch result unknown for {} records after offset {}",
                batch.records.len(),
                batch.after.offset
            ),
            Self::AcknowledgeUnknown(request) => write!(
                formatter,
                "replica acknowledgement result unknown for {} after offset {}",
                request.replica.as_str(),
                request.expected_after.offset
            ),
            Self::BootstrapUnknown(request) => write!(
                formatter,
                "replica bootstrap result unknown for {} through offset {}",
                request.replica.as_str(),
                request.through.offset
            ),
            other => write!(formatter, "{other:?}"),
        }
    }
}

impl std::error::Error for ReplicationError {}

/// Origin-side state. Implementations update replay protection and acknowledged progress under
/// the same ownership boundary as retention and local append backlog accounting.
#[async_trait]
pub trait ReplicationOriginStore: RetentionStore {
    async fn origin_identity(&self) -> ReplicationResult<OriginId>;
    async fn attach_replica(
        &self,
        request: AttachReplica,
    ) -> ReplicationResult<AttachReplicaReceipt>;
    async fn replica_status(
        &self,
        replica: &ReplicaId,
        stream: &OriginStream,
    ) -> ReplicationResult<ReplicaStatus>;
    async fn prepare_replica_batch(
        &self,
        request: PrepareReplicaBatch,
    ) -> ReplicationResult<PrepareReplicaBatchReceipt>;
    async fn acknowledge_replica_batch(
        &self,
        request: AcknowledgeReplicaBatch,
    ) -> ReplicationResult<AcknowledgeReplicaBatchReceipt>;
    async fn detach_replica(
        &self,
        request: DetachReplica,
    ) -> ReplicationResult<DetachReplicaReceipt>;
}

#[async_trait]
pub trait ReplicationStore: ReplicationOriginStore + SnapshotStore {
    async fn begin_origin_bootstrap(
        &self,
        request: BeginOriginBootstrap,
    ) -> ReplicationResult<BeginOriginBootstrapReceipt>;
    async fn acknowledge_origin_bootstrap(
        &self,
        request: AcknowledgeOriginBootstrap,
    ) -> ReplicationResult<AcknowledgeOriginBootstrapReceipt>;
    async fn cleanup_replication(
        &self,
        limits: ReplicaCleanupLimits,
    ) -> ReplicationResult<ReplicaCleanupProgress>;
}

/// Destination-side atomic records-plus-receipt publication.
#[async_trait]
pub trait ReplicaBatchDestinationStore: Send + Sync + 'static {
    async fn destination_epoch(&self) -> ReplicationResult<DestinationEpoch>;
    async fn commit_replica_batch(&self, batch: ReplicaBatch) -> ReplicationResult<ReplicaReceipt>;
    async fn read_replica_after(
        &self,
        after: &ReplicaPosition,
        limits: ReplicaBatchLimits,
    ) -> ReplicationResult<ReplicaPage>;
    async fn advance_replica_receipt_floor(
        &self,
        request: AdvanceReplicaReceiptFloor,
    ) -> ReplicationResult<AdvanceReplicaReceiptFloorReceipt>;
    async fn close(&self) -> ReplicationResult<()>;
}

#[async_trait]
pub trait ReplicaDestinationStore: ReplicaBatchDestinationStore {
    async fn begin_replica_bootstrap(
        &self,
        request: ReplicaBootstrap,
    ) -> ReplicationResult<BeginReplicaBootstrapReceipt>;
    async fn put_replica_bootstrap_chunk(
        &self,
        chunk: ReplicaBootstrapChunk,
    ) -> ReplicationResult<ReplicaBootstrapChunkReceipt>;
    async fn put_replica_bootstrap_batch(
        &self,
        batch: ReplicaBootstrapBatch,
    ) -> ReplicationResult<ReplicaBootstrapBatchReceipt>;
    async fn verify_replica_bootstrap_step(
        &self,
        request: VerifyReplicaBootstrap,
    ) -> ReplicationResult<ReplicaBootstrapVerificationProgress>;
    async fn publish_replica_bootstrap(
        &self,
        request: PublishReplicaBootstrap,
    ) -> ReplicationResult<ReplicaBootstrapReceipt>;
    async fn published_replica_bootstrap(
        &self,
        stream: &OriginStream,
    ) -> ReplicationResult<Option<PublishedReplicaBootstrap>>;
    async fn read_replica_bootstrap_bytes(
        &self,
        id: BootstrapId,
        offset: u64,
        max_bytes: usize,
    ) -> ReplicationResult<ReplicaBootstrapBytePage>;
    async fn abort_replica_bootstrap(
        &self,
        request: AbortReplicaBootstrap,
    ) -> ReplicationResult<AbortReplicaBootstrapReceipt>;
    async fn cleanup_replica_destination(
        &self,
        limits: ReplicaCleanupLimits,
    ) -> ReplicationResult<ReplicaCleanupProgress>;
}

pub trait DurableReplicationClock: std::fmt::Debug + Send + Sync + 'static {
    fn now(&self) -> DurableTimestampMillis;
}

/// The application injects an authenticated transport. The library retains the request until the
/// returned future finishes or transfers ownership to another bounded task.
#[async_trait]
pub trait ReplicaTransport: Send + Sync + 'static {
    async fn send_batch(&self, batch: ReplicaBatch) -> ReplicationResult<ReplicaReceipt>;
}
