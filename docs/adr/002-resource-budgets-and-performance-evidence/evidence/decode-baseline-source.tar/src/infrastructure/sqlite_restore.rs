use super::sqlite::{inspect_existing_format, validate_lifecycle_counters, Ownership};
use crate::{
    application::{
        MappingPage, RestoreBackend, RestoreConfig, RestoreError, RestoreManager, RestoreReceipt,
        RestoreRequest, RestoreResult,
    },
    domain::*,
};
use async_trait::async_trait;
use rusqlite::{params, Connection, OpenFlags, OptionalExtension, TransactionBehavior};
use sha2::{Digest, Sha256};
use std::{
    fs::{File, OpenOptions},
    io::Read,
    path::{Component, Path, PathBuf},
    sync::{
        atomic::{AtomicU8, Ordering},
        Arc,
    },
};

pub type SqliteRestoreManager = RestoreManager<SqliteRestoreBackend>;

#[derive(Clone, Debug)]
pub struct SqliteRestoreBackend {
    root: PathBuf,
    failure: Arc<AtomicU8>,
}

#[doc(hidden)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SqliteRestoreFailureInjection {
    AfterStagingCompletion,
    AfterDestinationLink,
    AfterPublishedMarker,
}

impl SqliteRestoreBackend {
    pub fn new(root: impl AsRef<Path>) -> RestoreResult<Self> {
        let root = root
            .as_ref()
            .canonicalize()
            .map_err(|error| RestoreError::InvalidConfig(format!("restore root: {error}")))?;
        let metadata = std::fs::symlink_metadata(&root)
            .map_err(|error| RestoreError::InvalidConfig(format!("restore root: {error}")))?;
        if !metadata.is_dir() || metadata.file_type().is_symlink() {
            return Err(RestoreError::InvalidConfig(
                "restore root must be a real directory".into(),
            ));
        }
        Ok(Self {
            root,
            failure: Arc::new(AtomicU8::new(0)),
        })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    #[doc(hidden)]
    pub fn with_failure_injection(self, failure: SqliteRestoreFailureInjection) -> Self {
        self.failure.store(failure as u8 + 1, Ordering::Release);
        self
    }
}

#[async_trait]
impl RestoreBackend for SqliteRestoreBackend {
    async fn inspect_backup(
        &self,
        source: PathBuf,
        config: RestoreConfig,
    ) -> RestoreResult<BackupIdentity> {
        tokio::task::spawn_blocking(move || inspect_backup_blocking(&source, &config))
            .await
            .map_err(|_| RestoreError::StorageFailure("backup inspection worker panicked".into()))?
    }

    async fn restore(
        &self,
        request: RestoreRequest,
        config: RestoreConfig,
    ) -> RestoreResult<RestoreReceipt> {
        let root = self.root.clone();
        let failure = self.failure.clone();
        let panic_request = request.clone();
        tokio::task::spawn_blocking(move || restore_blocking(&root, &request, &config, &failure))
            .await
            .map_err(|_| RestoreError::PublicationUnknown {
                operation_id: panic_request.operation_id,
                destination: Box::new(panic_request.destination),
            })?
    }

    async fn read_mapping(
        &self,
        receipt: RestoreReceipt,
        after: Option<StreamKey>,
        limits: PageLimits,
        config: RestoreConfig,
    ) -> RestoreResult<MappingPage> {
        let root = self.root.clone();
        tokio::task::spawn_blocking(move || {
            read_mapping_blocking(&root, &receipt, after.as_ref(), limits, &config)
        })
        .await
        .map_err(|_| RestoreError::StorageFailure("mapping reader worker panicked".into()))?
    }

    async fn cleanup_staging(
        &self,
        request: RestoreRequest,
        config: RestoreConfig,
    ) -> RestoreResult<()> {
        let root = self.root.clone();
        tokio::task::spawn_blocking(move || cleanup_staging_blocking(&root, &request, &config))
            .await
            .map_err(|_| RestoreError::StorageFailure("staging cleanup worker panicked".into()))?
    }
}

fn map_store_error(error: crate::application::Error) -> RestoreError {
    match error {
        crate::application::Error::StoreInUse => RestoreError::OwnershipConflict,
        crate::application::Error::UnsupportedFormat(version) => {
            RestoreError::UnsupportedBackup(version)
        }
        crate::application::Error::StoreCorrupt(message) => RestoreError::CorruptBackup(message),
        other => RestoreError::StorageFailure(other.to_string()),
    }
}

fn inspect_backup_blocking(source: &Path, config: &RestoreConfig) -> RestoreResult<BackupIdentity> {
    let ownership = Ownership::acquire(source).map_err(map_store_error)?;
    let (_connection, identity) = open_locked_source(ownership.path(), config)?;
    Ok(identity)
}

fn open_locked_source(
    source: &Path,
    config: &RestoreConfig,
) -> RestoreResult<(Connection, BackupIdentity)> {
    reject_recovery_sidecars(source)?;
    let metadata = std::fs::metadata(source)
        .map_err(|error| RestoreError::StorageFailure(format!("inspect backup: {error}")))?;
    if !metadata.is_file() || metadata.len() > config.max_source_bytes {
        return Err(RestoreError::CapacityExceeded);
    }
    let conn = Connection::open_with_flags(
        source,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::CorruptBackup(format!("open backup read-only: {error}")))?;
    conn.execute_batch("BEGIN;")
        .map_err(|error| RestoreError::CorruptBackup(format!("begin backup snapshot: {error}")))?;
    conn.query_row("SELECT count(*) FROM sqlite_schema", [], |row| {
        row.get::<_, u64>(0)
    })
    .map_err(|error| RestoreError::CorruptBackup(format!("establish backup snapshot: {error}")))?;
    let identity = hash_file(source, config.copy_buffer_bytes, config.max_source_bytes)?;
    match inspect_existing_format(&conn).map_err(map_store_error)? {
        Some(2) => {}
        Some(version) => return Err(RestoreError::UnsupportedBackup(version)),
        None => {
            return Err(RestoreError::CorruptBackup(
                "backup has no storage format".into(),
            ))
        }
    }
    validate_lifecycle_counters(&conn).map_err(map_store_error)?;
    let journal: String = conn
        .pragma_query_value(None, "journal_mode", |row| row.get(0))
        .map_err(|error| RestoreError::CorruptBackup(format!("read journal mode: {error}")))?;
    if !journal.eq_ignore_ascii_case("delete") {
        return Err(RestoreError::CorruptBackup(
            "backup must use DELETE journal mode".into(),
        ));
    }
    let quick: String = conn
        .query_row("PRAGMA quick_check", [], |row| row.get(0))
        .map_err(|error| RestoreError::CorruptBackup(format!("SQLite quick_check: {error}")))?;
    if quick != "ok" {
        return Err(RestoreError::CorruptBackup(format!(
            "SQLite quick_check failed: {quick}"
        )));
    }
    let foreign_violation: bool = conn
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
            [],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("foreign-key check: {error}")))?;
    if foreign_violation {
        return Err(RestoreError::CorruptBackup(
            "backup contains a foreign-key violation".into(),
        ));
    }
    Ok((conn, identity))
}

fn reject_recovery_sidecars(source: &Path) -> RestoreResult<()> {
    for suffix in ["-wal", "-journal"] {
        let mut sidecar = source.as_os_str().to_os_string();
        sidecar.push(suffix);
        let path = PathBuf::from(sidecar);
        match std::fs::metadata(&path) {
            Ok(metadata) if metadata.len() > 0 => {
                return Err(RestoreError::CorruptBackup(format!(
                    "backup has a nonempty recovery sidecar: {}",
                    path.display()
                )))
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(RestoreError::StorageFailure(format!(
                    "inspect recovery sidecar: {error}"
                )))
            }
        }
    }
    Ok(())
}

fn hash_file(path: &Path, buffer_bytes: usize, max_bytes: u64) -> RestoreResult<BackupIdentity> {
    let mut file = File::open(path).map_err(|error| {
        RestoreError::StorageFailure(format!("open backup for hashing: {error}"))
    })?;
    let mut buffer = vec![0; buffer_bytes];
    let mut total = 0_u64;
    let mut hash = Sha256::new();
    loop {
        let read = file
            .read(&mut buffer)
            .map_err(|error| RestoreError::StorageFailure(format!("hash backup: {error}")))?;
        if read == 0 {
            break;
        }
        total = total
            .checked_add(read as u64)
            .filter(|total| *total <= max_bytes)
            .ok_or(RestoreError::CapacityExceeded)?;
        hash.update(&buffer[..read]);
    }
    Ok(BackupIdentity(hash.finalize().into()))
}

fn resolve_destination(root: &Path, relative: &Path) -> RestoreResult<PathBuf> {
    if relative.is_absolute()
        || relative.components().any(|component| {
            matches!(
                component,
                Component::ParentDir | Component::RootDir | Component::Prefix(_)
            )
        })
    {
        return Err(RestoreError::InvalidConfig(
            "destination must remain inside the restore root".into(),
        ));
    }
    let name = relative
        .file_name()
        .ok_or_else(|| RestoreError::InvalidConfig("destination needs a file name".into()))?;
    let parent = root.join(relative).parent().unwrap_or(root).to_path_buf();
    let parent = parent.canonicalize().map_err(|error| {
        RestoreError::InvalidConfig(format!("destination parent is unavailable: {error}"))
    })?;
    if !parent.starts_with(root) {
        return Err(RestoreError::InvalidConfig(
            "destination parent escapes the restore root".into(),
        ));
    }
    Ok(parent.join(name))
}

fn staging_path(destination: &Path, operation_id: &RestoreOperationId) -> RestoreResult<PathBuf> {
    let name = destination
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| RestoreError::InvalidConfig("destination name must be UTF-8".into()))?;
    let mut hash = Sha256::new();
    hash.update(destination.as_os_str().to_string_lossy().as_bytes());
    hash.update([0]);
    hash.update(operation_id.as_str().as_bytes());
    let suffix = hex_prefix(&hash.finalize(), 16);
    let mut name_hash = Sha256::new();
    name_hash.update(name.as_bytes());
    let name_hash = hex_prefix(&name_hash.finalize(), 8);
    Ok(destination.with_file_name(format!(
        ".event-stream-restore-{name_hash}-{suffix}.sqlite3"
    )))
}

fn hex_prefix(bytes: &[u8], count: usize) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut value = String::with_capacity(count * 2);
    for byte in bytes.iter().take(count) {
        value.push(char::from(HEX[usize::from(byte >> 4)]));
        value.push(char::from(HEX[usize::from(byte & 0x0f)]));
    }
    value
}

fn restore_blocking(
    root: &Path,
    request: &RestoreRequest,
    config: &RestoreConfig,
    failure: &AtomicU8,
) -> RestoreResult<RestoreReceipt> {
    let destination = resolve_destination(root, &request.destination)?;
    let _destination_ownership =
        Ownership::acquire_restore_destination(&destination).map_err(map_store_error)?;
    let staging = staging_path(&destination, &request.operation_id)?;

    if destination.exists() {
        let receipt = read_published_receipt(&destination, request)?;
        finish_staging_alias_if_owned(&staging, &destination, request)?;
        return Ok(receipt);
    }
    if staging.exists() {
        if validate_staging_owner(&staging, request, &destination)? {
            return Err(RestoreError::IncompleteStaging {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination),
            });
        }
        sync_file(&staging)?;
        publish_no_replace(&staging, &destination, request, failure)?;
        return read_published_receipt(&destination, request);
    }

    let source_ownership = Ownership::acquire(&request.source).map_err(map_store_error)?;
    let (source, actual) = open_locked_source(source_ownership.path(), config)?;
    if actual != request.backup_identity {
        return Err(RestoreError::IdentityMismatch {
            expected: request.backup_identity,
            actual,
        });
    }

    let mut target = create_incomplete_staging(&staging, request, &destination, config)?;
    let result = (|| {
        import_all(&source, &mut target, request, config)?;
        validate_import(&target)?;
        complete_staging(&mut target, request, &destination)?;
        enforce_staging_limit(&target, config.max_staging_bytes)?;
        Ok(())
    })();
    if let Err(error) = result {
        drop(target);
        return Err(error);
    }
    target
        .close()
        .map_err(|(_, error)| RestoreError::StorageFailure(format!("close staging: {error}")))?;
    sync_file(&staging)?;
    if consume_failure(
        failure,
        SqliteRestoreFailureInjection::AfterStagingCompletion,
    ) {
        return Err(RestoreError::StorageFailure(
            "injected failure after staging completion".into(),
        ));
    }
    publish_no_replace(&staging, &destination, request, failure)?;
    read_published_receipt(&destination, request)
}

fn open_read_only(path: &Path) -> RestoreResult<Connection> {
    Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::CorruptBackup(format!("open backup read-only: {error}")))
}

fn create_incomplete_staging(
    path: &Path,
    request: &RestoreRequest,
    destination: &Path,
    config: &RestoreConfig,
) -> RestoreResult<Connection> {
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|error| RestoreError::StorageFailure(format!("reserve staging: {error}")))?;
    let flags = OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX;
    let conn = Connection::open_with_flags(path, flags)
        .map_err(|error| RestoreError::StorageFailure(format!("create staging: {error}")))?;
    conn.pragma_update(None, "journal_mode", "DELETE")
        .map_err(|error| RestoreError::StorageFailure(format!("set staging journal: {error}")))?;
    conn.pragma_update(None, "synchronous", "FULL")
        .map_err(|error| RestoreError::StorageFailure(format!("set staging sync: {error}")))?;
    conn.pragma_update(None, "foreign_keys", true)
        .map_err(|error| {
            RestoreError::StorageFailure(format!("set staging foreign keys: {error}"))
        })?;
    let page_size: u64 = conn
        .pragma_query_value(None, "page_size", |row| row.get(0))
        .map_err(|error| {
            RestoreError::StorageFailure(format!("read staging page size: {error}"))
        })?;
    let pages = config.max_staging_bytes / page_size;
    if pages == 0 || pages > i32::MAX as u64 {
        return Err(RestoreError::InvalidConfig(
            "staging byte limit cannot be represented as SQLite pages".into(),
        ));
    }
    conn.pragma_update(None, "max_page_count", pages)
        .map_err(|error| {
            RestoreError::StorageFailure(format!("set staging page limit: {error}"))
        })?;
    let destination = destination
        .to_str()
        .ok_or_else(|| RestoreError::InvalidConfig("canonical destination must be UTF-8".into()))?;
    let schema_result = conn.execute_batch(
        "BEGIN IMMEDIATE;
         CREATE TABLE event_stream_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),format_version INTEGER NOT NULL,lifecycle_receipt_count INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_count>=0),lifecycle_receipt_bytes INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_bytes>=0),retired_lifetime_count INTEGER NOT NULL DEFAULT 0 CHECK(retired_lifetime_count>=0),retired_metadata_bytes INTEGER NOT NULL DEFAULT 0 CHECK(retired_metadata_bytes>=0),restore_incomplete INTEGER NOT NULL DEFAULT 1 CHECK(restore_incomplete IN (0,1,2)));
         CREATE TABLE event_streams(stream_key INTEGER PRIMARY KEY,public_id TEXT NOT NULL,incarnation BLOB NOT NULL CHECK(length(incarnation)=16),floor BLOB NOT NULL CHECK(length(floor)=8),tail BLOB NOT NULL CHECK(length(tail)=8),retired INTEGER NOT NULL DEFAULT 0 CHECK(retired IN (0,1)),UNIQUE(public_id,incarnation));
         CREATE TABLE event_records(stream_key INTEGER NOT NULL,offset BLOB NOT NULL CHECK(length(offset)=8),event_id TEXT NOT NULL,schema_id TEXT NOT NULL,schema_version INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(stream_key,offset),UNIQUE(stream_key,event_id),FOREIGN KEY(stream_key) REFERENCES event_streams(stream_key));
         CREATE TABLE event_stream_names(public_id TEXT PRIMARY KEY,latest_incarnation BLOB NOT NULL CHECK(length(latest_incarnation)=16),active_stream_key INTEGER);
         CREATE TABLE lifecycle_receipts(operation_id TEXT PRIMARY KEY,action INTEGER NOT NULL CHECK(action IN (0,1)),expected_public_id TEXT NOT NULL,expected_incarnation BLOB NOT NULL CHECK(length(expected_incarnation)=16),replacement_incarnation BLOB CHECK(replacement_incarnation IS NULL OR length(replacement_incarnation)=16),charge INTEGER NOT NULL CHECK(charge>=0));
         CREATE TABLE restore_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),operation_id TEXT NOT NULL,backup_identity BLOB NOT NULL CHECK(length(backup_identity)=32),destination TEXT NOT NULL,mapping_count INTEGER NOT NULL CHECK(mapping_count>=0));
         CREATE TABLE restore_mappings(old_public_id TEXT NOT NULL,old_incarnation BLOB NOT NULL CHECK(length(old_incarnation)=16),new_incarnation BLOB NOT NULL CHECK(length(new_incarnation)=16),PRIMARY KEY(old_public_id,old_incarnation));
         CREATE TABLE restore_lifetime_keys(old_stream_key INTEGER PRIMARY KEY,new_stream_key INTEGER NOT NULL UNIQUE);
         CREATE INDEX event_streams_retired_idx ON event_streams(retired,stream_key);",
    );
    if let Err(error) = schema_result {
        return Err(map_sql_write("create staging schema", error));
    }
    conn.execute(
        "INSERT INTO event_stream_metadata(singleton,format_version,restore_incomplete) VALUES(1,2,1)",
        [],
    )
    .map_err(|error| map_sql_write("mark staging incomplete", error))?;
    conn.execute(
        "INSERT INTO restore_metadata(singleton,operation_id,backup_identity,destination,mapping_count) VALUES(1,?1,?2,?3,0)",
        params![request.operation_id.as_str(), request.backup_identity.0.as_slice(), destination],
    )
    .map_err(|error| map_sql_write("store restore identity", error))?;
    conn.execute_batch("COMMIT;")
        .map_err(|error| map_sql_write("commit incomplete staging marker", error))?;
    sync_file(path)?;
    Ok(conn)
}

fn map_sql_write(action: &str, error: rusqlite::Error) -> RestoreError {
    if let rusqlite::Error::SqliteFailure(code, _) = &error {
        if code.code == rusqlite::ErrorCode::DiskFull {
            return RestoreError::CapacityExceeded;
        }
    }
    RestoreError::StorageFailure(format!("{action}: {error}"))
}

fn enforce_staging_limit(conn: &Connection, max_bytes: u64) -> RestoreResult<()> {
    let (pages, page_size): (u64, u64) = conn
        .query_row(
            "SELECT page_count,page_size FROM pragma_page_count(),pragma_page_size()",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .map_err(|error| RestoreError::StorageFailure(format!("measure staging: {error}")))?;
    pages
        .checked_mul(page_size)
        .filter(|bytes| *bytes <= max_bytes)
        .ok_or(RestoreError::CapacityExceeded)?;
    Ok(())
}

fn import_all(
    source: &Connection,
    target: &mut Connection,
    request: &RestoreRequest,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mapping_count = import_identity_mappings(source, target, config)?;
    import_lifetimes(source, target, config)?;
    import_records(source, target, config)?;
    import_names(source, target, config)?;
    import_receipts(source, target, config)?;
    let counters: (i64, i64, i64, i64) = source
        .query_row(
            "SELECT lifecycle_receipt_count,lifecycle_receipt_bytes,retired_lifetime_count,retired_metadata_bytes FROM event_stream_metadata WHERE singleton=1",
            [],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("read source counters: {error}")))?;
    target
        .execute(
            "UPDATE event_stream_metadata SET lifecycle_receipt_count=?1,lifecycle_receipt_bytes=?2,retired_lifetime_count=?3,retired_metadata_bytes=?4 WHERE singleton=1",
            params![counters.0, counters.1, counters.2, counters.3],
        )
        .map_err(|error| map_sql_write("copy lifecycle counters", error))?;
    target
        .execute(
            "UPDATE restore_metadata SET mapping_count=?1 WHERE singleton=1 AND operation_id=?2",
            params![
                i64::try_from(mapping_count).map_err(|_| RestoreError::CapacityExceeded)?,
                request.operation_id.as_str()
            ],
        )
        .map_err(|error| map_sql_write("store mapping count", error))?;
    Ok(())
}

fn import_identity_mappings(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<u64> {
    let mut after_id = String::new();
    let mut after_incarnation = [0_u8; 16];
    let mut count = 0_u64;
    loop {
        let mut statement = source
            .prepare(
                "SELECT octet_length(public_id),
                        CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                        CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END
                 FROM (
                   SELECT public_id,incarnation FROM event_streams
                   UNION SELECT public_id,latest_incarnation FROM event_stream_names
                   UNION SELECT expected_public_id,expected_incarnation FROM lifecycle_receipts
                   UNION SELECT expected_public_id,replacement_incarnation FROM lifecycle_receipts WHERE replacement_incarnation IS NOT NULL
                 )
                 WHERE public_id>?1 OR (public_id=?1 AND incarnation>?2)
                 ORDER BY public_id,incarnation LIMIT ?3",
            )
            .map_err(|error| RestoreError::CorruptBackup(format!("prepare identity union: {error}")))?;
        let mut rows = statement
            .query(params![
                after_id,
                after_incarnation.as_slice(),
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("query identity union: {error}"))
            })?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step identity union: {error}")))?
        {
            let length: i64 = row.get(0).map_err(|error| {
                RestoreError::CorruptBackup(format!("read identity length: {error}"))
            })?;
            let id: Option<String> = row.get(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read mapped stream name: {error}"))
            })?;
            let incarnation: Option<Vec<u8>> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read mapped incarnation: {error}"))
            })?;
            let length = usize::try_from(length)
                .map_err(|_| RestoreError::CorruptBackup("invalid stream-name length".into()))?;
            let charge = length
                .checked_mul(2)
                .and_then(|value| value.checked_add(128))
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                break;
            }
            let id = StreamId::new(id.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid stream name in identity union".into())
            })?)
            .map_err(|_| RestoreError::CorruptBackup("invalid stream name".into()))?;
            let incarnation = fixed::<16>(incarnation, "incarnation")?;
            bytes += charge;
            batch.push((id, incarnation));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin mapping page", error))?;
        for (id, old) in &batch {
            let new = super::new_incarnation();
            transaction
                .execute(
                    "INSERT INTO restore_mappings(old_public_id,old_incarnation,new_incarnation) VALUES(?1,?2,?3)",
                    params![id.as_str(), old.as_slice(), new.0.as_slice()],
                )
                .map_err(|error| map_sql_write("insert incarnation mapping", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit mapping page", error))?;
        let (last_id, last_incarnation) = batch.last().expect("nonempty mapping batch");
        after_id = last_id.as_str().to_owned();
        after_incarnation = *last_incarnation;
        count = count
            .checked_add(batch.len() as u64)
            .ok_or(RestoreError::CapacityExceeded)?;
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(count)
}

fn mapped_incarnation(target: &Connection, id: &str, old: &[u8; 16]) -> RestoreResult<[u8; 16]> {
    let value: Vec<u8> = target
        .query_row(
            "SELECT new_incarnation FROM restore_mappings WHERE old_public_id=?1 AND old_incarnation=?2",
            params![id, old.as_slice()],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("missing identity mapping: {error}")))?;
    fixed(Some(value), "mapped incarnation")
}

fn import_lifetimes(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = 0_i64;
    loop {
        let mut statement = source.prepare(
            "SELECT stream_key,
                    CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                    CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END,
                    CASE WHEN typeof(floor)='blob' AND length(floor)=8 THEN floor END,
                    CASE WHEN typeof(tail)='blob' AND length(tail)=8 THEN tail END,
                    CASE WHEN typeof(retired)='integer' AND retired IN (0,1) THEN retired END
             FROM event_streams WHERE stream_key>?1 ORDER BY stream_key LIMIT ?2",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare lifetimes: {error}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| RestoreError::CorruptBackup(format!("query lifetimes: {error}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step lifetimes: {error}")))?
        {
            let key: i64 = row.get(0).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime key: {error}"))
            })?;
            let id: Option<String> = row.get(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime name: {error}"))
            })?;
            let old: Option<Vec<u8>> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime incarnation: {error}"))
            })?;
            let floor: Option<Vec<u8>> = row.get(3).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime floor: {error}"))
            })?;
            let tail: Option<Vec<u8>> = row.get(4).map_err(|error| {
                RestoreError::CorruptBackup(format!("read lifetime tail: {error}"))
            })?;
            let retired: Option<i64> = row.get(5).map_err(|error| {
                RestoreError::CorruptBackup(format!("read retired flag: {error}"))
            })?;
            let id = StreamId::new(
                id.ok_or_else(|| RestoreError::CorruptBackup("invalid lifetime name".into()))?,
            )
            .map_err(|_| RestoreError::CorruptBackup("invalid lifetime name".into()))?;
            let old = fixed::<16>(old, "lifetime incarnation")?;
            let floor = fixed::<8>(floor, "lifetime floor")?;
            let tail = fixed::<8>(tail, "lifetime tail")?;
            if floor > tail || retired.is_none() {
                return Err(RestoreError::CorruptBackup(
                    "invalid lifetime metadata".into(),
                ));
            }
            let charge = id
                .as_str()
                .len()
                .checked_add(256)
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|total| total > config.page.max_bytes)
            {
                break;
            }
            bytes += charge;
            batch.push((key, id, old, floor, tail, retired.unwrap()));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|error| map_sql_write("begin lifetime page", error))?;
        for (old_key, id, old, floor, tail, retired) in &batch {
            let new = mapped_incarnation(&transaction, id.as_str(), old)?;
            transaction.execute(
                "INSERT INTO event_streams(public_id,incarnation,floor,tail,retired) VALUES(?1,?2,?3,?4,?5)",
                params![id.as_str(),new.as_slice(),floor.as_slice(),tail.as_slice(),retired],
            ).map_err(|error| map_sql_write("insert restored lifetime", error))?;
            let new_key = transaction.last_insert_rowid();
            transaction.execute("INSERT INTO restore_lifetime_keys(old_stream_key,new_stream_key) VALUES(?1,?2)", params![old_key,new_key])
                .map_err(|error| map_sql_write("map lifetime key", error))?;
        }
        transaction
            .commit()
            .map_err(|error| map_sql_write("commit lifetime page", error))?;
        after = batch.last().unwrap().0;
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn fixed<const N: usize>(value: Option<Vec<u8>>, label: &str) -> RestoreResult<[u8; N]> {
    value
        .ok_or_else(|| RestoreError::CorruptBackup(format!("invalid {label}")))?
        .try_into()
        .map_err(|_| RestoreError::CorruptBackup(format!("invalid {label}")))
}

fn import_records(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut lifetimes = source
        .prepare("SELECT stream_key,floor,tail FROM event_streams ORDER BY stream_key")
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("prepare record lifetimes: {error}"))
        })?;
    let lifetime_rows = lifetimes
        .query_map([], |row| {
            Ok((
                row.get::<_, i64>(0)?,
                row.get::<_, Vec<u8>>(1)?,
                row.get::<_, Vec<u8>>(2)?,
            ))
        })
        .map_err(|error| RestoreError::CorruptBackup(format!("query record lifetimes: {error}")))?;
    for lifetime in lifetime_rows {
        let (old_key, floor, tail) = lifetime.map_err(|error| {
            RestoreError::CorruptBackup(format!("read record lifetime: {error}"))
        })?;
        let floor = u64::from_be_bytes(
            floor
                .try_into()
                .map_err(|_| RestoreError::CorruptBackup("invalid record floor".into()))?,
        );
        let tail = u64::from_be_bytes(
            tail.try_into()
                .map_err(|_| RestoreError::CorruptBackup("invalid record tail".into()))?,
        );
        if floor > tail {
            return Err(RestoreError::CorruptBackup(
                "record floor exceeds tail".into(),
            ));
        }
        let (record_count, minimum, maximum): (i64, Option<Vec<u8>>, Option<Vec<u8>>) = source
            .query_row(
                "SELECT count,
                        CASE WHEN minimum IS NULL OR (typeof(minimum)='blob' AND length(minimum)=8) THEN minimum END,
                        CASE WHEN maximum IS NULL OR (typeof(maximum)='blob' AND length(maximum)=8) THEN maximum END
                 FROM (SELECT count(*) AS count,min(offset) AS minimum,max(offset) AS maximum FROM event_records WHERE stream_key=?1)",
                params![old_key],
                |row| Ok((row.get(0)?,row.get(1)?,row.get(2)?)),
            )
            .map_err(|error| RestoreError::CorruptBackup(format!("validate record extent: {error}")))?;
        let expected_count = tail - floor;
        if u64::try_from(record_count).ok() != Some(expected_count)
            || (expected_count == 0 && (minimum.is_some() || maximum.is_some()))
            || (expected_count > 0
                && (fixed::<8>(minimum, "minimum record offset")? != (floor + 1).to_be_bytes()
                    || fixed::<8>(maximum, "maximum record offset")? != tail.to_be_bytes()))
        {
            return Err(RestoreError::CorruptBackup(
                "record extent does not match stored floor and tail".into(),
            ));
        }
        let new_key: i64 = target
            .query_row(
                "SELECT new_stream_key FROM restore_lifetime_keys WHERE old_stream_key=?1",
                params![old_key],
                |row| row.get(0),
            )
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("missing lifetime key mapping: {error}"))
            })?;
        let mut after = floor;
        while after < tail {
            let mut statement = source.prepare(
                "SELECT octet_length(event_id),octet_length(schema_id),octet_length(payload),
                        CASE WHEN typeof(offset)='blob' AND length(offset)=8 THEN offset END,
                        CASE WHEN typeof(event_id)='text' AND octet_length(event_id) BETWEEN 1 AND 256 THEN event_id END,
                        CASE WHEN typeof(schema_id)='text' AND octet_length(schema_id) BETWEEN 1 AND 256 THEN schema_id END,
                        CASE WHEN typeof(schema_version)='integer' THEN schema_version END,
                        CASE WHEN typeof(payload)='blob' THEN payload END
                 FROM event_records WHERE stream_key=?1 AND offset>?2 ORDER BY offset LIMIT ?3",
            ).map_err(|error| RestoreError::CorruptBackup(format!("prepare record page: {error}")))?;
            let mut rows = statement
                .query(params![
                    old_key,
                    after.to_be_bytes().as_slice(),
                    i64::try_from(config.page.max_records)
                        .map_err(|_| RestoreError::CapacityExceeded)?
                ])
                .map_err(|error| {
                    RestoreError::CorruptBackup(format!("query record page: {error}"))
                })?;
            let mut batch = Vec::with_capacity(config.page.max_records.min(256));
            let mut bytes = 0usize;
            while let Some(row) = rows.next().map_err(|error| {
                RestoreError::CorruptBackup(format!("step record page: {error}"))
            })? {
                let event_len = usize::try_from(row.get::<_, i64>(0).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read event length: {error}"))
                })?)
                .map_err(|_| RestoreError::CorruptBackup("invalid event length".into()))?;
                let schema_len = usize::try_from(row.get::<_, i64>(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read schema length: {error}"))
                })?)
                .map_err(|_| RestoreError::CorruptBackup("invalid schema length".into()))?;
                let payload_len = usize::try_from(row.get::<_, i64>(2).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read payload length: {error}"))
                })?)
                .map_err(|_| RestoreError::CorruptBackup("invalid payload length".into()))?;
                let charge = event_len
                    .checked_add(schema_len)
                    .and_then(|v| v.checked_add(payload_len))
                    .and_then(|v| v.checked_add(128))
                    .ok_or(RestoreError::CapacityExceeded)?;
                if batch.is_empty() && charge > config.page.max_bytes {
                    return Err(RestoreError::CapacityExceeded);
                }
                if bytes
                    .checked_add(charge)
                    .is_none_or(|total| total > config.page.max_bytes)
                {
                    break;
                }
                let offset = fixed::<8>(
                    row.get::<_, Option<Vec<u8>>>(3).map_err(|error| {
                        RestoreError::CorruptBackup(format!("read record offset: {error}"))
                    })?,
                    "record offset",
                )?;
                let event: Option<String> = row.get(4).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read event ID: {error}"))
                })?;
                let schema: Option<String> = row.get(5).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read schema ID: {error}"))
                })?;
                let version: Option<i64> = row.get(6).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read schema version: {error}"))
                })?;
                let payload: Option<Vec<u8>> = row.get(7).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read record payload: {error}"))
                })?;
                let offset_value = u64::from_be_bytes(offset);
                let expected = after
                    .checked_add(batch.len() as u64 + 1)
                    .ok_or(RestoreError::CapacityExceeded)?;
                if offset_value != expected
                    || offset_value > tail
                    || event.is_none()
                    || schema.is_none()
                    || version.is_none()
                    || payload.is_none()
                {
                    return Err(RestoreError::CorruptBackup(
                        "invalid or noncontiguous record page".into(),
                    ));
                }
                bytes += charge;
                batch.push((
                    offset,
                    event.unwrap(),
                    schema.unwrap(),
                    version.unwrap(),
                    payload.unwrap(),
                ));
            }
            drop(rows);
            drop(statement);
            if batch.is_empty() {
                return Err(RestoreError::CorruptBackup(
                    "record history ends before tail".into(),
                ));
            }
            let transaction = target
                .transaction_with_behavior(TransactionBehavior::Immediate)
                .map_err(|error| map_sql_write("begin record page", error))?;
            for (offset, event, schema, version, payload) in &batch {
                transaction.execute(
                    "INSERT INTO event_records(stream_key,offset,event_id,schema_id,schema_version,payload) VALUES(?1,?2,?3,?4,?5,?6)",
                    params![new_key,offset.as_slice(),event,schema,version,payload],
                ).map_err(|error| map_sql_write("insert restored record", error))?;
            }
            transaction
                .commit()
                .map_err(|error| map_sql_write("commit record page", error))?;
            after = u64::from_be_bytes(batch.last().unwrap().0);
            enforce_staging_limit(target, config.max_staging_bytes)?;
        }
    }
    Ok(())
}

fn import_names(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = String::new();
    loop {
        let mut statement = source.prepare(
            "SELECT CASE WHEN typeof(public_id)='text' AND octet_length(public_id) BETWEEN 1 AND 256 THEN public_id END,
                    CASE WHEN typeof(latest_incarnation)='blob' AND length(latest_incarnation)=16 THEN latest_incarnation END,
                    active_stream_key
             FROM event_stream_names WHERE public_id>?1 ORDER BY public_id LIMIT ?2",
        ).map_err(|error| RestoreError::CorruptBackup(format!("prepare names: {error}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|error| RestoreError::CorruptBackup(format!("query names: {error}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|error| RestoreError::CorruptBackup(format!("step names: {error}")))?
        {
            let id: Option<String> = row
                .get(0)
                .map_err(|error| RestoreError::CorruptBackup(format!("read name: {error}")))?;
            let incarnation = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(1).map_err(|error| {
                    RestoreError::CorruptBackup(format!("read latest incarnation: {error}"))
                })?,
                "latest incarnation",
            )?;
            let active: Option<i64> = row.get(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read active lifetime: {error}"))
            })?;
            let id = StreamId::new(
                id.ok_or_else(|| RestoreError::CorruptBackup("invalid stream name".into()))?,
            )
            .map_err(|_| RestoreError::CorruptBackup("invalid stream name".into()))?;
            let charge = id
                .as_str()
                .len()
                .checked_add(256)
                .ok_or(RestoreError::CapacityExceeded)?;
            if batch.is_empty() && charge > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(charge)
                .is_none_or(|v| v > config.page.max_bytes)
            {
                break;
            }
            bytes += charge;
            batch.push((id, incarnation, active));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| map_sql_write("begin name page", e))?;
        for (id, old, active) in &batch {
            let new = mapped_incarnation(&transaction, id.as_str(), old)?;
            let new_active = active
                .map(|key| {
                    transaction.query_row(
                        "SELECT new_stream_key FROM restore_lifetime_keys WHERE old_stream_key=?1",
                        params![key],
                        |r| r.get::<_, i64>(0),
                    )
                })
                .transpose()
                .map_err(|e| {
                    RestoreError::CorruptBackup(format!("missing active lifetime mapping: {e}"))
                })?;
            transaction.execute("INSERT INTO event_stream_names(public_id,latest_incarnation,active_stream_key) VALUES(?1,?2,?3)",params![id.as_str(),new.as_slice(),new_active]).map_err(|e|map_sql_write("insert restored name",e))?;
        }
        transaction
            .commit()
            .map_err(|e| map_sql_write("commit name page", e))?;
        after = batch.last().unwrap().0.as_str().to_owned();
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn import_receipts(
    source: &Connection,
    target: &mut Connection,
    config: &RestoreConfig,
) -> RestoreResult<()> {
    let mut after = String::new();
    loop {
        let mut statement=source.prepare("SELECT octet_length(operation_id),octet_length(expected_public_id),
                    CASE WHEN typeof(operation_id)='text' AND octet_length(operation_id) BETWEEN 1 AND 256 THEN operation_id END,
                    CASE WHEN typeof(action)='integer' AND action IN (0,1) THEN action END,
                    CASE WHEN typeof(expected_public_id)='text' AND octet_length(expected_public_id) BETWEEN 1 AND 256 THEN expected_public_id END,
                    CASE WHEN typeof(expected_incarnation)='blob' AND length(expected_incarnation)=16 THEN expected_incarnation END,
                    CASE WHEN replacement_incarnation IS NULL OR (typeof(replacement_incarnation)='blob' AND length(replacement_incarnation)=16) THEN 1 ELSE 0 END,
                    replacement_incarnation,
                    CASE WHEN typeof(charge)='integer' AND charge>=0 THEN charge END
                 FROM lifecycle_receipts WHERE operation_id>?1 ORDER BY operation_id LIMIT ?2")
            .map_err(|e|RestoreError::CorruptBackup(format!("prepare receipts: {e}")))?;
        let mut rows = statement
            .query(params![
                after,
                i64::try_from(config.page.max_records)
                    .map_err(|_| RestoreError::CapacityExceeded)?
            ])
            .map_err(|e| RestoreError::CorruptBackup(format!("query receipts: {e}")))?;
        let mut batch = Vec::with_capacity(config.page.max_records.min(256));
        let mut bytes = 0usize;
        while let Some(row) = rows
            .next()
            .map_err(|e| RestoreError::CorruptBackup(format!("step receipts: {e}")))?
        {
            let op_len: i64 = row.get(0).map_err(|e| {
                RestoreError::CorruptBackup(format!("read receipt operation length: {e}"))
            })?;
            let id_len: i64 = row.get(1).map_err(|e| {
                RestoreError::CorruptBackup(format!("read receipt name length: {e}"))
            })?;
            let op: Option<String> = row.get(2).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt op: {e}"))
            })?;
            let action: Option<i64> = row.get(3).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt action: {e}"))
            })?;
            let id: Option<String> = row.get(4).map_err(|e| {
                RestoreError::CorruptBackup(format!("read restore receipt name: {e}"))
            })?;
            let expected = fixed::<16>(
                row.get::<_, Option<Vec<u8>>>(5).map_err(|e| {
                    RestoreError::CorruptBackup(format!("read expected incarnation: {e}"))
                })?,
                "expected incarnation",
            )?;
            let replacement_valid: i64 = row.get(6).map_err(|e| {
                RestoreError::CorruptBackup(format!("read replacement validity: {e}"))
            })?;
            let replacement: Option<Vec<u8>> = row.get(7).map_err(|e| {
                RestoreError::CorruptBackup(format!("read replacement incarnation: {e}"))
            })?;
            let charge: Option<i64> = row
                .get(8)
                .map_err(|e| RestoreError::CorruptBackup(format!("read receipt charge: {e}")))?;
            let logical = usize::try_from(op_len)
                .ok()
                .and_then(|op| {
                    usize::try_from(id_len)
                        .ok()
                        .and_then(|id| op.checked_add(id))
                })
                .and_then(|v| v.checked_add(256))
                .ok_or_else(|| {
                    RestoreError::CorruptBackup("invalid lifecycle receipt lengths".into())
                })?;
            if batch.is_empty() && logical > config.page.max_bytes {
                return Err(RestoreError::CapacityExceeded);
            }
            if bytes
                .checked_add(logical)
                .is_none_or(|v| v > config.page.max_bytes)
            {
                break;
            }
            let op = op.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle operation ID".into())
            })?;
            let id = id.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle stream name".into())
            })?;
            let action = action
                .ok_or_else(|| RestoreError::CorruptBackup("invalid lifecycle action".into()))?;
            let charge = charge.ok_or_else(|| {
                RestoreError::CorruptBackup("invalid lifecycle receipt charge".into())
            })?;
            if replacement_valid != 1
                || (action == 0 && replacement.is_some())
                || (action == 1 && replacement.is_none())
                || RestoreOperationId::new(&op).is_err()
                || StreamId::new(&id).is_err()
                || usize::try_from(charge).ok() != Some(logical)
            {
                return Err(RestoreError::CorruptBackup(
                    "invalid lifecycle receipt".into(),
                ));
            }
            bytes += logical;
            batch.push((op, action, id, expected, replacement, charge));
        }
        drop(rows);
        drop(statement);
        if batch.is_empty() {
            break;
        }
        let transaction = target
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| map_sql_write("begin receipt page", e))?;
        for (op, action, id, expected, replacement, charge) in &batch {
            let new_expected = mapped_incarnation(&transaction, id, expected)?;
            let new_replacement = replacement
                .as_ref()
                .map(|old| {
                    fixed::<16>(Some(old.clone()), "replacement incarnation")
                        .and_then(|old| mapped_incarnation(&transaction, id, &old))
                })
                .transpose()?;
            transaction.execute("INSERT INTO lifecycle_receipts(operation_id,action,expected_public_id,expected_incarnation,replacement_incarnation,charge) VALUES(?1,?2,?3,?4,?5,?6)",params![op,action,id,new_expected.as_slice(),new_replacement.as_ref().map(|v|v.as_slice()),charge]).map_err(|e|map_sql_write("insert restored receipt",e))?;
        }
        transaction
            .commit()
            .map_err(|e| map_sql_write("commit receipt page", e))?;
        after = batch.last().unwrap().0.clone();
        enforce_staging_limit(target, config.max_staging_bytes)?;
    }
    Ok(())
}

fn validate_import(target: &Connection) -> RestoreResult<()> {
    validate_lifecycle_counters(target).map_err(map_store_error)?;
    let foreign_violation: bool = target
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
            [],
            |row| row.get(0),
        )
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("validate restored foreign keys: {error}"))
        })?;
    if foreign_violation {
        return Err(RestoreError::CorruptBackup(
            "restored database contains a foreign-key violation".into(),
        ));
    }
    let quick: String = target
        .query_row("PRAGMA quick_check", [], |row| row.get(0))
        .map_err(|error| {
            RestoreError::CorruptBackup(format!("validate restored SQLite: {error}"))
        })?;
    if quick != "ok" {
        return Err(RestoreError::CorruptBackup(format!(
            "restored SQLite quick_check failed: {quick}"
        )));
    }
    Ok(())
}

fn complete_staging(
    target: &mut Connection,
    request: &RestoreRequest,
    destination: &Path,
) -> RestoreResult<()> {
    let destination = destination
        .to_str()
        .ok_or_else(|| RestoreError::InvalidConfig("canonical destination must be UTF-8".into()))?;
    let transaction = target
        .transaction_with_behavior(TransactionBehavior::Immediate)
        .map_err(|error| map_sql_write("begin staging completion", error))?;
    let matches: bool = transaction
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM restore_metadata WHERE singleton=1 AND operation_id=?1 AND backup_identity=?2 AND destination=?3)",
            params![request.operation_id.as_str(),request.backup_identity.0.as_slice(),destination],
            |row| row.get(0),
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("validate restore identity: {error}")))?;
    if !matches {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    }
    transaction
        .execute("DROP TABLE restore_lifetime_keys", [])
        .map_err(|error| map_sql_write("drop staging key map", error))?;
    transaction
        .execute(
            "UPDATE event_stream_metadata SET restore_incomplete=2 WHERE singleton=1 AND restore_incomplete=1",
            [],
        )
        .map_err(|error| map_sql_write("mark restore complete", error))?;
    transaction
        .commit()
        .map_err(|error| map_sql_write("commit staging completion", error))
}

fn read_published_receipt(
    destination: &Path,
    request: &RestoreRequest,
) -> RestoreResult<RestoreReceipt> {
    let conn = open_read_only(destination)?;
    let row: Option<(i64, i64)> = conn
        .query_row(
            "SELECT mapping_count,restore_incomplete FROM restore_metadata,event_stream_metadata
             WHERE restore_metadata.singleton=1 AND event_stream_metadata.singleton=1
               AND operation_id=?1 AND backup_identity=?2 AND destination=?3",
            params![
                request.operation_id.as_str(),
                request.backup_identity.0.as_slice(),
                destination.to_str()
            ],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()
        .map_err(|_| RestoreError::DestinationExists(Box::new(destination.to_owned())))?;
    let Some((mapping_count, state)) = row else {
        let same_operation: bool = conn
            .query_row(
                "SELECT EXISTS(SELECT 1 FROM restore_metadata WHERE operation_id=?1)",
                params![request.operation_id.as_str()],
                |row| row.get(0),
            )
            .unwrap_or(false);
        if same_operation {
            return Err(RestoreError::RequestConflict {
                operation_id: request.operation_id.clone(),
            });
        }
        return Err(RestoreError::DestinationExists(Box::new(
            destination.to_owned(),
        )));
    };
    drop(conn);
    match state {
        0 => {
            let conn = open_read_only(destination)?;
            if inspect_existing_format(&conn).map_err(map_store_error)? != Some(2) {
                return Err(RestoreError::CorruptBackup(
                    "published restore format is invalid".into(),
                ));
            }
        }
        2 => finalize_published_marker(destination)?,
        _ => {
            return Err(RestoreError::PublicationUnknown {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination.to_owned()),
            })
        }
    }
    Ok(RestoreReceipt {
        operation_id: request.operation_id.clone(),
        backup_identity: request.backup_identity,
        destination: destination.to_owned(),
        mapping_count: u64::try_from(mapping_count)
            .map_err(|_| RestoreError::CorruptBackup("invalid mapping count".into()))?,
    })
}

fn validate_staging_owner(
    staging: &Path,
    request: &RestoreRequest,
    destination: &Path,
) -> RestoreResult<bool> {
    let conn = open_read_only(staging)?;
    let row: Option<i64> = conn
        .query_row(
            "SELECT restore_incomplete FROM restore_metadata,event_stream_metadata
             WHERE restore_metadata.singleton=1 AND event_stream_metadata.singleton=1
               AND operation_id=?1 AND backup_identity=?2 AND destination=?3",
            params![
                request.operation_id.as_str(),
                request.backup_identity.0.as_slice(),
                destination.to_str()
            ],
            |row| row.get(0),
        )
        .optional()
        .map_err(|error| RestoreError::CorruptBackup(format!("read staging identity: {error}")))?;
    let Some(incomplete) = row else {
        return Err(RestoreError::RequestConflict {
            operation_id: request.operation_id.clone(),
        });
    };
    if !matches!(incomplete, 1 | 2) {
        return Err(RestoreError::CorruptBackup("invalid staging state".into()));
    }
    Ok(incomplete == 1)
}

fn publish_no_replace(
    staging: &Path,
    destination: &Path,
    request: &RestoreRequest,
    failure: &AtomicU8,
) -> RestoreResult<()> {
    match std::fs::hard_link(staging, destination) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
            return Err(RestoreError::DestinationExists(Box::new(
                destination.to_owned(),
            )))
        }
        Err(error) => {
            return Err(RestoreError::StorageFailure(format!(
                "publish destination without replacement: {error}"
            )))
        }
    }
    if consume_failure(failure, SqliteRestoreFailureInjection::AfterDestinationLink) {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if sync_file(destination).is_err()
        || sync_directory(destination.parent().unwrap()).is_err()
        || finalize_published_marker(destination).is_err()
    {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if consume_failure(failure, SqliteRestoreFailureInjection::AfterPublishedMarker) {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    if std::fs::remove_file(staging).is_err()
        || sync_directory(destination.parent().unwrap()).is_err()
    {
        return Err(RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        });
    }
    Ok(())
}

fn consume_failure(failure: &AtomicU8, expected: SqliteRestoreFailureInjection) -> bool {
    failure
        .compare_exchange(expected as u8 + 1, 0, Ordering::AcqRel, Ordering::Acquire)
        .is_ok()
}

fn finalize_published_marker(destination: &Path) -> RestoreResult<()> {
    let conn = Connection::open_with_flags(
        destination,
        OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(|error| RestoreError::StorageFailure(format!("open published restore: {error}")))?;
    let changed = conn
        .execute(
            "UPDATE event_stream_metadata SET restore_incomplete=0 WHERE singleton=1 AND restore_incomplete=2",
            [],
        )
        .map_err(|error| map_sql_write("mark restore published", error))?;
    if changed != 1 {
        let state: i64 = conn
            .query_row(
                "SELECT restore_incomplete FROM event_stream_metadata WHERE singleton=1",
                [],
                |row| row.get(0),
            )
            .map_err(|error| {
                RestoreError::CorruptBackup(format!("read publication state: {error}"))
            })?;
        if state != 0 {
            return Err(RestoreError::CorruptBackup(
                "published restore has an invalid state".into(),
            ));
        }
    }
    conn.close().map_err(|(_, error)| {
        RestoreError::StorageFailure(format!("close published restore: {error}"))
    })?;
    sync_file(destination)
}

fn finish_staging_alias_if_owned(
    staging: &Path,
    destination: &Path,
    request: &RestoreRequest,
) -> RestoreResult<()> {
    if !staging.exists() {
        return Ok(());
    }
    if same_file(staging, destination)? {
        std::fs::remove_file(staging).map_err(|_| RestoreError::PublicationUnknown {
            operation_id: request.operation_id.clone(),
            destination: Box::new(destination.to_owned()),
        })?;
        sync_directory(destination.parent().unwrap()).map_err(|_| {
            RestoreError::PublicationUnknown {
                operation_id: request.operation_id.clone(),
                destination: Box::new(destination.to_owned()),
            }
        })?;
        return Ok(());
    }
    Err(RestoreError::IncompleteStaging {
        operation_id: request.operation_id.clone(),
        destination: Box::new(destination.to_owned()),
    })
}

#[cfg(unix)]
fn same_file(left: &Path, right: &Path) -> RestoreResult<bool> {
    use std::os::unix::fs::MetadataExt;
    let left = std::fs::metadata(left)
        .map_err(|error| RestoreError::StorageFailure(format!("inspect staging alias: {error}")))?;
    let right = std::fs::metadata(right).map_err(|error| {
        RestoreError::StorageFailure(format!("inspect destination alias: {error}"))
    })?;
    Ok(left.dev() == right.dev() && left.ino() == right.ino())
}

#[cfg(not(unix))]
fn same_file(_left: &Path, _right: &Path) -> RestoreResult<bool> {
    Ok(false)
}

fn sync_file(path: &Path) -> RestoreResult<()> {
    OpenOptions::new()
        .read(true)
        .write(true)
        .open(path)
        .and_then(|file| file.sync_all())
        .map_err(|error| {
            RestoreError::StorageFailure(format!("synchronize {}: {error}", path.display()))
        })
}

fn sync_directory(path: &Path) -> RestoreResult<()> {
    File::open(path)
        .and_then(|file| file.sync_all())
        .map_err(|error| {
            RestoreError::StorageFailure(format!(
                "synchronize directory {}: {error}",
                path.display()
            ))
        })
}

fn read_mapping_blocking(
    root: &Path,
    receipt: &RestoreReceipt,
    after: Option<&StreamKey>,
    limits: PageLimits,
    _config: &RestoreConfig,
) -> RestoreResult<MappingPage> {
    let destination = resolve_receipt_destination(root, &receipt.destination)?;
    let _ownership =
        Ownership::acquire_restore_destination(&destination).map_err(map_store_error)?;
    let request = RestoreRequest {
        operation_id: receipt.operation_id.clone(),
        backup_identity: receipt.backup_identity,
        source: PathBuf::from("unused-for-mapping"),
        destination: destination.clone(),
    };
    let stored = read_published_receipt(&destination, &request)?;
    if &stored != receipt {
        return Err(RestoreError::RequestConflict {
            operation_id: receipt.operation_id.clone(),
        });
    }
    let conn = open_read_only(&destination)?;
    let (after_id, after_incarnation) = after
        .map(|key| (key.id.as_str(), key.incarnation.0))
        .unwrap_or(("", [0; 16]));
    let mut statement = conn
        .prepare(
            "SELECT old_public_id,old_incarnation,new_incarnation FROM restore_mappings
         WHERE old_public_id>?1 OR (old_public_id=?1 AND old_incarnation>?2)
         ORDER BY old_public_id,old_incarnation LIMIT ?3",
        )
        .map_err(|error| RestoreError::CorruptBackup(format!("prepare mapping page: {error}")))?;
    let mut rows = statement
        .query(params![
            after_id,
            after_incarnation.as_slice(),
            i64::try_from(limits.max_records).map_err(|_| RestoreError::CapacityExceeded)?
        ])
        .map_err(|error| RestoreError::CorruptBackup(format!("query mapping page: {error}")))?;
    let mut entries = Vec::with_capacity(limits.max_records.min(256));
    let mut bytes = 0usize;
    while let Some(row) = rows
        .next()
        .map_err(|error| RestoreError::CorruptBackup(format!("step mapping page: {error}")))?
    {
        let id: String = row
            .get(0)
            .map_err(|error| RestoreError::CorruptBackup(format!("read mapped name: {error}")))?;
        let old = fixed::<16>(
            Some(row.get::<_, Vec<u8>>(1).map_err(|error| {
                RestoreError::CorruptBackup(format!("read old mapping: {error}"))
            })?),
            "old mapping",
        )?;
        let new = fixed::<16>(
            Some(row.get::<_, Vec<u8>>(2).map_err(|error| {
                RestoreError::CorruptBackup(format!("read new mapping: {error}"))
            })?),
            "new mapping",
        )?;
        let id = StreamId::new(id)
            .map_err(|_| RestoreError::CorruptBackup("invalid mapping name".into()))?;
        let entry = IncarnationMapping {
            old: StreamKey {
                id: id.clone(),
                incarnation: IncarnationId(old),
            },
            new: StreamKey {
                id,
                incarnation: IncarnationId(new),
            },
        };
        let charge = entry
            .accounted_bytes()
            .ok_or(RestoreError::CapacityExceeded)?;
        if entries.is_empty() && charge > limits.max_bytes {
            return Err(RestoreError::CapacityExceeded);
        }
        if bytes
            .checked_add(charge)
            .is_none_or(|v| v > limits.max_bytes)
        {
            break;
        }
        bytes += charge;
        entries.push(entry);
    }
    drop(rows);
    drop(statement);
    let next_after = entries.last().map(|entry| entry.old.clone());
    let complete=match &next_after {
        None=>true,
        Some(last)=>!conn.query_row("SELECT EXISTS(SELECT 1 FROM restore_mappings WHERE old_public_id>?1 OR (old_public_id=?1 AND old_incarnation>?2))",params![last.id.as_str(),last.incarnation.0.as_slice()],|r|r.get::<_,bool>(0)).map_err(|e|RestoreError::CorruptBackup(format!("check mapping completion: {e}")))?,
    };
    Ok(MappingPage {
        entries,
        next_after,
        complete,
    })
}

fn resolve_receipt_destination(root: &Path, path: &Path) -> RestoreResult<PathBuf> {
    if !path.is_absolute() {
        return resolve_destination(root, path);
    }
    let name = path.file_name().ok_or_else(|| {
        RestoreError::InvalidConfig("mapping destination needs a file name".into())
    })?;
    let parent = path
        .parent()
        .ok_or_else(|| RestoreError::InvalidConfig("mapping destination has no parent".into()))?
        .canonicalize()
        .map_err(|error| {
            RestoreError::InvalidConfig(format!("mapping destination parent: {error}"))
        })?;
    if !parent.starts_with(root) {
        return Err(RestoreError::InvalidConfig(
            "mapping destination escapes root".into(),
        ));
    }
    Ok(parent.join(name))
}

fn cleanup_staging_blocking(
    root: &Path,
    request: &RestoreRequest,
    _config: &RestoreConfig,
) -> RestoreResult<()> {
    let destination = resolve_destination(root, &request.destination)?;
    let _ownership =
        Ownership::acquire_restore_destination(&destination).map_err(map_store_error)?;
    let staging = staging_path(&destination, &request.operation_id)?;
    if !staging.exists() {
        return Ok(());
    }
    validate_staging_owner(&staging, request, &destination)?;
    let mut failed = Vec::new();
    for path in [
        staging.clone(),
        PathBuf::from(format!("{}-journal", staging.display())),
        PathBuf::from(format!("{}-wal", staging.display())),
        PathBuf::from(format!("{}-shm", staging.display())),
    ] {
        if let Err(error) = std::fs::remove_file(&path) {
            if error.kind() != std::io::ErrorKind::NotFound {
                failed.push(path)
            }
        }
    }
    if failed.is_empty() {
        sync_directory(destination.parent().unwrap())?;
        Ok(())
    } else {
        Err(RestoreError::StagingCleanupFailed { paths: failed })
    }
}
