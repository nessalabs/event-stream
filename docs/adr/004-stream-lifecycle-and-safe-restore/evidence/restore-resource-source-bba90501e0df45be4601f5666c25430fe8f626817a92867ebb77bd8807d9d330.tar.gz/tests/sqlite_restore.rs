#![cfg(feature = "sqlite")]

use event_stream::{
    infrastructure::{
        SqliteFailureInjection, SqliteOptions, SqliteRestoreBackend, SqliteRestoreFailureInjection,
        SqliteRestoreManager, SqliteStore,
    },
    CleanupLimits, Error, EventId, EventStore, LifecycleAction, LifecycleOperationId,
    LifecycleRequest, LifecycleStore, NewEvent, PageLimits, Payload, RestoreConfig, RestoreError,
    RestoreOperationId, RestoreReceipt, RestoreRequest, SchemaId, SchemaRef, StreamId,
};
use rusqlite::Connection;
use std::path::PathBuf;
#[cfg(feature = "test-support")]
use std::{
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    },
    time::{Duration, Instant},
};

#[cfg(feature = "test-support")]
use event_stream::infrastructure::{SqliteRestoreObserver, SqliteRestoreStage};

#[cfg(feature = "test-support")]
#[derive(Debug, Default)]
struct CommitObserver {
    record_pages: AtomicUsize,
}

#[cfg(feature = "test-support")]
impl SqliteRestoreObserver for CommitObserver {
    fn observe(&self, stage: SqliteRestoreStage) {
        if stage == SqliteRestoreStage::RecordPageCommitted {
            self.record_pages.fetch_add(1, Ordering::Relaxed);
        }
    }
}

#[cfg(feature = "test-support")]
struct ChildGuard(Option<Child>);

#[cfg(feature = "test-support")]
impl ChildGuard {
    fn kill_and_wait(mut self) -> std::process::ExitStatus {
        let mut child = self.0.take().unwrap();
        child.kill().unwrap();
        child.wait().unwrap()
    }
}

#[cfg(feature = "test-support")]
impl Drop for ChildGuard {
    fn drop(&mut self) {
        if let Some(child) = &mut self.0 {
            let _ = child.kill();
            let _ = child.wait();
        }
    }
}

fn temp_root(label: &str) -> PathBuf {
    let root = std::env::temp_dir().join(format!(
        "event-stream-restore-{label}-{}",
        uuid::Uuid::new_v4()
    ));
    std::fs::create_dir(&root).unwrap();
    root.canonicalize().unwrap()
}

async fn simple_restore_fixture(
    label: &str,
    failure: Option<SqliteRestoreFailureInjection>,
) -> (PathBuf, PathBuf, RestoreRequest, SqliteRestoreManager) {
    let root = temp_root(label);
    let source = root.join("backup.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("live").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("one", b"restore publication state"))
        .await
        .unwrap();
    store.close().await.unwrap();

    let backend = match failure {
        Some(failure) => SqliteRestoreBackend::new(&root)
            .unwrap()
            .with_failure_injection(failure),
        None => SqliteRestoreBackend::new(&root).unwrap(),
    };
    let manager = SqliteRestoreManager::new(backend, RestoreConfig::default()).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let request = RestoreRequest {
        operation_id: RestoreOperationId::new(format!("restore-{label}")).unwrap(),
        backup_identity: identity,
        source: source.clone(),
        destination: PathBuf::from("restored.sqlite3"),
    };
    (root, source, request, manager)
}

fn staging_file(root: &std::path::Path) -> PathBuf {
    let mut matches = std::fs::read_dir(root)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| {
            path.file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| {
                    name.starts_with(".event-stream-restore-") && name.ends_with(".sqlite3")
                })
        });
    let staging = matches.next().expect("restore staging file");
    assert!(matches.next().is_none(), "one deterministic staging file");
    staging
}

fn owner_directory(root: &std::path::Path) -> PathBuf {
    let mut matches = std::fs::read_dir(root)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| {
            path.file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| {
                    name.starts_with(".event-stream-restore-") && name.ends_with(".owner")
                })
        });
    let owner = matches.next().expect("restore owner directory");
    assert!(matches.next().is_none(), "one operation owner directory");
    owner
}

fn downgrade_to_legacy_format_two(path: &std::path::Path) {
    let conn = Connection::open(path).unwrap();
    conn.execute_batch(
        "BEGIN IMMEDIATE;
         CREATE TABLE event_stream_metadata_legacy(
           singleton INTEGER PRIMARY KEY CHECK(singleton=1),
           format_version INTEGER NOT NULL,
           lifecycle_receipt_count INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_count>=0),
           lifecycle_receipt_bytes INTEGER NOT NULL DEFAULT 0 CHECK(lifecycle_receipt_bytes>=0),
           retired_lifetime_count INTEGER NOT NULL DEFAULT 0 CHECK(retired_lifetime_count>=0),
           retired_metadata_bytes INTEGER NOT NULL DEFAULT 0 CHECK(retired_metadata_bytes>=0)
         );
         INSERT INTO event_stream_metadata_legacy
           SELECT singleton,format_version,lifecycle_receipt_count,lifecycle_receipt_bytes,
                  retired_lifetime_count,retired_metadata_bytes
           FROM event_stream_metadata;
         DROP TABLE event_stream_metadata;
         ALTER TABLE event_stream_metadata_legacy RENAME TO event_stream_metadata;
         DROP TABLE restore_metadata;
         DROP TABLE restore_mappings;
         COMMIT;",
    )
    .unwrap();
}

fn event(id: &str, payload: &[u8]) -> NewEvent {
    NewEvent {
        id: EventId::new(id).unwrap(),
        schema: SchemaRef {
            id: SchemaId::new("restore.test").unwrap(),
            version: 7,
        },
        payload: Payload::copy_from_slice(payload),
    }
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn record_pages_batch_across_streams_and_skip_empty_lifetimes() {
    let root = temp_root("cross-stream-record-pages");
    let source = root.join("backup.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    for index in 0..5 {
        let stream = store
            .create_if_absent(&StreamId::new(format!("stream-{index}")).unwrap())
            .await
            .unwrap();
        store
            .append_atomic(
                &stream,
                event(&format!("event-{index}"), &[index as u8; 16]),
            )
            .await
            .unwrap();
    }
    store
        .create_if_absent(&StreamId::new("empty-stream").unwrap())
        .await
        .unwrap();
    store.close().await.unwrap();

    let observer = Arc::new(CommitObserver::default());
    let backend = SqliteRestoreBackend::new(&root)
        .unwrap()
        .with_observer(observer.clone());
    let config = RestoreConfig {
        page: PageLimits {
            max_records: 2,
            max_bytes: 4096,
        },
        ..RestoreConfig::default()
    };
    let manager = SqliteRestoreManager::new(backend, config).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let receipt = manager
        .restore(RestoreRequest {
            operation_id: RestoreOperationId::new("cross-stream-pages").unwrap(),
            backup_identity: identity,
            source,
            destination: PathBuf::from("restored.sqlite3"),
        })
        .await
        .unwrap();
    assert_eq!(
        observer.record_pages.load(Ordering::Relaxed),
        3,
        "five one-record streams use ceil(5 / 2) record transactions"
    );

    let restored = SqliteStore::open(SqliteOptions::new(&receipt.destination))
        .await
        .unwrap();
    for index in 0..5 {
        let stream = restored
            .create_if_absent(&StreamId::new(format!("stream-{index}")).unwrap())
            .await
            .unwrap();
        let page = restored
            .read_range(
                &stream,
                0,
                1,
                PageLimits {
                    max_records: 1,
                    max_bytes: 4096,
                },
            )
            .await
            .unwrap();
        assert_eq!(page.records.len(), 1);
        assert_eq!(page.records[0].event.id.as_str(), format!("event-{index}"));
        assert_eq!(page.records[0].event.payload.as_bytes(), &[index as u8; 16]);
    }
    let empty = restored
        .create_if_absent(&StreamId::new("empty-stream").unwrap())
        .await
        .unwrap();
    assert_eq!(restored.bounds(&empty).await.unwrap().tail.offset, 0);
    restored.close().await.unwrap();
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn record_page_byte_limit_flushes_across_streams() {
    let root = temp_root("record-byte-pages");
    let source = root.join("backup.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    for index in 0..3 {
        let stream = store
            .create_if_absent(&StreamId::new(format!("byte-stream-{index}")).unwrap())
            .await
            .unwrap();
        store
            .append_atomic(
                &stream,
                event(&format!("byte-event-{index}"), &[index as u8; 500]),
            )
            .await
            .unwrap();
    }
    store.close().await.unwrap();

    let observer = Arc::new(CommitObserver::default());
    let backend = SqliteRestoreBackend::new(&root)
        .unwrap()
        .with_observer(observer.clone());
    let config = RestoreConfig {
        page: PageLimits {
            max_records: 16,
            max_bytes: 700,
        },
        ..RestoreConfig::default()
    };
    let manager = SqliteRestoreManager::new(backend, config).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    manager
        .restore(RestoreRequest {
            operation_id: RestoreOperationId::new("byte-pages").unwrap(),
            backup_identity: identity,
            source,
            destination: PathBuf::from("restored.sqlite3"),
        })
        .await
        .unwrap();
    assert_eq!(
        observer.record_pages.load(Ordering::Relaxed),
        3,
        "the 700-byte page budget admits one charged record per transaction"
    );
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn staging_quota_failure_never_publishes_the_destination() {
    let root = temp_root("staging-quota");
    let source = root.join("backup.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("quota-stream").unwrap())
        .await
        .unwrap();
    for index in 0..128 {
        store
            .append_atomic(
                &stream,
                event(&format!("quota-event-{index}"), &[index as u8; 1024]),
            )
            .await
            .unwrap();
    }
    store.close().await.unwrap();

    let config = RestoreConfig {
        max_staging_bytes: 128 * 1024,
        page: PageLimits {
            max_records: 16,
            max_bytes: 32 * 1024,
        },
        ..RestoreConfig::default()
    };
    let manager =
        SqliteRestoreManager::new(SqliteRestoreBackend::new(&root).unwrap(), config).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let request = RestoreRequest {
        operation_id: RestoreOperationId::new("staging-quota").unwrap(),
        backup_identity: identity,
        source,
        destination: PathBuf::from("restored.sqlite3"),
    };
    assert!(matches!(
        manager.restore(request).await,
        Err(RestoreError::CapacityExceeded)
    ));
    assert!(!root.join("restored.sqlite3").exists());
    let staging = staging_file(&root);
    let incomplete: i64 = Connection::open(staging)
        .unwrap()
        .query_row(
            "SELECT restore_incomplete FROM event_stream_metadata WHERE singleton=1",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(incomplete, 1);
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn restore_rejects_a_missing_record_before_the_declared_tail() {
    let (root, source, request, manager) = simple_restore_fixture("missing-tail", None).await;
    let connection = Connection::open(&source).unwrap();
    connection.execute("DELETE FROM event_records", []).unwrap();
    drop(connection);
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    assert!(matches!(
        manager
            .restore(RestoreRequest {
                backup_identity: identity,
                ..request
            })
            .await,
        Err(RestoreError::CorruptBackup(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn restore_rejects_schema_versions_outside_the_domain_range() {
    for (label, version) in [
        ("negative-version", -1_i64),
        ("large-version", 4_294_967_296),
    ] {
        let (root, source, request, manager) = simple_restore_fixture(label, None).await;
        let connection = Connection::open(&source).unwrap();
        connection
            .execute("UPDATE event_records SET schema_version=?1", [version])
            .unwrap();
        drop(connection);
        let identity = manager.inspect_backup(source.clone()).await.unwrap();
        assert!(matches!(
            manager
                .restore(RestoreRequest {
                    backup_identity: identity,
                    ..request
                })
                .await,
            Err(RestoreError::CorruptBackup(_))
        ));
        assert!(!root.join("restored.sqlite3").exists());
        std::fs::remove_dir_all(root).unwrap();
    }
}

#[tokio::test]
async fn logical_restore_rewrites_full_identity_union_and_survives_restart() {
    let root = temp_root("roundtrip");
    let source = root.join("backup.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();

    let retired_a = store
        .create_if_absent(&StreamId::new("retired-name").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&retired_a, event("retired-record", b"cleaned"))
        .await
        .unwrap();
    let reset_request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("source-reset").unwrap(),
        expected: retired_a.clone(),
        action: LifecycleAction::Reset,
    };
    let retired_b = store
        .change_lifecycle(reset_request)
        .await
        .unwrap()
        .replacement
        .unwrap();
    store
        .change_lifecycle(LifecycleRequest {
            operation_id: LifecycleOperationId::new("source-delete").unwrap(),
            expected: retired_b.clone(),
            action: LifecycleAction::Delete,
        })
        .await
        .unwrap();
    loop {
        let progress = store
            .cleanup_retired(CleanupLimits {
                max_records: 8,
                max_bytes: 2 * 1024 * 1024,
            })
            .await
            .unwrap();
        if !progress.remaining {
            break;
        }
    }

    let live = store
        .create_if_absent(&StreamId::new("live-name").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&live, event("live-1", b"exact restored bytes"))
        .await
        .unwrap();
    store.close().await.unwrap();

    let config = RestoreConfig {
        max_source_bytes: 32 * 1024 * 1024,
        max_staging_bytes: 32 * 1024 * 1024,
        page: PageLimits {
            max_records: 2,
            max_bytes: 2 * 1024 * 1024,
        },
        ..RestoreConfig::default()
    };
    let manager =
        SqliteRestoreManager::new(SqliteRestoreBackend::new(&root).unwrap(), config).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let request = RestoreRequest {
        operation_id: RestoreOperationId::new("restore-roundtrip").unwrap(),
        backup_identity: identity,
        source: source.clone(),
        destination: PathBuf::from("restored.sqlite3"),
    };
    let receipt = manager.restore(request.clone()).await.unwrap();
    assert_eq!(receipt.mapping_count, 3);
    assert_eq!(manager.restore(request.clone()).await.unwrap(), receipt);

    let first_page = manager
        .read_mapping(
            receipt.clone(),
            None,
            PageLimits {
                max_records: 2,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(first_page.entries.len(), 2);
    assert!(!first_page.complete);
    let second_page = manager
        .read_mapping(
            receipt.clone(),
            first_page.next_after.clone(),
            PageLimits {
                max_records: 2,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(second_page.entries.len(), 1);
    assert!(second_page.complete);
    let mappings: Vec<_> = first_page
        .entries
        .into_iter()
        .chain(second_page.entries)
        .collect();
    let mapped_live = mappings
        .iter()
        .find(|entry| entry.old == live)
        .unwrap()
        .new
        .clone();
    let mapped_a = mappings
        .iter()
        .find(|entry| entry.old == retired_a)
        .unwrap()
        .new
        .clone();
    let mapped_b = mappings
        .iter()
        .find(|entry| entry.old == retired_b)
        .unwrap()
        .new
        .clone();
    assert_ne!(mapped_live.incarnation, live.incarnation);

    let restored = SqliteStore::open(SqliteOptions::new(&receipt.destination))
        .await
        .unwrap();
    assert!(matches!(
        restored.bounds(&live).await,
        Err(Error::StaleIncarnation { .. })
    ));
    let page = restored
        .read_range(
            &mapped_live,
            0,
            1,
            PageLimits {
                max_records: 1,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(
        page.records[0].event.payload.as_bytes(),
        b"exact restored bytes"
    );
    assert!(matches!(
        restored
            .create_if_absent(&StreamId::new("retired-name").unwrap())
            .await,
        Err(Error::StreamUnavailable { last }) if *last == mapped_b
    ));
    let restored_reset = restored
        .change_lifecycle(LifecycleRequest {
            operation_id: LifecycleOperationId::new("source-reset").unwrap(),
            expected: mapped_a,
            action: LifecycleAction::Reset,
        })
        .await
        .unwrap();
    assert_eq!(restored_reset.replacement, Some(mapped_b));
    restored.close().await.unwrap();

    let conflicting = RestoreRequest {
        operation_id: RestoreOperationId::new("other-operation").unwrap(),
        ..request
    };
    assert!(matches!(
        manager.restore(conflicting).await,
        Err(RestoreError::DestinationExists(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn completed_unpublished_restore_retries_without_source() {
    let (root, source, request, manager) = simple_restore_fixture(
        "completed-unpublished",
        Some(SqliteRestoreFailureInjection::AfterStagingCompletion),
    )
    .await;

    assert!(matches!(
        manager.restore(request.clone()).await,
        Err(RestoreError::StorageFailure(_))
    ));
    let staging = staging_file(&root);
    assert!(SqliteStore::open(SqliteOptions::new(&staging))
        .await
        .is_err());
    let relocated = root.join("relocated-backup.sqlite3");
    std::fs::rename(&source, &relocated).unwrap();

    let mut relocated_request = request.clone();
    relocated_request.source = relocated;
    let receipt = manager.restore(relocated_request).await.unwrap();
    assert_eq!(receipt.destination, root.join("restored.sqlite3"));
    assert!(!staging.exists());
    assert_eq!(manager.restore(request).await.unwrap(), receipt);
    let restored = SqliteStore::open(SqliteOptions::new(&receipt.destination))
        .await
        .unwrap();
    restored.close().await.unwrap();
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn corrupt_completed_mapping_count_is_rejected_before_publication() {
    let (root, _source, request, manager) = simple_restore_fixture(
        "completed-count-corrupt",
        Some(SqliteRestoreFailureInjection::AfterStagingCompletion),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let staging = staging_file(&root);
    let connection = Connection::open(&staging).unwrap();
    connection
        .execute("UPDATE restore_metadata SET mapping_count=0", [])
        .unwrap();
    drop(connection);

    assert!(matches!(
        manager.restore(request.clone()).await,
        Err(RestoreError::CorruptBackup(_))
    ));
    assert!(!root.join("restored.sqlite3").exists());
    let state: i64 = Connection::open(&staging)
        .unwrap()
        .query_row(
            "SELECT restore_incomplete FROM event_stream_metadata WHERE singleton=1",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(state, 2);
    manager.cleanup_staging(request).await.unwrap();
    assert!(!root.join("restored.sqlite3").exists());
    assert!(!staging.exists());
    assert!(std::fs::read_dir(&root).unwrap().all(|entry| {
        !entry
            .unwrap()
            .file_name()
            .to_string_lossy()
            .ends_with(".owner")
    }));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn linked_restore_retries_each_publication_boundary_without_source() {
    for (label, failure) in [
        (
            "linked-state-two",
            SqliteRestoreFailureInjection::AfterDestinationLink,
        ),
        (
            "linked-state-zero",
            SqliteRestoreFailureInjection::AfterPublishedMarker,
        ),
    ] {
        let (root, source, request, manager) = simple_restore_fixture(label, Some(failure)).await;
        assert!(matches!(
            manager.restore(request.clone()).await,
            Err(RestoreError::PublicationUnknown { .. })
        ));
        let destination = root.join("restored.sqlite3");
        let staging = staging_file(&root);
        assert!(destination.exists());
        assert!(SqliteStore::open(SqliteOptions::new(&destination))
            .await
            .is_err());
        if failure == SqliteRestoreFailureInjection::AfterDestinationLink {
            let unpublished = RestoreReceipt {
                operation_id: request.operation_id.clone(),
                backup_identity: request.backup_identity,
                destination: destination.clone(),
                mapping_count: 1,
            };
            assert!(manager
                .read_mapping(
                    unpublished,
                    None,
                    PageLimits {
                        max_records: 1,
                        max_bytes: 4096,
                    },
                )
                .await
                .is_err());
            let state: i64 = Connection::open(&destination)
                .unwrap()
                .query_row(
                    "SELECT restore_incomplete FROM event_stream_metadata WHERE singleton=1",
                    [],
                    |row| row.get(0),
                )
                .unwrap();
            assert_eq!(state, 2, "mapping reads must not recover publication");
        }
        std::fs::remove_file(source).unwrap();

        if failure == SqliteRestoreFailureInjection::AfterPublishedMarker {
            std::fs::remove_file(&staging).unwrap();
            assert!(owner_directory(&root).exists());
        }

        let receipt = manager.restore(request.clone()).await.unwrap();
        assert_eq!(receipt.destination, destination);
        assert!(!staging.exists());
        assert!(std::fs::read_dir(&root).unwrap().all(|entry| {
            !entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .ends_with(".owner")
        }));
        assert_eq!(manager.restore(request).await.unwrap(), receipt);
        let restored = SqliteStore::open(SqliteOptions::new(&receipt.destination))
            .await
            .unwrap();
        restored.close().await.unwrap();
        std::fs::remove_dir_all(root).unwrap();
    }
}

#[tokio::test]
async fn cleanup_removes_owned_completed_staging_without_source() {
    let (root, source, request, manager) = simple_restore_fixture(
        "cleanup-completed",
        Some(SqliteRestoreFailureInjection::AfterStagingCompletion),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let staging = staging_file(&root);
    std::fs::remove_file(source).unwrap();

    manager.cleanup_staging(request.clone()).await.unwrap();
    assert!(!staging.exists());
    assert!(manager.cleanup_staging(request).await.is_ok());
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn cleanup_reports_exact_unlink_and_directory_sync_failures() {
    let (root, _source, request, creator) = simple_restore_fixture(
        "cleanup-faults-unlink",
        Some(SqliteRestoreFailureInjection::AfterStagingCompletion),
    )
    .await;
    assert!(creator.restore(request.clone()).await.is_err());
    let staging = staging_file(&root);
    let unlink = SqliteRestoreManager::new(
        SqliteRestoreBackend::new(&root)
            .unwrap()
            .with_failure_injection(SqliteRestoreFailureInjection::DuringCleanupUnlink),
        RestoreConfig::default(),
    )
    .unwrap();
    assert!(matches!(
        unlink.cleanup_staging(request.clone()).await,
        Err(RestoreError::StagingCleanupFailed { paths }) if paths == vec![staging.clone()]
    ));
    assert!(staging.exists());
    SqliteRestoreManager::new(
        SqliteRestoreBackend::new(&root).unwrap(),
        RestoreConfig::default(),
    )
    .unwrap()
    .cleanup_staging(request)
    .await
    .unwrap();
    std::fs::remove_dir_all(root).unwrap();

    let (root, _source, request, creator) = simple_restore_fixture(
        "cleanup-faults-sync",
        Some(SqliteRestoreFailureInjection::AfterStagingCompletion),
    )
    .await;
    assert!(creator.restore(request.clone()).await.is_err());
    let sync = SqliteRestoreManager::new(
        SqliteRestoreBackend::new(&root)
            .unwrap()
            .with_failure_injection(SqliteRestoreFailureInjection::DuringCleanupDirectorySync),
        RestoreConfig::default(),
    )
    .unwrap();
    assert!(matches!(
        sync.cleanup_staging(request.clone()).await,
        Err(RestoreError::StagingCleanupFailed { paths }) if paths == vec![root.clone()]
    ));
    assert!(sync.cleanup_staging(request).await.is_ok());
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn operation_reservation_rejects_conflicts_and_preserves_unknown_entries() {
    let (root, _source, request, manager) = simple_restore_fixture(
        "reservation-conflict",
        Some(SqliteRestoreFailureInjection::AfterOwnerReservation),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let owner = owner_directory(&root);
    let unexpected = owner.join("unexpected");
    std::fs::write(&unexpected, b"external").unwrap();
    assert!(matches!(
        manager.restore(request.clone()).await,
        Err(RestoreError::RequestConflict { .. })
    ));
    assert_eq!(std::fs::read(&unexpected).unwrap(), b"external");
    std::fs::remove_file(unexpected).unwrap();

    let second = root.join("different.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&second))
        .await
        .unwrap();
    let key = store
        .create_if_absent(&StreamId::new("different").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&key, event("different", b"different bytes"))
        .await
        .unwrap();
    store.close().await.unwrap();
    let second_identity = manager.inspect_backup(second.clone()).await.unwrap();
    let conflict = RestoreRequest {
        backup_identity: second_identity,
        source: second,
        ..request.clone()
    };
    assert!(matches!(
        manager.restore(conflict).await,
        Err(RestoreError::RequestConflict { .. })
    ));
    manager.cleanup_staging(request).await.unwrap();
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn unbound_empty_staging_is_preserved_and_not_adopted() {
    let (root, _source, request, manager) = simple_restore_fixture(
        "unbound-empty-staging",
        Some(SqliteRestoreFailureInjection::AfterStagingFileReservation),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let staging = staging_file(&root);
    let owner = owner_directory(&root);
    let binding = std::fs::read_dir(&owner)
        .unwrap()
        .next()
        .unwrap()
        .unwrap()
        .path();
    std::fs::remove_dir(binding).unwrap();
    assert_eq!(std::fs::metadata(&staging).unwrap().len(), 0);

    assert!(matches!(
        manager.restore(request.clone()).await,
        Err(RestoreError::RequestConflict { .. })
    ));
    assert_eq!(std::fs::metadata(&staging).unwrap().len(), 0);
    assert!(std::fs::read_dir(&owner).unwrap().next().is_none());

    std::fs::remove_file(staging).unwrap();
    std::fs::remove_dir(owner).unwrap();
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(all(feature = "test-support", unix))]
#[tokio::test]
async fn symlinked_operation_owner_is_rejected_and_preserved() {
    use std::os::unix::fs::symlink;

    let (root, _source, request, manager) = simple_restore_fixture(
        "reservation-symlink",
        Some(SqliteRestoreFailureInjection::AfterOwnerReservation),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let owner = owner_directory(&root);
    std::fs::remove_dir_all(&owner).unwrap();
    let outside = root.join("outside-owner");
    std::fs::create_dir(&outside).unwrap();
    symlink(&outside, &owner).unwrap();
    std::fs::remove_dir(&outside).unwrap();
    assert!(matches!(
        manager.restore(request).await,
        Err(RestoreError::StagingCleanupFailed { .. })
    ));
    assert!(std::fs::symlink_metadata(owner)
        .unwrap()
        .file_type()
        .is_symlink());
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(all(feature = "test-support", unix))]
#[tokio::test]
async fn dangling_symlinked_request_binding_is_rejected_and_preserved() {
    use std::os::unix::fs::symlink;

    let (root, _source, request, manager) = simple_restore_fixture(
        "reservation-binding-symlink",
        Some(SqliteRestoreFailureInjection::AfterOwnerReservation),
    )
    .await;
    assert!(manager.restore(request.clone()).await.is_err());
    let owner = owner_directory(&root);
    let binding = std::fs::read_dir(&owner)
        .unwrap()
        .next()
        .unwrap()
        .unwrap()
        .path();
    std::fs::remove_dir(&binding).unwrap();
    symlink(root.join("missing-request-binding"), &binding).unwrap();

    assert!(matches!(
        manager.restore(request.clone()).await,
        Err(RestoreError::StagingCleanupFailed { .. })
    ));
    assert!(std::fs::symlink_metadata(&binding)
        .unwrap()
        .file_type()
        .is_symlink());
    assert!(matches!(
        manager.cleanup_staging(request).await,
        Err(RestoreError::StagingCleanupFailed { .. })
    ));
    assert!(std::fs::symlink_metadata(binding)
        .unwrap()
        .file_type()
        .is_symlink());
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(all(feature = "test-support", unix))]
#[tokio::test]
async fn staging_symlink_and_hardlink_are_rejected_before_sqlite_open() {
    use std::os::unix::fs::{symlink, MetadataExt};

    for hard_link in [false, true] {
        let label = if hard_link {
            "staging-hardlink"
        } else {
            "staging-symlink"
        };
        let (root, source, request, manager) = simple_restore_fixture(
            label,
            Some(SqliteRestoreFailureInjection::AfterStagingFileReservation),
        )
        .await;
        assert!(manager.restore(request.clone()).await.is_err());
        let staging = staging_file(&root);
        std::fs::remove_file(&staging).unwrap();
        let external = root.join(format!("external-empty-{label}"));
        std::fs::File::create(&external).unwrap();
        if hard_link {
            std::fs::hard_link(&external, &staging).unwrap();
        } else {
            symlink(&external, &staging).unwrap();
        }

        assert!(matches!(
            manager.restore(request.clone()).await,
            Err(RestoreError::StagingCleanupFailed { paths }) if paths == vec![staging.clone()]
        ));
        let metadata = std::fs::symlink_metadata(&staging).unwrap();
        if hard_link {
            assert_eq!(metadata.nlink(), 2);
        } else {
            assert!(metadata.file_type().is_symlink());
        }
        assert_eq!(std::fs::metadata(&external).unwrap().len(), 0);
        let count: i64 =
            Connection::open_with_flags(&source, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)
                .unwrap()
                .query_row("SELECT COUNT(*) FROM event_records", [], |row| row.get(0))
                .unwrap();
        assert_eq!(count, 1);
        assert!(matches!(
            manager.cleanup_staging(request).await,
            Err(RestoreError::StagingCleanupFailed { paths }) if paths == vec![staging.clone()]
        ));
        assert!(std::fs::symlink_metadata(&staging).is_ok());
        std::fs::remove_dir_all(root).unwrap();
    }
}

#[tokio::test]
async fn operation_id_cannot_escape_or_lengthen_staging_name() {
    let (root, _source, mut request, manager) = simple_restore_fixture("hashed-name", None).await;
    request.operation_id =
        RestoreOperationId::new("../nested/../../operation-with-path-separators").unwrap();
    let receipt = manager.restore(request).await.unwrap();
    assert_eq!(receipt.destination, root.join("restored.sqlite3"));
    assert!(!root.join("nested").exists());
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn legacy_format_two_is_inspected_read_only_restored_and_extended_on_normal_open() {
    let root = temp_root("legacy-v2");
    let source = root.join("legacy.sqlite3");
    let store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    let live = store
        .create_if_absent(&StreamId::new("legacy-live").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&live, event("legacy-event", b"legacy payload"))
        .await
        .unwrap();
    let deleted = store
        .create_if_absent(&StreamId::new("legacy-deleted").unwrap())
        .await
        .unwrap();
    let lifecycle = LifecycleRequest {
        operation_id: LifecycleOperationId::new("legacy-delete").unwrap(),
        expected: deleted,
        action: LifecycleAction::Delete,
    };
    let lifecycle_receipt = store.change_lifecycle(lifecycle.clone()).await.unwrap();
    store.close().await.unwrap();
    downgrade_to_legacy_format_two(&source);

    let manager = SqliteRestoreManager::new(
        SqliteRestoreBackend::new(&root).unwrap(),
        RestoreConfig::default(),
    )
    .unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let connection = Connection::open(&source).unwrap();
    let restore_tables: u32 = connection
        .query_row(
            "SELECT count(*) FROM sqlite_schema WHERE type='table' AND name LIKE 'restore_%'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(
        restore_tables, 0,
        "read-only inspection must not extend schema"
    );
    drop(connection);

    let restored = manager
        .restore(RestoreRequest {
            operation_id: RestoreOperationId::new("restore-legacy-v2").unwrap(),
            backup_identity: identity,
            source: source.clone(),
            destination: PathBuf::from("restored-legacy.sqlite3"),
        })
        .await
        .unwrap();
    assert_eq!(restored.mapping_count, 2);

    let mut failed_extension = SqliteOptions::new(&source);
    failed_extension.failure_injection = Some(SqliteFailureInjection::BeforeMigrationCommit);
    assert!(matches!(
        SqliteStore::open(failed_extension).await,
        Err(Error::StoreWriteFailed(_))
    ));
    let connection = Connection::open(&source).unwrap();
    let partial_extension: (u32, u32) = connection
        .query_row(
            "SELECT
               (SELECT count(*) FROM sqlite_schema WHERE type='table' AND name LIKE 'restore_%'),
               (SELECT count(*) FROM pragma_table_info('event_stream_metadata') WHERE name='restore_incomplete')",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .unwrap();
    assert_eq!(partial_extension, (0, 0));
    drop(connection);

    let source_store = SqliteStore::open(SqliteOptions::new(&source))
        .await
        .unwrap();
    assert_eq!(source_store.bounds(&live).await.unwrap().tail.offset, 1);
    assert_eq!(
        source_store.change_lifecycle(lifecycle).await.unwrap(),
        lifecycle_receipt
    );
    source_store.close().await.unwrap();
    let connection = Connection::open(&source).unwrap();
    let extended: (u32, u32) = connection
        .query_row(
            "SELECT
               (SELECT count(*) FROM sqlite_schema WHERE type='table' AND name LIKE 'restore_%'),
               (SELECT count(*) FROM pragma_table_info('event_stream_metadata') WHERE name='restore_incomplete')",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .unwrap();
    assert_eq!(extended, (2, 1));
    drop(connection);
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn restore_rejects_records_outside_declared_lifetime_extent() {
    let (root, source, request, manager) = simple_restore_fixture("record-extent", None).await;
    let connection = Connection::open(&source).unwrap();
    let stream_key: i64 = connection
        .query_row(
            "SELECT stream_key FROM event_streams WHERE public_id='live'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    connection
        .execute(
            "INSERT INTO event_records(stream_key,offset,event_id,schema_id,schema_version,payload)
             VALUES(?1,?2,'outside','restore.test',7,X'01')",
            rusqlite::params![stream_key, 0_u64.to_be_bytes().as_slice()],
        )
        .unwrap();
    drop(connection);
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let corrupt_request = RestoreRequest {
        backup_identity: identity,
        ..request
    };
    assert!(matches!(
        manager.restore(corrupt_request).await,
        Err(RestoreError::CorruptBackup(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn mapping_reader_guards_malformed_large_columns_before_materialization() {
    let (root, _source, request, manager) = simple_restore_fixture("mapping-guard", None).await;
    let receipt = manager.restore(request).await.unwrap();
    let connection = Connection::open(&receipt.destination).unwrap();
    connection
        .execute_batch("PRAGMA ignore_check_constraints=ON;")
        .unwrap();
    connection
        .execute(
            "UPDATE restore_mappings SET new_incarnation=zeroblob(2097152)",
            [],
        )
        .unwrap();
    drop(connection);
    assert!(matches!(
        manager
            .read_mapping(
                receipt,
                None,
                PageLimits {
                    max_records: 1,
                    max_bytes: 4096,
                },
            )
            .await,
        Err(RestoreError::CorruptBackup(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn published_receipt_rejects_malformed_types_counts_and_accounting() {
    for (label, mutation) in [
        (
            "receipt-count-type",
            "UPDATE restore_metadata SET mapping_count='not-an-integer'",
        ),
        (
            "receipt-count-mismatch",
            "UPDATE restore_metadata SET mapping_count=0",
        ),
        (
            "receipt-state-type",
            "UPDATE event_stream_metadata SET restore_incomplete='not-an-integer'",
        ),
        (
            "receipt-counter-mismatch",
            "UPDATE event_stream_metadata SET lifecycle_receipt_count=1",
        ),
    ] {
        let (root, _source, request, manager) = simple_restore_fixture(label, None).await;
        let receipt = manager.restore(request.clone()).await.unwrap();
        let connection = Connection::open(&receipt.destination).unwrap();
        connection
            .execute_batch("PRAGMA ignore_check_constraints=ON;")
            .unwrap();
        connection.execute(mutation, []).unwrap();
        drop(connection);

        assert!(matches!(
            manager.restore(request).await,
            Err(RestoreError::CorruptBackup(_))
        ));
        std::fs::remove_dir_all(root).unwrap();
    }
}

#[tokio::test]
async fn backup_inspection_rejects_oversized_replacement_before_import() {
    let (root, source, _request, manager) =
        simple_restore_fixture("receipt-replacement", None).await;
    let connection = Connection::open(&source).unwrap();
    connection
        .execute_batch("PRAGMA ignore_check_constraints=ON;")
        .unwrap();
    let incarnation: Vec<u8> = connection
        .query_row(
            "SELECT incarnation FROM event_streams WHERE public_id='live'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    connection
        .execute(
            "INSERT INTO lifecycle_receipts(
               operation_id,action,expected_public_id,expected_incarnation,
               replacement_incarnation,charge
             ) VALUES('oversized-replacement',1,'live',?1,zeroblob(2097152),281)",
            rusqlite::params![incarnation],
        )
        .unwrap();
    connection
        .execute(
            "UPDATE event_stream_metadata
             SET lifecycle_receipt_count=1,lifecycle_receipt_bytes=281",
            [],
        )
        .unwrap();
    drop(connection);

    assert!(matches!(
        manager.inspect_backup(source).await,
        Err(RestoreError::CorruptBackup(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn mapping_reader_rejects_an_incarnation_that_was_not_refreshed() {
    let (root, _source, request, manager) = simple_restore_fixture("mapping-freshness", None).await;
    let receipt = manager.restore(request).await.unwrap();
    let connection = Connection::open(&receipt.destination).unwrap();
    connection
        .execute(
            "UPDATE restore_mappings SET new_incarnation=old_incarnation",
            [],
        )
        .unwrap();
    drop(connection);

    assert!(matches!(
        manager
            .read_mapping(
                receipt,
                None,
                PageLimits {
                    max_records: 1,
                    max_bytes: 4096,
                },
            )
            .await,
        Err(RestoreError::CorruptBackup(_))
    ));
    std::fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn restore_process_kill_child() {
    let Ok(root) = std::env::var("EVENT_STREAM_RESTORE_KILL_ROOT") else {
        return;
    };
    let failure = match std::env::var("EVENT_STREAM_RESTORE_KILL_PHASE")
        .unwrap()
        .as_str()
    {
        "owner" => SqliteRestoreFailureInjection::AfterOwnerReservation,
        "reserved" => SqliteRestoreFailureInjection::AfterStagingFileReservation,
        "completed" => SqliteRestoreFailureInjection::AfterStagingCompletion,
        "linked" => SqliteRestoreFailureInjection::AfterDestinationLink,
        "published" => SqliteRestoreFailureInjection::AfterPublishedMarker,
        other => panic!("unknown restore kill phase {other}"),
    };
    let root = PathBuf::from(root);
    let pause_marker = PathBuf::from(std::env::var("EVENT_STREAM_RESTORE_PAUSE_MARKER").unwrap());
    let source = root.join("backup.sqlite3");
    let backend = SqliteRestoreBackend::new(&root)
        .unwrap()
        .with_pause_injection(failure, pause_marker);
    let manager = SqliteRestoreManager::new(backend, RestoreConfig::default()).unwrap();
    let identity = manager.inspect_backup(source.clone()).await.unwrap();
    let request = RestoreRequest {
        operation_id: RestoreOperationId::new("restore-process-kill").unwrap(),
        backup_identity: identity,
        source,
        destination: PathBuf::from("restored.sqlite3"),
    };
    let _ = manager.restore(request).await;
    panic!("pause injection unexpectedly returned");
}

#[cfg(feature = "test-support")]
#[tokio::test]
async fn abrupt_process_kill_recovers_bootstrap_and_publication_boundaries() {
    for phase in ["owner", "reserved", "completed", "linked", "published"] {
        let (root, source, request, manager) = simple_restore_fixture("process-kill", None).await;
        drop(manager);
        let pause_marker = root.join(format!("pause-{phase}"));
        let child = Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "restore_process_kill_child",
                "--nocapture",
                "--test-threads=1",
            ])
            .env("EVENT_STREAM_RESTORE_KILL_ROOT", &root)
            .env("EVENT_STREAM_RESTORE_KILL_PHASE", phase)
            .env("EVENT_STREAM_RESTORE_PAUSE_MARKER", &pause_marker)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::inherit())
            .spawn()
            .unwrap();
        let child = ChildGuard(Some(child));
        let deadline = Instant::now() + Duration::from_secs(10);
        while !pause_marker.exists() && Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(5));
        }
        assert!(pause_marker.exists(), "child reached {phase} boundary");
        assert!(!child.kill_and_wait().success());
        std::fs::remove_file(pause_marker).unwrap();
        if phase != "owner" && phase != "reserved" {
            std::fs::remove_file(&source).unwrap();
        } else if phase == "reserved" {
            let staging = staging_file(&root);
            assert!(SqliteStore::open(SqliteOptions::new(staging))
                .await
                .is_err());
        }

        let manager = SqliteRestoreManager::new(
            SqliteRestoreBackend::new(&root).unwrap(),
            RestoreConfig::default(),
        )
        .unwrap();
        let receipt = manager.restore(request.clone()).await.unwrap();
        assert_eq!(manager.restore(request).await.unwrap(), receipt);
        let mapping = manager
            .read_mapping(
                receipt.clone(),
                None,
                PageLimits {
                    max_records: 1,
                    max_bytes: 4096,
                },
            )
            .await
            .unwrap()
            .entries
            .pop()
            .unwrap();
        assert_ne!(mapping.old.incarnation, mapping.new.incarnation);
        for _ in 0..2 {
            let restored = SqliteStore::open(SqliteOptions::new(&receipt.destination))
                .await
                .unwrap();
            let page = restored
                .read_range(
                    &mapping.new,
                    0,
                    1,
                    PageLimits {
                        max_records: 1,
                        max_bytes: 4096,
                    },
                )
                .await
                .unwrap();
            assert_eq!(page.records.len(), 1);
            assert_eq!(page.records[0].cursor.offset, 1);
            assert_eq!(page.records[0].event.id.as_str(), "one");
            assert_eq!(page.records[0].event.schema.id.as_str(), "restore.test");
            assert_eq!(page.records[0].event.schema.version, 7);
            assert_eq!(
                page.records[0].event.payload.as_bytes(),
                b"restore publication state"
            );
            restored.close().await.unwrap();
        }
        std::fs::remove_dir_all(root).unwrap();
    }
}
