mod common;
use event_stream::infrastructure::{MemoryStore, MemoryStoreOptions};
use event_stream::*;

#[tokio::test]
async fn memory_store_passes_shared_contract() {
    common::event_store_contract!(MemoryStore::open(MemoryStoreOptions::default()));
}

#[tokio::test]
async fn memory_store_passes_lifecycle_contract() {
    common::lifecycle_store_contract!(MemoryStore::open(MemoryStoreOptions::default()));
}

#[tokio::test]
async fn quota_rejects_new_history_but_allows_retry() {
    let store = MemoryStore::open(MemoryStoreOptions {
        max_record_bytes: 1024,
        max_history_records: 1,
        max_history_bytes: 2048,
        ..MemoryStoreOptions::default()
    })
    .await
    .unwrap();
    let key = store
        .create_if_absent(&StreamId::new("quota").unwrap())
        .await
        .unwrap();
    let original = common::event("one", b"one");
    store.append_atomic(&key, original.clone()).await.unwrap();
    assert!(matches!(
        store
            .append_atomic(&key, common::event("two", b"two"))
            .await,
        Err(Error::CapacityExceeded)
    ));
    assert_eq!(
        store.append_atomic(&key, original).await.unwrap().kind,
        AppendKind::Deduplicated
    );
}

#[tokio::test]
async fn stream_metadata_has_finite_count_and_byte_quotas() {
    let store = MemoryStore::open(MemoryStoreOptions {
        max_streams: 1,
        max_stream_metadata_bytes: 300,
        ..MemoryStoreOptions::default()
    })
    .await
    .unwrap();
    let first_id = StreamId::new("one").unwrap();
    let first = store.create_if_absent(&first_id).await.unwrap();
    assert_eq!(store.create_if_absent(&first_id).await.unwrap(), first);
    assert!(matches!(
        store.create_if_absent(&StreamId::new("two").unwrap()).await,
        Err(Error::CapacityExceeded)
    ));

    let byte_limited = MemoryStore::open(MemoryStoreOptions {
        max_streams: 10,
        max_stream_metadata_bytes: 260,
        ..MemoryStoreOptions::default()
    })
    .await
    .unwrap();
    byte_limited
        .create_if_absent(&StreamId::new("a").unwrap())
        .await
        .unwrap();
    assert!(matches!(
        byte_limited
            .create_if_absent(&StreamId::new("bbbb").unwrap())
            .await,
        Err(Error::CapacityExceeded)
    ));
}

#[tokio::test]
async fn lifecycle_receipt_and_retired_metadata_quotas_are_finite_and_retry_safe() {
    let receipt_limited = MemoryStore::open(MemoryStoreOptions {
        max_lifecycle_receipts: 1,
        max_lifecycle_receipt_bytes: 1024,
        ..MemoryStoreOptions::default()
    })
    .await
    .unwrap();
    let first = receipt_limited
        .create_if_absent(&StreamId::new("receipt-quota").unwrap())
        .await
        .unwrap();
    let request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("receipt-one").unwrap(),
        expected: first,
        action: LifecycleAction::Reset,
    };
    let receipt = receipt_limited
        .change_lifecycle(request.clone())
        .await
        .unwrap();
    assert_eq!(
        receipt_limited.change_lifecycle(request).await.unwrap(),
        receipt
    );
    assert!(matches!(
        receipt_limited
            .change_lifecycle(LifecycleRequest {
                operation_id: LifecycleOperationId::new("receipt-two").unwrap(),
                expected: receipt.replacement.unwrap(),
                action: LifecycleAction::Delete,
            })
            .await,
        Err(Error::CapacityExceeded)
    ));

    let retired_limited = MemoryStore::open(MemoryStoreOptions {
        max_retired_lifetimes: 1,
        max_retired_metadata_bytes: 1024,
        ..MemoryStoreOptions::default()
    })
    .await
    .unwrap();
    let a = retired_limited
        .create_if_absent(&StreamId::new("retired-quota").unwrap())
        .await
        .unwrap();
    let b = retired_limited
        .change_lifecycle(LifecycleRequest {
            operation_id: LifecycleOperationId::new("retire-a").unwrap(),
            expected: a,
            action: LifecycleAction::Reset,
        })
        .await
        .unwrap()
        .replacement
        .unwrap();
    let retire_b = LifecycleRequest {
        operation_id: LifecycleOperationId::new("retire-b").unwrap(),
        expected: b,
        action: LifecycleAction::Reset,
    };
    assert!(matches!(
        retired_limited.change_lifecycle(retire_b.clone()).await,
        Err(Error::CapacityExceeded)
    ));
    let cleanup = retired_limited
        .cleanup_retired(CleanupLimits {
            max_records: 1,
            max_bytes: 2 * 1024 * 1024,
        })
        .await
        .unwrap();
    assert_eq!(cleanup.removed_records, 0);
    assert!(!cleanup.remaining);
    assert!(retired_limited
        .change_lifecycle(retire_b)
        .await
        .unwrap()
        .replacement
        .is_some());
}

#[tokio::test]
async fn generated_lifecycle_sequence_matches_the_name_state_model() {
    let store = MemoryStore::open(MemoryStoreOptions::default())
        .await
        .unwrap();
    let id = StreamId::new("lifecycle-model").unwrap();
    let original = store.create_if_absent(&id).await.unwrap();
    let mut model = StreamAvailability::Active(original.clone());
    let mut committed: Vec<(LifecycleRequest, LifecycleReceipt)> = Vec::new();
    let mut seed = 0x4d59_5df4_d0f3_3173u64;
    for step in 0..128 {
        seed = seed.wrapping_mul(6_364_136_223_846_793_005).wrapping_add(1);
        if step % 5 == 4 && !committed.is_empty() {
            let index = (seed as usize) % committed.len();
            let (request, expected) = &committed[index];
            assert_eq!(
                store.change_lifecycle(request.clone()).await.unwrap(),
                *expected
            );
            continue;
        }
        let current = match &model {
            StreamAvailability::Active(key) | StreamAvailability::Unavailable(key) => key,
        };
        let expected = if step % 7 == 6 {
            original.clone()
        } else {
            current.clone()
        };
        let action = if seed & 1 == 0 {
            LifecycleAction::Reset
        } else {
            LifecycleAction::Delete
        };
        let request = LifecycleRequest {
            operation_id: LifecycleOperationId::new(format!("model-{step}")).unwrap(),
            expected,
            action,
        };
        if request.expected != *current {
            assert!(matches!(
                store.change_lifecycle(request).await,
                Err(Error::StaleIncarnation { .. })
            ));
            continue;
        }
        let receipt = store.change_lifecycle(request.clone()).await.unwrap();
        model = match &receipt.replacement {
            Some(replacement) => StreamAvailability::Active(replacement.clone()),
            None => StreamAvailability::Unavailable(request.expected.clone()),
        };
        committed.push((request, receipt));
        match &model {
            StreamAvailability::Active(key) => {
                assert_eq!(store.create_if_absent(&id).await.unwrap(), *key)
            }
            StreamAvailability::Unavailable(last) => assert!(matches!(
                store.create_if_absent(&id).await,
                Err(Error::StreamUnavailable { last: actual }) if *actual == *last
            )),
        }
    }
}
