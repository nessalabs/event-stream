#![cfg(feature = "sqlite")]

mod common;

use event_stream::{
    infrastructure::{SqliteFailureInjection, SqliteOptions, SqliteStore, SQLITE_FORMAT_VERSION},
    AppendKind, CleanupLimits, Error, EventId, EventStore, LifecycleAction, LifecycleOperationId,
    LifecycleRequest, LifecycleStore, NewEvent, PageLimits, Payload, SchemaId, SchemaRef, StreamId,
};
use rusqlite::{params, Connection};
use std::{
    io::{BufRead, BufReader, Write},
    path::PathBuf,
    process::{Command, Stdio},
    time::Duration,
};

fn temp_db(label: &str) -> (PathBuf, PathBuf) {
    let dir = std::env::temp_dir().join(format!("event-stream-{label}-{}", uuid::Uuid::new_v4()));
    std::fs::create_dir(&dir).unwrap();
    (dir.join("events.sqlite3"), dir)
}

fn event(id: &str, payload: &[u8]) -> NewEvent {
    NewEvent {
        id: EventId::new(id).unwrap(),
        schema: SchemaRef {
            id: SchemaId::new("test.bytes").unwrap(),
            version: 7,
        },
        payload: Payload::copy_from_slice(payload),
    }
}

#[tokio::test]
async fn shared_event_store_contract() {
    let (path, dir) = temp_db("contract");
    common::event_store_contract!(SqliteStore::open(SqliteOptions::new(&path)));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn shared_lifecycle_store_contract() {
    let (path, dir) = temp_db("lifecycle-contract");
    common::lifecycle_store_contract!(SqliteStore::open(SqliteOptions::new(&path)));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn lifecycle_receipts_and_unavailable_name_survive_restart_and_cleanup() {
    let (path, dir) = temp_db("lifecycle-restart");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let first = store
        .create_if_absent(&StreamId::new("retained-name").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&first, event("retired", b"history"))
        .await
        .unwrap();
    let request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("delete-restart").unwrap(),
        expected: first.clone(),
        action: LifecycleAction::Delete,
    };
    let receipt = store.change_lifecycle(request.clone()).await.unwrap();
    store.close().await.unwrap();

    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert_eq!(reopened.change_lifecycle(request).await.unwrap(), receipt);
    let progress = reopened
        .cleanup_retired(CleanupLimits {
            max_records: 1,
            max_bytes: 2 * 1024 * 1024,
        })
        .await
        .unwrap();
    assert_eq!(progress.stream, Some(first.clone()));
    assert_eq!(progress.removed_records, 1);
    assert!(!progress.remaining);
    assert!(matches!(
        reopened
            .create_if_absent(&StreamId::new("retained-name").unwrap())
            .await,
        Err(Error::StreamUnavailable { last }) if *last == first
    ));
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn lifecycle_quotas_are_atomic_and_identical_retries_bypass_capacity() {
    let (path, dir) = temp_db("lifecycle-quotas");
    let mut options = SqliteOptions::new(&path);
    options.max_lifecycle_receipts = 1;
    options.max_lifecycle_receipt_bytes = 4096;
    options.max_retired_lifetimes = 1;
    options.max_retired_metadata_bytes = 4096;
    let store = SqliteStore::open(options).await.unwrap();
    let first = store
        .create_if_absent(&StreamId::new("quota-a").unwrap())
        .await
        .unwrap();
    let request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("quota-op").unwrap(),
        expected: first.clone(),
        action: LifecycleAction::Delete,
    };
    let receipt = store.change_lifecycle(request.clone()).await.unwrap();
    assert_eq!(store.change_lifecycle(request).await.unwrap(), receipt);
    let second = store
        .create_if_absent(&StreamId::new("quota-b").unwrap())
        .await
        .unwrap();
    assert!(matches!(
        store
            .change_lifecycle(LifecycleRequest {
                operation_id: LifecycleOperationId::new("quota-op-2").unwrap(),
                expected: second,
                action: LifecycleAction::Delete,
            })
            .await,
        Err(Error::CapacityExceeded)
    ));
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let accounting: (u32, u32, u32, u32) = conn
        .query_row(
            "SELECT lifecycle_receipt_count,lifecycle_receipt_bytes,retired_lifetime_count,retired_metadata_bytes FROM event_stream_metadata WHERE singleton=1",
            [],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
        )
        .unwrap();
    assert_eq!(accounting.0, 1);
    assert_eq!(accounting.2, 1);
    assert!(accounting.1 > 0 && accounting.3 > 0);
    drop(conn);
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn understated_lifecycle_counters_are_rejected_on_open() {
    let (path, dir) = temp_db("lifecycle-counter-corrupt");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("counter-corrupt").unwrap())
        .await
        .unwrap();
    store
        .change_lifecycle(LifecycleRequest {
            operation_id: LifecycleOperationId::new("counter-op").unwrap(),
            expected: stream,
            action: LifecycleAction::Delete,
        })
        .await
        .unwrap();
    store.close().await.unwrap();
    Connection::open(&path)
        .unwrap()
        .execute(
            "UPDATE event_stream_metadata SET lifecycle_receipt_count=0",
            [],
        )
        .unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreCorrupt(_))
    ));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn internally_inconsistent_lifecycle_receipt_is_rejected_on_open() {
    let (path, dir) = temp_db("lifecycle-receipt-corrupt");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("receipt-corrupt").unwrap())
        .await
        .unwrap();
    let request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("receipt-corrupt-op").unwrap(),
        expected: stream,
        action: LifecycleAction::Delete,
    };
    store.change_lifecycle(request.clone()).await.unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    conn.execute(
        "UPDATE lifecycle_receipts SET charge=charge+1 WHERE operation_id='receipt-corrupt-op'",
        [],
    )
    .unwrap();
    conn.execute(
        "UPDATE event_stream_metadata SET lifecycle_receipt_bytes=lifecycle_receipt_bytes+1",
        [],
    )
    .unwrap();
    drop(conn);
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreCorrupt(_))
    ));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn retired_cleanup_rejects_history_holes_and_rolls_back_prior_deletes() {
    let (path, dir) = temp_db("cleanup-hole");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("cleanup-hole").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("first", b"one"))
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("second", b"two"))
        .await
        .unwrap();
    store
        .change_lifecycle(LifecycleRequest {
            operation_id: LifecycleOperationId::new("cleanup-hole-reset").unwrap(),
            expected: stream.clone(),
            action: LifecycleAction::Reset,
        })
        .await
        .unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let retired_key: i64 = conn
        .query_row(
            "SELECT stream_key FROM event_streams WHERE public_id='cleanup-hole' AND retired=1",
            [],
            |r| r.get(0),
        )
        .unwrap();
    conn.execute(
        "DELETE FROM event_records WHERE stream_key=?1 AND offset=?2",
        params![retired_key, 2_u64.to_be_bytes().as_slice()],
    )
    .unwrap();
    drop(conn);
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened
            .cleanup_retired(CleanupLimits {
                max_records: 2,
                max_bytes: 2 * 1024 * 1024,
            })
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    reopened.close().await.unwrap();
    assert_eq!(
        Connection::open(&path)
            .unwrap()
            .query_row(
                "SELECT count(*) FROM event_records WHERE stream_key=?1",
                params![retired_key],
                |r| r.get::<_, u32>(0),
            )
            .unwrap(),
        1
    );
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_active_name_pointer_cannot_retire_another_lifetime() {
    let (path, dir) = temp_db("lifecycle-pointer-corrupt");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let first = store
        .create_if_absent(&StreamId::new("pointer-a").unwrap())
        .await
        .unwrap();
    let second = store
        .create_if_absent(&StreamId::new("pointer-b").unwrap())
        .await
        .unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let second_key: i64 = conn
        .query_row(
            "SELECT active_stream_key FROM event_stream_names WHERE public_id='pointer-b'",
            [],
            |r| r.get(0),
        )
        .unwrap();
    conn.execute(
        "UPDATE event_stream_names SET active_stream_key=?1 WHERE public_id='pointer-a'",
        params![second_key],
    )
    .unwrap();
    drop(conn);
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened
            .create_if_absent(&StreamId::new("pointer-a").unwrap())
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    assert!(matches!(
        reopened
            .change_lifecycle(LifecycleRequest {
                operation_id: LifecycleOperationId::new("pointer-op").unwrap(),
                expected: first,
                action: LifecycleAction::Delete,
            })
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    assert_eq!(reopened.bounds(&second).await.unwrap().tail.offset, 0);
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn lifecycle_and_cleanup_failure_boundaries_are_atomic_and_retryable() {
    let (path, dir) = temp_db("lifecycle-faults");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let first = store
        .create_if_absent(&StreamId::new("faulted-lifecycle").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&first, event("history", b"preserved"))
        .await
        .unwrap();
    store.close().await.unwrap();

    let request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("faulted-reset").unwrap(),
        expected: first.clone(),
        action: LifecycleAction::Reset,
    };
    let mut before = SqliteOptions::new(&path);
    before.failure_injection = Some(SqliteFailureInjection::BeforeLifecycleCommit);
    let store = SqliteStore::open(before).await.unwrap();
    assert!(matches!(
        store.change_lifecycle(request.clone()).await,
        Err(Error::StoreWriteFailed(_))
    ));
    assert_eq!(store.bounds(&first).await.unwrap().tail.offset, 1);
    store.close().await.unwrap();

    let mut lost = SqliteOptions::new(&path);
    lost.failure_injection = Some(SqliteFailureInjection::AfterLifecycleCommitAcknowledgementLost);
    let store = SqliteStore::open(lost).await.unwrap();
    let receipt = store.change_lifecycle(request.clone()).await.unwrap();
    let replacement = receipt.replacement.clone().unwrap();
    assert_eq!(store.change_lifecycle(request).await.unwrap(), receipt);
    store.close().await.unwrap();

    let mut cleanup_fault = SqliteOptions::new(&path);
    cleanup_fault.failure_injection = Some(SqliteFailureInjection::BeforeCleanupCommit);
    let store = SqliteStore::open(cleanup_fault).await.unwrap();
    assert!(matches!(
        store
            .cleanup_retired(CleanupLimits {
                max_records: 1,
                max_bytes: 2 * 1024 * 1024,
            })
            .await,
        Err(Error::StoreWriteFailed(_))
    ));
    store.close().await.unwrap();

    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let progress = reopened
        .cleanup_retired(CleanupLimits {
            max_records: 1,
            max_bytes: 2 * 1024 * 1024,
        })
        .await
        .unwrap();
    assert_eq!(progress.stream, Some(first));
    assert_eq!(progress.removed_records, 1);
    assert!(!progress.remaining);
    assert_eq!(reopened.bounds(&replacement).await.unwrap().tail.offset, 0);
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn restart_preserves_records_deduplication_and_incarnation() {
    let (path, dir) = temp_db("restart");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert_eq!(store.capabilities().format_version, SQLITE_FORMAT_VERSION);
    let stream = store
        .create_if_absent(&StreamId::new("orders").unwrap())
        .await
        .unwrap();
    let first = store
        .append_atomic(&stream, event("e-1", b"one"))
        .await
        .unwrap();
    assert_eq!(first.kind, AppendKind::Inserted);
    store.close().await.unwrap();

    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let same = reopened
        .create_if_absent(&StreamId::new("orders").unwrap())
        .await
        .unwrap();
    assert_eq!(same, stream);
    let retry = reopened
        .append_atomic(&same, event("e-1", b"one"))
        .await
        .unwrap();
    assert_eq!(retry.kind, AppendKind::Deduplicated);
    assert_eq!(retry.record.cursor.offset, 1);
    assert!(matches!(
        reopened
            .append_atomic(&same, event("e-1", b"different"))
            .await,
        Err(Error::IdempotencyConflict { .. })
    ));
    let page = reopened
        .read_range(
            &same,
            0,
            1,
            PageLimits {
                max_records: 8,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(page.records[0].event.payload.as_bytes(), b"one");
    assert!(page.complete);
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn in_process_ownership_lasts_until_worker_stops() {
    let (path, dir) = temp_db("owner-local");
    let first = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreInUse)
    ));
    first.close().await.unwrap();
    let replacement = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    replacement.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn dropping_store_releases_ownership_after_accepted_work_stops() {
    let (path, dir) = temp_db("drop-owner");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("drop").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("one", b"saved"))
        .await
        .unwrap();
    drop(store);
    let reopened = tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            match SqliteStore::open(SqliteOptions::new(&path)).await {
                Ok(store) => break store,
                Err(Error::StoreInUse) => tokio::task::yield_now().await,
                Err(error) => panic!("unexpected reopen error: {error}"),
            }
        }
    })
    .await
    .unwrap();
    assert_eq!(
        reopened
            .lookup_event(&stream, &EventId::new("one").unwrap())
            .await
            .unwrap()
            .unwrap()
            .event
            .payload
            .as_bytes(),
        b"saved"
    );
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn dropped_close_future_still_closes_after_a_full_queue_drains() {
    let (path, dir) = temp_db("cancel-close");
    let mut options = SqliteOptions::new(&path);
    options.worker_queue_capacity = 1;
    options.failure_injection = Some(SqliteFailureInjection::PauseBeforeCommit(
        Duration::from_millis(100),
    ));
    let store = std::sync::Arc::new(SqliteStore::open(options).await.unwrap());
    let stream = store
        .create_if_absent(&StreamId::new("closing").unwrap())
        .await
        .unwrap();
    let first = {
        let store = store.clone();
        let stream = stream.clone();
        tokio::spawn(async move { store.append_atomic(&stream, event("first", b"one")).await })
    };
    tokio::time::sleep(Duration::from_millis(10)).await;
    let second = {
        let store = store.clone();
        let stream = stream.clone();
        tokio::spawn(async move { store.append_atomic(&stream, event("second", b"two")).await })
    };
    tokio::task::yield_now().await;
    let closing = {
        let store = store.clone();
        tokio::spawn(async move { store.close().await })
    };
    loop {
        match store.bounds(&stream).await {
            Err(Error::Closed) => break,
            Err(Error::Overloaded) => tokio::task::yield_now().await,
            result => panic!("unexpected state while starting close: {result:?}"),
        }
    }
    closing.abort();
    first.await.unwrap().unwrap();
    second.await.unwrap().unwrap();
    drop(store);
    let reopened = tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            match SqliteStore::open(SqliteOptions::new(&path)).await {
                Ok(store) => break store,
                Err(Error::StoreInUse) => tokio::task::yield_now().await,
                Err(error) => panic!("unexpected reopen error: {error}"),
            }
        }
    })
    .await
    .unwrap();
    assert_eq!(reopened.bounds(&stream).await.unwrap().tail.offset, 2);
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[test]
fn sqlite_child() {
    let Some(path) = std::env::var_os("EVENT_STREAM_CHILD_DB") else {
        return;
    };
    let mode = std::env::var("EVENT_STREAM_CHILD_MODE").unwrap();
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    runtime.block_on(async {
        let mut options = SqliteOptions::new(PathBuf::from(path));
        if mode == "before_commit" {
            options.failure_injection = Some(SqliteFailureInjection::PauseBeforeCommit(
                Duration::from_secs(60),
            ));
        } else if mode == "lost_receipt" {
            options.failure_injection =
                Some(SqliteFailureInjection::PauseAfterCommitAcknowledgementLost(
                    Duration::from_secs(60),
                ));
        }
        let store = SqliteStore::open(options).await.unwrap();
        if matches!(mode.as_str(), "append" | "before_commit" | "lost_receipt") {
            let stream = store
                .create_if_absent(&StreamId::new("crash").unwrap())
                .await
                .unwrap();
            if mode != "append" {
                println!("STARTING");
                std::io::stdout().flush().unwrap();
            }
            store
                .append_atomic(&stream, event("committed", b"survives-process-kill"))
                .await
                .unwrap();
        }
        println!("READY");
        std::io::stdout().flush().unwrap();
        if mode == "hold" {
            let mut line = String::new();
            std::io::stdin().read_line(&mut line).unwrap();
            store.close().await.unwrap();
        } else {
            loop {
                std::thread::park_timeout(Duration::from_secs(60));
            }
        }
    });
}

#[tokio::test]
async fn separate_process_cannot_take_ownership() {
    let (path, dir) = temp_db("owner-process");
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "sqlite_child", "--nocapture", "--test-threads=1"])
        .env("EVENT_STREAM_CHILD_DB", &path)
        .env("EVENT_STREAM_CHILD_MODE", "hold")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit())
        .spawn()
        .unwrap();
    let mut reader = BufReader::new(child.stdout.take().unwrap());
    let mut line = String::new();
    loop {
        line.clear();
        reader.read_line(&mut line).unwrap();
        if line.contains("READY") {
            break;
        }
    }
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreInUse)
    ));
    writeln!(child.stdin.take().unwrap(), "close").unwrap();
    assert!(child.wait().unwrap().success());
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn committed_data_recovers_after_process_kill() {
    let (path, dir) = temp_db("kill");
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "sqlite_child", "--nocapture", "--test-threads=1"])
        .env("EVENT_STREAM_CHILD_DB", &path)
        .env("EVENT_STREAM_CHILD_MODE", "append")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit())
        .spawn()
        .unwrap();
    let mut reader = BufReader::new(child.stdout.take().unwrap());
    let mut line = String::new();
    loop {
        line.clear();
        reader.read_line(&mut line).unwrap();
        if line.contains("READY") {
            break;
        }
    }
    child.kill().unwrap();
    child.wait().unwrap();
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("crash").unwrap())
        .await
        .unwrap();
    let found = store
        .lookup_event(&stream, &EventId::new("committed").unwrap())
        .await
        .unwrap()
        .unwrap();
    assert_eq!(found.event.payload.as_bytes(), b"survives-process-kill");
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn process_kill_before_commit_rolls_back_record_and_tail() {
    let (path, dir) = temp_db("kill-before-commit");
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "sqlite_child", "--nocapture", "--test-threads=1"])
        .env("EVENT_STREAM_CHILD_DB", &path)
        .env("EVENT_STREAM_CHILD_MODE", "before_commit")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit())
        .spawn()
        .unwrap();
    let mut reader = BufReader::new(child.stdout.take().unwrap());
    let mut line = String::new();
    loop {
        line.clear();
        reader.read_line(&mut line).unwrap();
        if line.contains("STARTING") {
            break;
        }
    }
    let journal = PathBuf::from(format!("{}-journal", path.display()));
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            if std::fs::metadata(&journal).is_ok_and(|metadata| metadata.len() > 0) {
                break;
            }
            tokio::time::sleep(Duration::from_millis(2)).await;
        }
    })
    .await
    .unwrap();
    child.kill().unwrap();
    child.wait().unwrap();
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("crash").unwrap())
        .await
        .unwrap();
    assert_eq!(store.bounds(&stream).await.unwrap().tail.offset, 0);
    assert!(store
        .lookup_event(&stream, &EventId::new("committed").unwrap())
        .await
        .unwrap()
        .is_none());
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn process_kill_after_commit_before_receipt_deduplicates_retry() {
    let (path, dir) = temp_db("kill-lost-receipt");
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "sqlite_child", "--nocapture", "--test-threads=1"])
        .env("EVENT_STREAM_CHILD_DB", &path)
        .env("EVENT_STREAM_CHILD_MODE", "lost_receipt")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit())
        .spawn()
        .unwrap();
    let mut reader = BufReader::new(child.stdout.take().unwrap());
    let mut line = String::new();
    loop {
        line.clear();
        reader.read_line(&mut line).unwrap();
        if line.contains("STARTING") {
            break;
        }
    }
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            let committed = Connection::open(&path).ok().and_then(|conn| {
                conn.query_row(
                    "SELECT count(*) FROM event_records WHERE event_id='committed'",
                    [],
                    |row| row.get::<_, u32>(0),
                )
                .ok()
            }) == Some(1);
            if committed {
                break;
            }
            tokio::time::sleep(Duration::from_millis(2)).await;
        }
    })
    .await
    .unwrap();
    child.kill().unwrap();
    child.wait().unwrap();
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("crash").unwrap())
        .await
        .unwrap();
    let retry = store
        .append_atomic(&stream, event("committed", b"survives-process-kill"))
        .await
        .unwrap();
    assert_eq!(retry.kind, AppendKind::Deduplicated);
    assert_eq!(retry.record.cursor.offset, 1);
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn database_quota_failure_rolls_back_record_and_tail() {
    let (path, dir) = temp_db("quota");
    let mut options = SqliteOptions::new(&path);
    options.max_record_bytes = 256 * 1024;
    options.max_database_pages = 16;
    let store = SqliteStore::open(options).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("quota").unwrap())
        .await
        .unwrap();
    let append = store
        .append_atomic(&stream, event("large", &vec![9; 128 * 1024]))
        .await;
    assert!(matches!(append, Err(Error::CapacityExceeded)), "{append:?}");
    assert_eq!(store.bounds(&stream).await.unwrap().tail.offset, 0);
    assert!(store
        .lookup_event(&stream, &EventId::new("large").unwrap())
        .await
        .unwrap()
        .is_none());
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn injected_transaction_boundaries_preserve_atomic_state_and_resolve_unknown_commit() {
    let (path, dir) = temp_db("fault-boundaries");
    let mut stream = None;
    for (index, fault) in [
        SqliteFailureInjection::BeforeRecordInsert,
        SqliteFailureInjection::AfterRecordInsert,
        SqliteFailureInjection::BeforeCommit,
    ]
    .into_iter()
    .enumerate()
    {
        let mut options = SqliteOptions::new(&path);
        options.failure_injection = Some(fault);
        let store = SqliteStore::open(options).await.unwrap();
        let key = store
            .create_if_absent(&StreamId::new("faults").unwrap())
            .await
            .unwrap();
        stream.get_or_insert_with(|| key.clone());
        let id = format!("before-{index}");
        assert!(matches!(
            store.append_atomic(&key, event(&id, b"rollback")).await,
            Err(Error::StoreWriteFailed(_))
        ));
        assert_eq!(store.bounds(&key).await.unwrap().tail.offset, 0);
        assert!(store
            .lookup_event(&key, &EventId::new(id).unwrap())
            .await
            .unwrap()
            .is_none());
        store.close().await.unwrap();
    }
    let stream = stream.unwrap();

    let mut after = SqliteOptions::new(&path);
    after.failure_injection = Some(SqliteFailureInjection::AfterCommitAcknowledgementLost);
    let store = SqliteStore::open(after).await.unwrap();
    let receipt = store
        .append_atomic(&stream, event("after", b"committed"))
        .await
        .unwrap();
    assert_eq!(receipt.kind, AppendKind::Inserted);
    assert_eq!(receipt.record.cursor.offset, 1);
    assert_eq!(store.bounds(&stream).await.unwrap().tail.offset, 1);
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn unsigned_offset_representation_crosses_signed_boundary_on_a_forged_tail() {
    let (path, dir) = temp_db("u64");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("high").unwrap())
        .await
        .unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let key: i64 = conn
        .query_row(
            "SELECT stream_key FROM event_streams WHERE public_id='high'",
            [],
            |r| r.get(0),
        )
        .unwrap();
    conn.execute(
        "UPDATE event_streams SET tail=?1 WHERE stream_key=?2",
        params![(u64::MAX - 1).to_be_bytes().as_slice(), key],
    )
    .unwrap();
    // Direct metadata mutation reaches the representation boundary without
    // writing 2^64 records. This does not represent healthy no-gap history.
    drop(conn);
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let inserted = store
        .append_atomic(&stream, event("max", b"last"))
        .await
        .unwrap();
    assert_eq!(inserted.record.cursor.offset, u64::MAX);
    assert!(matches!(
        store.append_atomic(&stream, event("overflow", b"no")).await,
        Err(Error::OffsetOverflow)
    ));
    let page = store
        .read_range(
            &stream,
            u64::MAX - 1,
            u64::MAX,
            PageLimits {
                max_records: 1,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(page.records[0].cursor.offset, u64::MAX);
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn newer_format_is_rejected_without_migration() {
    let (path, dir) = temp_db("format");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("format").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("preserved", b"bytes"))
        .await
        .unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let mode: String = conn
        .query_row("PRAGMA journal_mode=WAL", [], |row| row.get(0))
        .unwrap();
    assert_eq!(mode.to_ascii_lowercase(), "wal");
    conn.execute("UPDATE event_stream_metadata SET format_version=99", [])
        .unwrap();
    drop(conn);
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::UnsupportedFormat(99))
    ));
    let conn = Connection::open(&path).unwrap();
    let version: u32 = conn
        .query_row(
            "SELECT format_version FROM event_stream_metadata WHERE singleton=1",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(version, 99);
    let mode: String = conn
        .query_row("PRAGMA journal_mode", [], |row| row.get(0))
        .unwrap();
    assert_eq!(mode.to_ascii_lowercase(), "wal");
    let records: u32 = conn
        .query_row("SELECT count(*) FROM event_records", [], |row| row.get(0))
        .unwrap();
    assert_eq!(records, 1);
    drop(conn);
    std::fs::remove_dir_all(dir).unwrap();
}

fn create_format_one_fixture(path: &PathBuf, valid: bool) -> i64 {
    let conn = Connection::open(path).unwrap();
    conn.execute_batch(
        "PRAGMA foreign_keys=ON;
         CREATE TABLE event_stream_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),format_version INTEGER NOT NULL);
         CREATE TABLE event_streams(stream_key INTEGER PRIMARY KEY,public_id TEXT NOT NULL UNIQUE,incarnation BLOB NOT NULL CHECK(length(incarnation)=16),floor BLOB NOT NULL CHECK(length(floor)=8),tail BLOB NOT NULL CHECK(length(tail)=8));
         CREATE TABLE event_records(stream_key INTEGER NOT NULL,offset BLOB NOT NULL CHECK(length(offset)=8),event_id TEXT NOT NULL,schema_id TEXT NOT NULL,schema_version INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(stream_key,offset),UNIQUE(stream_key,event_id),FOREIGN KEY(stream_key) REFERENCES event_streams(stream_key));
         INSERT INTO event_stream_metadata(singleton,format_version) VALUES(1,1);",
    )
    .unwrap();
    let incarnation: Vec<u8> = if valid { vec![7; 16] } else { vec![7; 15] };
    if !valid {
        conn.execute_batch("PRAGMA ignore_check_constraints=ON;")
            .unwrap();
    }
    conn.execute(
        "INSERT INTO event_streams(stream_key,public_id,incarnation,floor,tail) VALUES(1,'migrated',?1,?2,?3)",
        params![incarnation, 0_u64.to_be_bytes().as_slice(), 1_u64.to_be_bytes().as_slice()],
    )
    .unwrap();
    if !valid {
        conn.execute_batch("PRAGMA ignore_check_constraints=OFF;")
            .unwrap();
    }
    conn.execute(
        "INSERT INTO event_records(stream_key,offset,event_id,schema_id,schema_version,payload) VALUES(1,?1,'legacy-event','legacy.schema',9,?2)",
        params![1_u64.to_be_bytes().as_slice(), b"exact legacy bytes"],
    )
    .unwrap();
    conn.query_row(
        "SELECT rootpage FROM sqlite_schema WHERE type='table' AND name='event_records'",
        [],
        |r| r.get(0),
    )
    .unwrap()
}

#[tokio::test]
async fn format_one_migration_preserves_record_table_and_exact_bytes() {
    let (path, dir) = temp_db("format-one-migration");
    let record_rootpage = create_format_one_fixture(&path, true);
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("migrated").unwrap())
        .await
        .unwrap();
    let page = store
        .read_range(
            &stream,
            0,
            1,
            PageLimits {
                max_records: 1,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(
        page.records[0].event.payload.as_bytes(),
        b"exact legacy bytes"
    );
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    assert_eq!(
        conn.query_row(
            "SELECT rootpage FROM sqlite_schema WHERE type='table' AND name='event_records'",
            [],
            |r| r.get::<_, i64>(0),
        )
        .unwrap(),
        record_rootpage
    );
    assert_eq!(
        conn.query_row(
            "SELECT format_version FROM event_stream_metadata WHERE singleton=1",
            [],
            |r| r.get::<_, u32>(0),
        )
        .unwrap(),
        SQLITE_FORMAT_VERSION
    );
    drop(conn);
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_format_one_input_fails_migration_without_partial_schema_change() {
    let (path, dir) = temp_db("format-one-rollback");
    let record_rootpage = create_format_one_fixture(&path, false);
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreWriteFailed(_))
    ));
    let conn = Connection::open(&path).unwrap();
    assert_eq!(
        conn.query_row(
            "SELECT format_version FROM event_stream_metadata WHERE singleton=1",
            [],
            |r| r.get::<_, u32>(0),
        )
        .unwrap(),
        1
    );
    assert_eq!(
        conn.query_row(
            "SELECT rootpage FROM sqlite_schema WHERE type='table' AND name='event_records'",
            [],
            |r| r.get::<_, i64>(0),
        )
        .unwrap(),
        record_rootpage
    );
    assert_eq!(
        conn.query_row("SELECT count(*) FROM event_records", [], |r| r
            .get::<_, u32>(0))
            .unwrap(),
        1
    );
    drop(conn);
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn injected_migration_failure_preserves_valid_format_one_then_retries() {
    let (path, dir) = temp_db("format-one-injected-rollback");
    let record_rootpage = create_format_one_fixture(&path, true);
    let mut injected = SqliteOptions::new(&path);
    injected.failure_injection = Some(SqliteFailureInjection::BeforeMigrationCommit);
    assert!(matches!(
        SqliteStore::open(injected).await,
        Err(Error::StoreWriteFailed(_))
    ));
    let conn = Connection::open(&path).unwrap();
    assert_eq!(
        conn.query_row(
            "SELECT format_version FROM event_stream_metadata WHERE singleton=1",
            [],
            |r| r.get::<_, u32>(0),
        )
        .unwrap(),
        1
    );
    assert_eq!(
        conn.query_row(
            "SELECT rootpage FROM sqlite_schema WHERE type='table' AND name='event_records'",
            [],
            |r| r.get::<_, i64>(0),
        )
        .unwrap(),
        record_rootpage
    );
    drop(conn);
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("migrated").unwrap())
        .await
        .unwrap();
    assert_eq!(store.bounds(&stream).await.unwrap().tail.offset, 1);
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn malformed_or_foreign_formats_fail_without_partial_initialization() {
    let (path, dir) = temp_db("foreign-format");
    Connection::open(&path)
        .unwrap()
        .execute("CREATE TABLE application_data(value TEXT)", [])
        .unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreCorrupt(_))
    ));
    let tables: u32 = Connection::open(&path)
        .unwrap()
        .query_row(
            "SELECT count(*) FROM sqlite_schema WHERE type='table' AND name LIKE 'event_%'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(tables, 0);
    std::fs::remove_dir_all(dir).unwrap();

    let (path, dir) = temp_db("missing-format-table");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    store.close().await.unwrap();
    Connection::open(&path)
        .unwrap()
        .execute("DROP TABLE event_records", [])
        .unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreCorrupt(_))
    ));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_stream_metadata_lengths_fail_before_blob_allocation() {
    let (path, dir) = temp_db("metadata-bounds");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("bounded").unwrap())
        .await
        .unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    conn.pragma_update(None, "ignore_check_constraints", true)
        .unwrap();
    conn.execute(
        "UPDATE event_streams SET tail=zeroblob(2000000) WHERE public_id='bounded'",
        [],
    )
    .unwrap();
    drop(conn);
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        store.bounds(&stream).await,
        Err(Error::StoreCorrupt(_))
    ));
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_record_identifiers_are_bounded_by_utf8_bytes_before_allocation() {
    let cases = [
        ("unicode-event", "event_id", "😀".repeat(256)),
        (
            "nul-event",
            "event_id",
            format!("x\0{}", "suffix".repeat(128)),
        ),
        ("unicode-schema", "schema_id", "😀".repeat(256)),
    ];
    for (label, column, malformed) in cases {
        let (path, dir) = temp_db(label);
        let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
        let stream = store
            .create_if_absent(&StreamId::new("bounded-record").unwrap())
            .await
            .unwrap();
        store
            .append_atomic(&stream, event("valid", b"payload"))
            .await
            .unwrap();
        store.close().await.unwrap();

        let sql = format!("UPDATE event_records SET {column}=?1");
        Connection::open(&path)
            .unwrap()
            .execute(&sql, params![malformed])
            .unwrap();
        let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
        assert!(matches!(
            reopened
                .read_range(
                    &stream,
                    0,
                    1,
                    PageLimits {
                        max_records: 1,
                        max_bytes: 4096,
                    },
                )
                .await,
            Err(Error::StoreCorrupt(_))
        ));
        reopened.close().await.unwrap();
        std::fs::remove_dir_all(dir).unwrap();
    }
}

#[tokio::test]
async fn corrupt_record_offset_is_rejected_before_blob_allocation() {
    let (path, dir) = temp_db("record-offset-bound");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("bounded-offset").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("valid", b"payload"))
        .await
        .unwrap();
    store.close().await.unwrap();

    let conn = Connection::open(&path).unwrap();
    conn.pragma_update(None, "ignore_check_constraints", true)
        .unwrap();
    conn.execute("UPDATE event_records SET offset=zeroblob(2000000)", [])
        .unwrap();
    drop(conn);
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened
            .lookup_event(&stream, &EventId::new("valid").unwrap())
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_record_payload_is_bounded_before_result_materialization() {
    let (path, dir) = temp_db("record-payload-bound");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("bounded-payload").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("valid", b"payload"))
        .await
        .unwrap();
    store.close().await.unwrap();

    Connection::open(&path)
        .unwrap()
        .execute("UPDATE event_records SET payload=zeroblob(2000000)", [])
        .unwrap();
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened
            .read_range(
                &stream,
                0,
                1,
                PageLimits {
                    max_records: 1,
                    max_bytes: 4096,
                },
            )
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn corrupt_scalar_types_are_rejected_before_result_materialization() {
    let (path, dir) = temp_db("record-schema-version-type");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("bounded-version").unwrap())
        .await
        .unwrap();
    store
        .append_atomic(&stream, event("valid", b"payload"))
        .await
        .unwrap();
    store.close().await.unwrap();
    Connection::open(&path)
        .unwrap()
        .execute(
            "UPDATE event_records SET schema_version=zeroblob(2000000)",
            [],
        )
        .unwrap();
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened
            .lookup_event(&stream, &EventId::new("valid").unwrap())
            .await,
        Err(Error::StoreCorrupt(_))
    ));
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();

    let (path, dir) = temp_db("format-version-type");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    store.close().await.unwrap();
    Connection::open(&path)
        .unwrap()
        .execute(
            "UPDATE event_stream_metadata SET format_version=zeroblob(2000000)",
            [],
        )
        .unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::StoreCorrupt(_))
    ));
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn replay_rejects_internal_holes_and_missing_tail_rows() {
    for (label, removed_offset) in [("internal-hole", 2_u64), ("missing-tail", 3_u64)] {
        let (path, dir) = temp_db(label);
        let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
        let stream = store
            .create_if_absent(&StreamId::new("corrupt-history").unwrap())
            .await
            .unwrap();
        for index in 1..=3 {
            store
                .append_atomic(&stream, event(&format!("e-{index}"), b"value"))
                .await
                .unwrap();
        }
        store.close().await.unwrap();
        Connection::open(&path)
            .unwrap()
            .execute(
                "DELETE FROM event_records WHERE offset=?1",
                params![removed_offset.to_be_bytes().as_slice()],
            )
            .unwrap();
        let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
        let result = reopened
            .read_range(
                &stream,
                0,
                3,
                PageLimits {
                    max_records: 8,
                    max_bytes: 4096,
                },
            )
            .await;
        assert!(matches!(result, Err(Error::StoreCorrupt(_))), "{result:?}");
        reopened.close().await.unwrap();
        std::fs::remove_dir_all(dir).unwrap();
    }
}

#[tokio::test]
async fn metadata_rejects_floor_above_tail() {
    let (path, dir) = temp_db("floor-above-tail");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let stream = store
        .create_if_absent(&StreamId::new("bad-bounds").unwrap())
        .await
        .unwrap();
    store.close().await.unwrap();
    Connection::open(&path)
        .unwrap()
        .execute(
            "UPDATE event_streams SET floor=?1,tail=?2 WHERE public_id='bad-bounds'",
            params![
                2_u64.to_be_bytes().as_slice(),
                1_u64.to_be_bytes().as_slice()
            ],
        )
        .unwrap();
    let reopened = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    assert!(matches!(
        reopened.bounds(&stream).await,
        Err(Error::StoreCorrupt(_))
    ));
    reopened.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[cfg(unix)]
#[tokio::test]
async fn ownership_rejects_hardlinks_symlinks_and_normalizes_parent_aliases() {
    use std::os::unix::fs::symlink;
    let (path, dir) = temp_db("aliases");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    let dotted = dir.join(".").join("events.sqlite3");
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(dotted)).await,
        Err(Error::StoreInUse)
    ));
    store.close().await.unwrap();

    let hardlink = dir.join("hardlink.sqlite3");
    std::fs::hard_link(&path, &hardlink).unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&hardlink)).await,
        Err(Error::InvalidConfig(_))
    ));
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&path)).await,
        Err(Error::InvalidConfig(_))
    ));
    std::fs::remove_file(&hardlink).unwrap();

    let symlink_path = dir.join("symlink.sqlite3");
    symlink(&path, &symlink_path).unwrap();
    assert!(matches!(
        SqliteStore::open(SqliteOptions::new(&symlink_path)).await,
        Err(Error::InvalidConfig(_))
    ));
    std::fs::remove_file(symlink_path).unwrap();
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    store.close().await.unwrap();
    std::fs::remove_dir_all(dir).unwrap();
}

#[tokio::test]
async fn ordered_replay_and_retry_lookup_use_declared_indexes() {
    let (path, dir) = temp_db("plans");
    let store = SqliteStore::open(SqliteOptions::new(&path)).await.unwrap();
    store.close().await.unwrap();
    let conn = Connection::open(&path).unwrap();
    let replay: String = conn.query_row(
        "EXPLAIN QUERY PLAN SELECT octet_length(event_id),octet_length(schema_id),octet_length(payload),CASE WHEN typeof(offset)='blob' AND length(offset)=8 THEN offset END,CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob' AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256 AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN event_id END,CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob' AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256 AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN schema_id END,CASE WHEN typeof(schema_version)='integer' THEN schema_version END,CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob' AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256 AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN payload END FROM event_records WHERE stream_key=?1 AND offset>?2 AND offset<=?3 ORDER BY offset LIMIT ?4",
        params![1_i64, 0_u64.to_be_bytes().as_slice(), 10_u64.to_be_bytes().as_slice(), 10_i64, 4096_i64],
        |row| row.get(3),
    ).unwrap();
    assert!(
        replay.contains("INDEX") && !replay.contains("SCAN"),
        "{replay}"
    );
    let retry: String = conn.query_row(
        "EXPLAIN QUERY PLAN SELECT offset FROM event_records WHERE stream_key=?1 AND event_id=?2",
        params![1_i64, "event"], |row| row.get(3),
    ).unwrap();
    assert!(
        retry.contains("INDEX") && !retry.contains("SCAN"),
        "{retry}"
    );
    drop(conn);
    std::fs::remove_dir_all(dir).unwrap();
}
