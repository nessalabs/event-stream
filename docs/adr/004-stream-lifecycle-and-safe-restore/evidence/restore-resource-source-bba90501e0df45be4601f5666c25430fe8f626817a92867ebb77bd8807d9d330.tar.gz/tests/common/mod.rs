#![allow(dead_code, unused_imports, unused_macros)]

use event_stream::*;
use std::sync::Arc;

pub fn event(id: &str, payload: &[u8]) -> NewEvent {
    NewEvent {
        id: EventId::new(id).unwrap(),
        schema: SchemaRef {
            id: SchemaId::new("test.bytes").unwrap(),
            version: 1,
        },
        payload: Payload::copy_from_slice(payload),
    }
}

pub async fn run_store_contract<S: EventStore>(store: S) {
    let store = Arc::new(store);
    let missing = StreamKey {
        id: StreamId::new("missing").unwrap(),
        incarnation: IncarnationId([42; 16]),
    };
    assert!(matches!(
        store.bounds(&missing).await,
        Err(Error::StreamNotFound)
    ));

    let id = StreamId::new("contract-stream").unwrap();
    let key = store.create_if_absent(&id).await.unwrap();
    assert_eq!(key, store.create_if_absent(&id).await.unwrap());
    let empty = store.bounds(&key).await.unwrap();
    assert_eq!((empty.floor.offset, empty.tail.offset), (0, 0));

    let first_input = event("event-1", b"exact bytes");
    let first = store
        .append_atomic(&key, first_input.clone())
        .await
        .unwrap();
    assert_eq!(first.kind, AppendKind::Inserted);
    assert_eq!(first.record.cursor.offset, 1);
    let retry = store.append_atomic(&key, first_input).await.unwrap();
    assert_eq!(retry.kind, AppendKind::Deduplicated);
    assert_eq!(retry.record, first.record);
    assert!(matches!(
        store
            .append_atomic(&key, event("event-1", b"different"))
            .await,
        Err(Error::IdempotencyConflict { .. })
    ));
    assert_eq!(store.bounds(&key).await.unwrap().tail.offset, 1);
    assert_eq!(
        store
            .lookup_event(&key, &EventId::new("event-1").unwrap())
            .await
            .unwrap(),
        Some(first.record.clone())
    );

    for offset in 2..=6 {
        let receipt = store
            .append_atomic(&key, event(&format!("event-{offset}"), &[offset as u8]))
            .await
            .unwrap();
        assert_eq!(receipt.record.cursor.offset, offset);
    }
    let limits = PageLimits {
        max_records: 2,
        max_bytes: 4096,
    };
    let page1 = store.read_range(&key, 0, 5, limits).await.unwrap();
    assert_eq!(
        page1
            .records
            .iter()
            .map(|r| r.cursor.offset)
            .collect::<Vec<_>>(),
        vec![1, 2]
    );
    assert_eq!(page1.next_after.offset, 2);
    assert!(!page1.complete);
    let page2 = store.read_range(&key, 2, 5, limits).await.unwrap();
    assert_eq!(
        page2
            .records
            .iter()
            .map(|r| r.cursor.offset)
            .collect::<Vec<_>>(),
        vec![3, 4]
    );
    let page3 = store.read_range(&key, 4, 5, limits).await.unwrap();
    assert_eq!(
        page3
            .records
            .iter()
            .map(|r| r.cursor.offset)
            .collect::<Vec<_>>(),
        vec![5]
    );
    assert!(page3.complete);
    let empty = store.read_range(&key, 5, 5, limits).await.unwrap();
    assert!(empty.records.is_empty() && empty.complete);

    assert!(matches!(
        store.read_range(&key, 7, 7, limits).await,
        Err(Error::CursorAhead { .. })
    ));
    assert!(matches!(
        store.read_range(&key, 4, 3, limits).await,
        Err(Error::InvalidConfig(_))
    ));
    assert!(matches!(
        store
            .read_range(
                &key,
                0,
                1,
                PageLimits {
                    max_records: 0,
                    max_bytes: 1
                }
            )
            .await,
        Err(Error::InvalidConfig(_))
    ));
    assert!(matches!(
        store
            .read_range(
                &key,
                0,
                1,
                PageLimits {
                    max_records: 1,
                    max_bytes: 1
                }
            )
            .await,
        Err(Error::CapacityExceeded)
    ));

    let wrong = StreamKey {
        id: key.id.clone(),
        incarnation: IncarnationId([99; 16]),
    };
    assert!(matches!(
        store.bounds(&wrong).await,
        Err(Error::StaleIncarnation { .. })
    ));
    assert!(matches!(
        store.append_atomic(&wrong, event("wrong", b"x")).await,
        Err(Error::StaleIncarnation { .. })
    ));

    let concurrent_id = StreamId::new("concurrent").unwrap();
    let concurrent = store.create_if_absent(&concurrent_id).await.unwrap();
    let mut tasks = Vec::new();
    for number in 0..32 {
        let store = store.clone();
        let concurrent = concurrent.clone();
        tasks.push(tokio::spawn(async move {
            store
                .append_atomic(&concurrent, event(&format!("c-{number}"), &[number]))
                .await
                .unwrap()
        }));
    }
    let mut offsets = Vec::new();
    for task in tasks {
        offsets.push(task.await.unwrap().record.cursor.offset);
    }
    offsets.sort_unstable();
    assert_eq!(offsets, (1..=32).collect::<Vec<_>>());
    assert_eq!(store.bounds(&concurrent).await.unwrap().tail.offset, 32);

    let create_id = StreamId::new("concurrent-create").unwrap();
    let mut creates = Vec::new();
    for _ in 0..16 {
        let store = store.clone();
        let create_id = create_id.clone();
        creates.push(tokio::spawn(async move {
            store.create_if_absent(&create_id).await.unwrap()
        }));
    }
    let mut created = Vec::new();
    for task in creates {
        created.push(task.await.unwrap());
    }
    assert!(created.iter().all(|key| key == &created[0]));

    let first_attempt_stream = store
        .create_if_absent(&StreamId::new("concurrent-first-attempt").unwrap())
        .await
        .unwrap();
    let first_attempt = event("same-first-id", b"same-first-payload");
    let mut first_attempts = Vec::new();
    for _ in 0..32 {
        let store = store.clone();
        let stream = first_attempt_stream.clone();
        let candidate = first_attempt.clone();
        first_attempts.push(tokio::spawn(async move {
            store.append_atomic(&stream, candidate).await.unwrap()
        }));
    }
    let mut first_attempt_receipts = Vec::new();
    for task in first_attempts {
        first_attempt_receipts.push(task.await.unwrap());
    }
    assert_eq!(
        first_attempt_receipts
            .iter()
            .filter(|receipt| receipt.kind == AppendKind::Inserted)
            .count(),
        1
    );
    assert_eq!(
        first_attempt_receipts
            .iter()
            .filter(|receipt| receipt.kind == AppendKind::Deduplicated)
            .count(),
        31
    );
    assert!(first_attempt_receipts.iter().all(|receipt| {
        receipt.record.cursor.offset == 1 && receipt.record.event == first_attempt
    }));
    assert_eq!(
        store
            .bounds(&first_attempt_stream)
            .await
            .unwrap()
            .tail
            .offset,
        1
    );

    let identity_stream = store
        .create_if_absent(&StreamId::new("concurrent-identity").unwrap())
        .await
        .unwrap();
    let established = event("shared-id", b"same");
    store
        .append_atomic(&identity_stream, established.clone())
        .await
        .unwrap();
    let mut identities = Vec::new();
    for number in 0..32 {
        let store = store.clone();
        let identity_stream = identity_stream.clone();
        let mut candidate = established.clone();
        if number % 2 == 1 {
            candidate.schema.version = 2;
        }
        identities.push(tokio::spawn(async move {
            store.append_atomic(&identity_stream, candidate).await
        }));
    }
    for (number, task) in identities.into_iter().enumerate() {
        let result = task.await.unwrap();
        if number % 2 == 0 {
            assert_eq!(result.unwrap().kind, AppendKind::Deduplicated);
        } else {
            assert!(matches!(result, Err(Error::IdempotencyConflict { .. })));
        }
    }
    assert_eq!(store.bounds(&identity_stream).await.unwrap().tail.offset, 1);

    let isolated_a = store
        .create_if_absent(&StreamId::new("isolated-a").unwrap())
        .await
        .unwrap();
    let isolated_b = store
        .create_if_absent(&StreamId::new("isolated-b").unwrap())
        .await
        .unwrap();
    let shared_id_a = event("same-id-across-streams", b"payload-a");
    let shared_id_b = event("same-id-across-streams", b"payload-b");
    let receipt_a = store
        .append_atomic(&isolated_a, shared_id_a.clone())
        .await
        .unwrap();
    let receipt_b = store
        .append_atomic(&isolated_b, shared_id_b.clone())
        .await
        .unwrap();
    assert_eq!(receipt_a.kind, AppendKind::Inserted);
    assert_eq!(receipt_b.kind, AppendKind::Inserted);
    assert_eq!(receipt_a.record.cursor.offset, 1);
    assert_eq!(receipt_b.record.cursor.offset, 1);
    assert_eq!(
        store
            .lookup_event(&isolated_a, &shared_id_a.id)
            .await
            .unwrap()
            .unwrap()
            .event,
        shared_id_a
    );
    assert_eq!(
        store
            .lookup_event(&isolated_b, &shared_id_b.id)
            .await
            .unwrap()
            .unwrap()
            .event,
        shared_id_b
    );

    // The generic stream stores application envelopes as opaque bytes. A schema
    // version unknown to this library must round-trip unchanged.
    let opaque = store
        .create_if_absent(&StreamId::new("opaque-schema").unwrap())
        .await
        .unwrap();
    let unknown = NewEvent {
        id: EventId::new("opaque-1").unwrap(),
        schema: SchemaRef {
            id: SchemaId::new("future.vendor.envelope").unwrap(),
            version: u32::MAX,
        },
        payload: Payload::copy_from_slice(&[0, 255, 17, 99]),
    };
    store.append_atomic(&opaque, unknown.clone()).await.unwrap();
    let replay = store
        .read_range(
            &opaque,
            0,
            1,
            PageLimits {
                max_records: 1,
                max_bytes: 4096,
            },
        )
        .await
        .unwrap();
    assert_eq!(replay.records[0].event, unknown);

    store.close().await.unwrap();
    assert!(matches!(store.bounds(&key).await, Err(Error::Closed)));
}

pub async fn run_lifecycle_store_contract<S: LifecycleStore>(store: S) {
    let store = Arc::new(store);
    let id = StreamId::new("lifecycle-contract").unwrap();
    let first = store.create_if_absent(&id).await.unwrap();
    for index in 1..=3 {
        store
            .append_atomic(&first, event(&format!("retired-{index}"), &[index]))
            .await
            .unwrap();
    }
    let reset = LifecycleRequest {
        operation_id: LifecycleOperationId::new("reset-1").unwrap(),
        expected: first.clone(),
        action: LifecycleAction::Reset,
    };
    let reset_receipt = store.change_lifecycle(reset.clone()).await.unwrap();
    let second = reset_receipt.replacement.clone().unwrap();
    assert_ne!(first, second);
    assert_eq!(
        store.change_lifecycle(reset.clone()).await.unwrap(),
        reset_receipt
    );
    let conflict = LifecycleRequest {
        action: LifecycleAction::Delete,
        ..reset
    };
    assert!(matches!(
        store.change_lifecycle(conflict).await,
        Err(Error::LifecycleConflict { .. })
    ));
    assert!(matches!(
        store.bounds(&first).await,
        Err(Error::StaleIncarnation {
            current
        }) if *current == StreamAvailability::Active(second.clone())
    ));
    assert!(matches!(
        store.append_atomic(&first, event("stale", b"x")).await,
        Err(Error::StaleIncarnation { .. })
    ));
    assert_eq!(store.bounds(&second).await.unwrap().tail.offset, 0);

    let delete = LifecycleRequest {
        operation_id: LifecycleOperationId::new("delete-2").unwrap(),
        expected: second.clone(),
        action: LifecycleAction::Delete,
    };
    assert!(store
        .change_lifecycle(delete.clone())
        .await
        .unwrap()
        .replacement
        .is_none());
    assert!(matches!(
        store.create_if_absent(&id).await,
        Err(Error::StreamUnavailable { last }) if *last == second
    ));
    assert_eq!(
        store.change_lifecycle(delete).await.unwrap().replacement,
        None
    );

    let revive = LifecycleRequest {
        operation_id: LifecycleOperationId::new("reset-3").unwrap(),
        expected: second.clone(),
        action: LifecycleAction::Reset,
    };
    let third = store
        .change_lifecycle(revive)
        .await
        .unwrap()
        .replacement
        .unwrap();
    assert_ne!(second, third);
    assert_eq!(store.create_if_absent(&id).await.unwrap(), third);

    let limits = CleanupLimits {
        max_records: 2,
        max_bytes: 2 * 1024 * 1024,
    };
    let first_cleanup = store.cleanup_retired(limits).await.unwrap();
    assert_eq!(first_cleanup.stream, Some(first.clone()));
    assert_eq!(first_cleanup.removed_records, 2);
    assert!(first_cleanup.remaining);
    let second_cleanup = store.cleanup_retired(limits).await.unwrap();
    assert_eq!(second_cleanup.stream, Some(first));
    assert_eq!(second_cleanup.removed_records, 1);
    assert!(second_cleanup.remaining);
    let empty_lifetime = store.cleanup_retired(limits).await.unwrap();
    assert_eq!(empty_lifetime.stream, Some(second));
    assert_eq!(empty_lifetime.removed_records, 0);
    assert!(!empty_lifetime.remaining);
    assert_eq!(store.cleanup_retired(limits).await.unwrap().stream, None);

    let concurrent_key = store
        .create_if_absent(&StreamId::new("concurrent-lifecycle").unwrap())
        .await
        .unwrap();
    let concurrent_request = LifecycleRequest {
        operation_id: LifecycleOperationId::new("concurrent-reset").unwrap(),
        expected: concurrent_key,
        action: LifecycleAction::Reset,
    };
    let mut calls = Vec::new();
    for _ in 0..16 {
        let store = store.clone();
        let request = concurrent_request.clone();
        calls.push(tokio::spawn(async move {
            store.change_lifecycle(request).await.unwrap()
        }));
    }
    let mut receipts = Vec::new();
    for call in calls {
        receipts.push(call.await.unwrap());
    }
    assert!(receipts.iter().all(|receipt| receipt == &receipts[0]));
    assert_eq!(
        store
            .create_if_absent(&concurrent_request.expected.id)
            .await
            .unwrap(),
        receipts[0].replacement.clone().unwrap()
    );
}

macro_rules! event_store_contract {
    ($open:expr) => {{
        common::run_store_contract($open.await.expect("store opens")).await
    }};
}

macro_rules! lifecycle_store_contract {
    ($open:expr) => {{
        let store = $open.await.expect("store opens");
        $crate::common::run_lifecycle_store_contract(store).await;
    }};
}
pub(crate) use event_store_contract;
pub(crate) use lifecycle_store_contract;
