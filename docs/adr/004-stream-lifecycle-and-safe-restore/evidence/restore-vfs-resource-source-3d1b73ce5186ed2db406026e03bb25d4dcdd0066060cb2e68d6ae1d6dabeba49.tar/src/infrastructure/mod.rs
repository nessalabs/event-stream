//! Storage and operating-system adapters.
pub mod memory;
pub use memory::*;
#[cfg(feature = "sqlite")]
mod sqlite;
#[cfg(feature = "sqlite")]
pub use sqlite::*;
#[cfg(feature = "sqlite")]
mod sqlite_restore;
#[cfg(feature = "sqlite")]
pub use sqlite_restore::*;
#[cfg(all(feature = "sqlite", feature = "test-support"))]
mod sqlite_test_vfs;
#[cfg(all(feature = "sqlite", feature = "test-support"))]
pub use sqlite_test_vfs::*;

pub fn new_incarnation() -> crate::domain::IncarnationId {
    crate::domain::IncarnationId(*uuid::Uuid::new_v4().as_bytes())
}
