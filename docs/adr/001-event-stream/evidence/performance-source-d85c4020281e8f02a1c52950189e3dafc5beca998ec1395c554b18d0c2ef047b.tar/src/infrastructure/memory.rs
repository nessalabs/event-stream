use crate::{
    application::{Error, EventStore, PersistenceProfile, Result, StoreCapabilities},
    domain::*,
};
use async_trait::async_trait;
use std::{
    collections::{BTreeMap, HashMap},
    sync::{Arc, Mutex},
};

/// Finite storage limits for one ephemeral store instance.
#[derive(Clone, Debug)]
pub struct MemoryStoreOptions {
    pub max_record_bytes: usize,
    pub max_history_records: usize,
    pub max_history_bytes: usize,
    pub max_streams: usize,
    pub max_stream_metadata_bytes: usize,
}

impl Default for MemoryStoreOptions {
    fn default() -> Self {
        Self {
            max_record_bytes: 1024 * 1024,
            max_history_records: 100_000,
            max_history_bytes: 64 * 1024 * 1024,
            max_streams: 10_000,
            max_stream_metadata_bytes: 4 * 1024 * 1024,
        }
    }
}

#[derive(Debug)]
pub struct MemoryStore {
    options: MemoryStoreOptions,
    state: Mutex<State>,
}

#[derive(Debug)]
struct State {
    streams: HashMap<StreamId, StreamHistory>,
    history_records: usize,
    history_bytes: usize,
    stream_metadata_bytes: usize,
    closed: bool,
}

#[derive(Debug)]
struct StreamHistory {
    key: StreamKey,
    records: BTreeMap<u64, Arc<Record>>,
    event_offsets: HashMap<EventId, u64>,
    tail: u64,
}

impl MemoryStore {
    fn lock(&self) -> Result<std::sync::MutexGuard<'_, State>> {
        self.state
            .lock()
            .map_err(|_| Error::StoreCorrupt("memory store lock poisoned".into()))
    }

    fn validate_options(options: &MemoryStoreOptions) -> Result<()> {
        if options.max_record_bytes == 0
            || options.max_history_records == 0
            || options.max_history_bytes == 0
            || options.max_streams == 0
            || options.max_stream_metadata_bytes == 0
        {
            return Err(Error::InvalidConfig(
                "memory store limits must all be nonzero".into(),
            ));
        }
        if options
            .max_record_bytes
            .checked_add(256)
            .is_none_or(|bytes| bytes > options.max_history_bytes)
        {
            return Err(Error::InvalidConfig(
                "one maximum-size record and its index overhead must fit history bytes".into(),
            ));
        }
        Ok(())
    }

    fn history<'a>(state: &'a State, stream: &StreamKey) -> Result<&'a StreamHistory> {
        if state.closed {
            return Err(Error::Closed);
        }
        let history = state.streams.get(&stream.id).ok_or(Error::StreamNotFound)?;
        if history.key != *stream {
            return Err(Error::InvalidCursor(
                "stream incarnation does not match".into(),
            ));
        }
        Ok(history)
    }
}

#[async_trait]
impl EventStore for MemoryStore {
    type Options = MemoryStoreOptions;

    async fn open(options: Self::Options) -> Result<Self> {
        Self::validate_options(&options)?;
        Ok(Self {
            options,
            state: Mutex::new(State {
                streams: HashMap::new(),
                history_records: 0,
                history_bytes: 0,
                stream_metadata_bytes: 0,
                closed: false,
            }),
        })
    }

    fn capabilities(&self) -> StoreCapabilities {
        StoreCapabilities {
            persistence: PersistenceProfile::Ephemeral,
            format_version: 1,
            max_record_bytes: self.options.max_record_bytes,
            max_concurrent_reads: usize::MAX,
            max_concurrent_writes: usize::MAX,
            ownership: "one in-memory store instance",
        }
    }

    async fn create_if_absent(&self, id: &StreamId) -> Result<StreamKey> {
        let mut state = self.lock()?;
        if state.closed {
            return Err(Error::Closed);
        }
        if let Some(history) = state.streams.get(id) {
            return Ok(history.key.clone());
        }
        let metadata_bytes = id
            .as_str()
            .len()
            .checked_add(256)
            .ok_or(Error::CapacityExceeded)?;
        if state.streams.len() >= self.options.max_streams
            || state
                .stream_metadata_bytes
                .checked_add(metadata_bytes)
                .is_none_or(|bytes| bytes > self.options.max_stream_metadata_bytes)
        {
            return Err(Error::CapacityExceeded);
        }
        let key = StreamKey {
            id: id.clone(),
            incarnation: super::new_incarnation(),
        };
        state.streams.insert(
            id.clone(),
            StreamHistory {
                key: key.clone(),
                records: BTreeMap::new(),
                event_offsets: HashMap::new(),
                tail: 0,
            },
        );
        state.stream_metadata_bytes += metadata_bytes;
        Ok(key)
    }

    async fn append_atomic(&self, stream: &StreamKey, event: NewEvent) -> Result<AppendReceipt> {
        let event_bytes = event.accounted_bytes();
        if event_bytes > self.options.max_record_bytes {
            return Err(Error::PayloadTooLarge);
        }
        let mut state = self.lock()?;
        let history = Self::history(&state, stream)?;
        if let Some(offset) = history.event_offsets.get(&event.id) {
            let original = history.records.get(offset).ok_or_else(|| {
                Error::StoreCorrupt("event identity points to a missing record".into())
            })?;
            if original.event.schema != event.schema || original.event.payload != event.payload {
                return Err(Error::IdempotencyConflict {
                    event_id: event.id.clone(),
                });
            }
            return Ok(AppendReceipt {
                record: original.clone(),
                kind: AppendKind::Deduplicated,
            });
        }
        let stored_bytes = event_bytes
            .checked_add(256)
            .ok_or(Error::CapacityExceeded)?;
        if state.history_records >= self.options.max_history_records
            || state
                .history_bytes
                .checked_add(stored_bytes)
                .filter(|total| *total <= self.options.max_history_bytes)
                .is_none()
        {
            return Err(Error::CapacityExceeded);
        }
        let offset = history.tail.checked_add(1).ok_or(Error::OffsetOverflow)?;
        let record = Arc::new(Record {
            cursor: Cursor::new(stream.clone(), offset),
            event,
        });
        let history = state.streams.get_mut(&stream.id).expect("validated above");
        history
            .event_offsets
            .insert(record.event.id.clone(), offset);
        history.records.insert(offset, record.clone());
        history.tail = offset;
        state.history_records += 1;
        state.history_bytes += stored_bytes;
        Ok(AppendReceipt {
            record,
            kind: AppendKind::Inserted,
        })
    }

    async fn lookup_event(&self, stream: &StreamKey, id: &EventId) -> Result<Option<Arc<Record>>> {
        let state = self.lock()?;
        let history = Self::history(&state, stream)?;
        match history.event_offsets.get(id) {
            Some(offset) => history
                .records
                .get(offset)
                .cloned()
                .map(Some)
                .ok_or_else(|| Error::StoreCorrupt("event lookup has no record".into())),
            None => Ok(None),
        }
    }

    async fn bounds(&self, stream: &StreamKey) -> Result<Bounds> {
        let state = self.lock()?;
        let history = Self::history(&state, stream)?;
        Ok(Bounds {
            floor: Cursor::new(stream.clone(), 0),
            tail: Cursor::new(stream.clone(), history.tail),
        })
    }

    async fn read_range(
        &self,
        stream: &StreamKey,
        after: u64,
        through: u64,
        limits: PageLimits,
    ) -> Result<Page> {
        if limits.max_records == 0 || limits.max_bytes == 0 {
            return Err(Error::InvalidConfig("page limits must be nonzero".into()));
        }
        let state = self.lock()?;
        let history = Self::history(&state, stream)?;
        let bounds = Bounds {
            floor: Cursor::new(stream.clone(), 0),
            tail: Cursor::new(stream.clone(), history.tail),
        };
        if after > history.tail {
            return Err(Error::CursorAhead { tail: bounds.tail });
        }
        if through > history.tail {
            return Err(Error::CursorAhead { tail: bounds.tail });
        }
        if after > through {
            return Err(Error::InvalidConfig("after is beyond through".into()));
        }

        if after == through {
            return Ok(Page {
                records: Vec::new(),
                next_after: Cursor::new(stream.clone(), after),
                through: Cursor::new(stream.clone(), through),
                complete: true,
            });
        }
        let available = usize::try_from(through - after).unwrap_or(usize::MAX);
        let mut records = Vec::with_capacity(limits.max_records.min(available));
        let mut bytes = 0usize;
        let first = after.checked_add(1).ok_or(Error::OffsetOverflow)?;
        let mut expected = first;
        let mut range = history.records.range(first..=through);
        loop {
            let Some((&offset, record)) = range.next() else {
                return Err(Error::StoreCorrupt(format!(
                    "missing committed record at offset {expected}"
                )));
            };
            if offset != expected {
                return Err(Error::StoreCorrupt(format!(
                    "missing committed record at offset {expected}"
                )));
            }
            let record_bytes = record.event.accounted_bytes();
            if records.is_empty() && record_bytes > limits.max_bytes {
                return Err(Error::CapacityExceeded);
            }
            if records.len() == limits.max_records
                || bytes
                    .checked_add(record_bytes)
                    .is_none_or(|n| n > limits.max_bytes)
            {
                break;
            }
            bytes += record_bytes;
            records.push(record.clone());
            if offset == through {
                break;
            }
            expected = offset.checked_add(1).ok_or(Error::OffsetOverflow)?;
        }
        let next_offset = records.last().map_or(after, |r| r.cursor.offset);
        Ok(Page {
            records,
            next_after: Cursor::new(stream.clone(), next_offset),
            through: Cursor::new(stream.clone(), through),
            complete: next_offset == through,
        })
    }

    async fn close(&self) -> Result<()> {
        self.lock()?.closed = true;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn append_rejects_offset_overflow_without_mutating_history() {
        let store = MemoryStore::open(MemoryStoreOptions::default())
            .await
            .unwrap();
        let key = store
            .create_if_absent(&StreamId::new("overflow").unwrap())
            .await
            .unwrap();
        {
            let mut state = store.state.lock().unwrap();
            state.streams.get_mut(&key.id).unwrap().tail = u64::MAX;
        }
        let event = NewEvent {
            id: EventId::new("overflow-event").unwrap(),
            schema: SchemaRef {
                id: SchemaId::new("test.bytes").unwrap(),
                version: 1,
            },
            payload: Payload::copy_from_slice(b"unchanged"),
        };

        assert!(matches!(
            store.append_atomic(&key, event.clone()).await,
            Err(Error::OffsetOverflow)
        ));
        assert_eq!(store.lookup_event(&key, &event.id).await.unwrap(), None);
        let state = store.state.lock().unwrap();
        assert_eq!(state.history_records, 0);
        assert_eq!(state.history_bytes, 0);
        assert!(state.streams.get(&key.id).unwrap().records.is_empty());
    }

    #[tokio::test]
    async fn range_read_reports_middle_and_suffix_holes() {
        let store = MemoryStore::open(MemoryStoreOptions::default())
            .await
            .unwrap();
        let key = store
            .create_if_absent(&StreamId::new("corrupt-range").unwrap())
            .await
            .unwrap();
        for index in 1..=3 {
            store
                .append_atomic(
                    &key,
                    NewEvent {
                        id: EventId::new(format!("event-{index}")).unwrap(),
                        schema: SchemaRef {
                            id: SchemaId::new("test.bytes").unwrap(),
                            version: 1,
                        },
                        payload: Payload::copy_from_slice(&[index]),
                    },
                )
                .await
                .unwrap();
        }

        {
            let mut state = store.state.lock().unwrap();
            state.streams.get_mut(&key.id).unwrap().records.remove(&2);
        }
        assert!(matches!(
            store
                .read_range(
                    &key,
                    0,
                    3,
                    PageLimits {
                        max_records: 3,
                        max_bytes: 1024,
                    },
                )
                .await,
            Err(Error::StoreCorrupt(detail)) if detail.contains("offset 2")
        ));

        {
            let mut state = store.state.lock().unwrap();
            let history = state.streams.get_mut(&key.id).unwrap();
            history.records.insert(
                2,
                Arc::new(Record {
                    cursor: Cursor::new(key.clone(), 2),
                    event: NewEvent {
                        id: EventId::new("event-2").unwrap(),
                        schema: SchemaRef {
                            id: SchemaId::new("test.bytes").unwrap(),
                            version: 1,
                        },
                        payload: Payload::copy_from_slice(&[2]),
                    },
                }),
            );
            history.records.remove(&3);
        }
        assert!(matches!(
            store
                .read_range(
                    &key,
                    0,
                    3,
                    PageLimits {
                        max_records: 3,
                        max_bytes: 1024,
                    },
                )
                .await,
            Err(Error::StoreCorrupt(detail)) if detail.contains("offset 3")
        ));
    }
}
