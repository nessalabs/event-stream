//! Storage and operating-system adapters.
pub mod memory;
pub use memory::*;
#[cfg(feature = "sqlite")]
mod sqlite;
#[cfg(feature = "sqlite")]
pub use sqlite::*;

pub fn new_incarnation() -> crate::domain::IncarnationId {
    crate::domain::IncarnationId(*uuid::Uuid::new_v4().as_bytes())
}
