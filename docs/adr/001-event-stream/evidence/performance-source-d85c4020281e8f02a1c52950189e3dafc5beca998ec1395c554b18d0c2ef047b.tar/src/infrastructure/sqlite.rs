use crate::{
    application::{Error, EventStore, PersistenceProfile, Result, StoreCapabilities},
    domain::*,
};
use async_trait::async_trait;
use fs2::FileExt;
use rusqlite::{params, Connection, ErrorCode, OptionalExtension, TransactionBehavior};
use std::{
    collections::HashSet,
    fs::{File, OpenOptions},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicU8, Ordering},
        Arc, Mutex, OnceLock,
    },
    thread,
    time::Duration,
};
use tokio::sync::{mpsc, oneshot, Notify};

pub const SQLITE_FORMAT_VERSION: u32 = 1;
const OPEN: u8 = 0;
const CLOSING: u8 = 1;
const CLOSED: u8 = 2;
const FAULTED: u8 = 3;
const LOOKUP_RECORD_SQL: &str = "SELECT octet_length(event_id),octet_length(schema_id),octet_length(payload),
    CASE WHEN typeof(offset)='blob' AND length(offset)=8 THEN offset END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?3 THEN event_id END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?3 THEN schema_id END,
    CASE WHEN typeof(schema_version)='integer' THEN schema_version END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?3 THEN payload END
    FROM event_records WHERE stream_key=?1 AND event_id=?2";
const READ_RECORD_SQL: &str = "SELECT octet_length(event_id),octet_length(schema_id),octet_length(payload),
    CASE WHEN typeof(offset)='blob' AND length(offset)=8 THEN offset END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN event_id END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN schema_id END,
    CASE WHEN typeof(schema_version)='integer' THEN schema_version END,
    CASE WHEN typeof(event_id)='text' AND typeof(schema_id)='text' AND typeof(payload)='blob'
        AND octet_length(event_id) BETWEEN 1 AND 256 AND octet_length(schema_id) BETWEEN 1 AND 256
        AND octet_length(payload)+octet_length(event_id)+octet_length(schema_id)+128<=?5 THEN payload END
    FROM event_records WHERE stream_key=?1 AND offset>?2 AND offset<=?3 ORDER BY offset LIMIT ?4";

#[derive(Clone, Debug)]
pub struct SqliteOptions {
    pub path: PathBuf,
    pub max_record_bytes: usize,
    pub worker_queue_capacity: usize,
    pub max_page_records: usize,
    pub max_page_bytes: usize,
    pub sqlite_cache_kib: u32,
    /// SQLite database-page quota. Journal files may temporarily use more disk space.
    pub max_database_pages: u32,
    pub busy_timeout: Duration,
    /// Deterministic one-shot failure hook for adapter boundary tests.
    #[doc(hidden)]
    pub failure_injection: Option<SqliteFailureInjection>,
}

#[doc(hidden)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SqliteFailureInjection {
    BeforeRecordInsert,
    AfterRecordInsert,
    BeforeCommit,
    AfterCommitAcknowledgementLost,
    PauseAfterCommitAcknowledgementLost(Duration),
    PauseBeforeCommit(Duration),
}
impl SqliteOptions {
    pub fn new(path: impl Into<PathBuf>) -> Self {
        Self {
            path: path.into(),
            max_record_bytes: 1024 * 1024,
            worker_queue_capacity: 256,
            max_page_records: 1024,
            max_page_bytes: 4 * 1024 * 1024,
            sqlite_cache_kib: 4096,
            max_database_pages: 262_144,
            busy_timeout: Duration::from_secs(5),
            failure_injection: None,
        }
    }
    fn validate(&self) -> Result<()> {
        if self.max_record_bytes == 0 {
            return Err(invalid("max_record_bytes must be positive"));
        }
        if self.worker_queue_capacity == 0 {
            return Err(invalid("worker_queue_capacity must be positive"));
        }
        if self.max_page_records == 0 || self.max_page_bytes == 0 {
            return Err(invalid("SQLite page limits must be positive"));
        }
        if self.sqlite_cache_kib == 0 || self.sqlite_cache_kib > i32::MAX as u32 {
            return Err(invalid("sqlite_cache_kib is out of range"));
        }
        if self.max_database_pages == 0 || self.max_database_pages > i32::MAX as u32 {
            return Err(invalid("max_database_pages is out of range"));
        }
        if self.busy_timeout.is_zero() {
            return Err(invalid("busy_timeout must be positive"));
        }
        if self.busy_timeout.as_millis() > i32::MAX as u128 {
            return Err(invalid("busy_timeout is out of range"));
        }
        Ok(())
    }
}
fn invalid(message: &str) -> Error {
    Error::InvalidConfig(message.into())
}

/// A single-worker SQLite adapter with bounded queues and caches.
///
/// The verified profile covers committed data across normal restart and process
/// termination. It does not claim survival across device power loss.
pub struct SqliteStore {
    inner: Arc<Inner>,
    capabilities: StoreCapabilities,
    limits: Limits,
}
struct Inner {
    tx: mpsc::Sender<Command>,
    gate: Mutex<()>,
    shared: Arc<Shared>,
}
struct Shared {
    state: AtomicU8,
    stopped: Notify,
}
#[derive(Clone, Copy)]
struct Limits {
    record: usize,
    page_records: usize,
    page_bytes: usize,
}
enum Command {
    Create(StreamId, oneshot::Sender<Result<StreamKey>>),
    Append(StreamKey, NewEvent, oneshot::Sender<Result<AppendReceipt>>),
    Lookup(
        StreamKey,
        EventId,
        oneshot::Sender<Result<Option<Arc<Record>>>>,
    ),
    Bounds(StreamKey, oneshot::Sender<Result<Bounds>>),
    Read(
        StreamKey,
        u64,
        u64,
        PageLimits,
        oneshot::Sender<Result<Page>>,
    ),
    Close(oneshot::Sender<Result<()>>),
}

struct Ownership {
    path: PathBuf,
    file: File,
}
static OWNED: OnceLock<Mutex<HashSet<PathBuf>>> = OnceLock::new();
impl Ownership {
    fn acquire(path: &Path) -> Result<Self> {
        let path = canonical_db(path)?;
        let registry = OWNED.get_or_init(|| Mutex::new(HashSet::new()));
        if !registry
            .lock()
            .map_err(|_| Error::StoreInUse)?
            .insert(path.clone())
        {
            return Err(Error::StoreInUse);
        }
        let result = (|| {
            let name = path
                .file_name()
                .and_then(|v| v.to_str())
                .ok_or_else(|| invalid("database file name must be UTF-8"))?;
            let lock_path = path.with_file_name(format!(".{name}.event-stream.lock"));
            if lock_path.exists()
                && std::fs::symlink_metadata(&lock_path)
                    .map_err(|e| Error::StoreWriteFailed(format!("inspect ownership lock: {e}")))?
                    .file_type()
                    .is_symlink()
            {
                return Err(invalid("ownership lock may not be a symbolic link"));
            }
            let file = OpenOptions::new()
                .read(true)
                .write(true)
                .create(true)
                .truncate(false)
                .open(lock_path)
                .map_err(|e| Error::StoreWriteFailed(format!("open ownership lock: {e}")))?;
            file.try_lock_exclusive().map_err(|_| Error::StoreInUse)?;
            Ok(Self {
                path: path.clone(),
                file,
            })
        })();
        if result.is_err() {
            remove_owned(&path);
        }
        result
    }
}
impl Drop for Ownership {
    fn drop(&mut self) {
        let _ = FileExt::unlock(&self.file);
        remove_owned(&self.path);
    }
}
fn remove_owned(path: &Path) {
    if let Some(registry) = OWNED.get() {
        if let Ok(mut paths) = registry.lock() {
            paths.remove(path);
        }
    }
}
fn canonical_db(path: &Path) -> Result<PathBuf> {
    let name = path
        .file_name()
        .ok_or_else(|| invalid("database path needs a file name"))?;
    if path.exists() {
        let metadata = std::fs::symlink_metadata(path)
            .map_err(|e| Error::StoreWriteFailed(format!("inspect database: {e}")))?;
        if metadata.file_type().is_symlink() {
            return Err(invalid("database path may not be a symbolic link"));
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            if metadata.nlink() != 1 {
                return Err(invalid("hard-linked database files are unsupported"));
            }
        }
    }
    let parent = path
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .canonicalize()
        .map_err(|e| Error::InvalidConfig(format!("database parent is unavailable: {e}")))?;
    Ok(parent.join(name))
}

#[async_trait]
impl EventStore for SqliteStore {
    type Options = SqliteOptions;
    async fn open(options: Self::Options) -> Result<Self> {
        options.validate()?;
        let ownership = Ownership::acquire(&options.path)?;
        let path = ownership.path.clone();
        let limits = Limits {
            record: options.max_record_bytes,
            page_records: options.max_page_records,
            page_bytes: options.max_page_bytes,
        };
        let (tx, rx) = mpsc::channel(options.worker_queue_capacity);
        let shared = Arc::new(Shared {
            state: AtomicU8::new(OPEN),
            stopped: Notify::new(),
        });
        let inner = Arc::new(Inner {
            tx,
            gate: Mutex::new(()),
            shared: shared.clone(),
        });
        let (ready_tx, ready_rx) = oneshot::channel();
        thread::Builder::new()
            .name("event-stream-sqlite".into())
            .spawn(move || worker(path, options, ownership, rx, shared, ready_tx))
            .map_err(|e| Error::StoreWriteFailed(format!("start SQLite worker: {e}")))?;
        ready_rx
            .await
            .map_err(|_| Error::StoreWriteFailed("SQLite worker stopped during open".into()))??;
        Ok(Self {
            inner,
            limits,
            capabilities: StoreCapabilities {
                persistence: PersistenceProfile::ProcessRestart,
                format_version: SQLITE_FORMAT_VERSION,
                max_record_bytes: limits.record,
                max_concurrent_reads: 1,
                max_concurrent_writes: 1,
                ownership: "exclusive in-process registry and OS file lock through worker shutdown",
            },
        })
    }
    fn capabilities(&self) -> StoreCapabilities {
        self.capabilities.clone()
    }
    async fn create_if_absent(&self, id: &StreamId) -> Result<StreamKey> {
        let (tx, rx) = oneshot::channel();
        self.submit(Command::Create(id.clone(), tx))?;
        recv(rx).await
    }
    async fn append_atomic(&self, stream: &StreamKey, event: NewEvent) -> Result<AppendReceipt> {
        if event.accounted_bytes() > self.limits.record {
            return Err(Error::PayloadTooLarge);
        }
        let (tx, rx) = oneshot::channel();
        self.submit(Command::Append(stream.clone(), event, tx))?;
        recv(rx).await
    }
    async fn lookup_event(&self, stream: &StreamKey, id: &EventId) -> Result<Option<Arc<Record>>> {
        let (tx, rx) = oneshot::channel();
        self.submit(Command::Lookup(stream.clone(), id.clone(), tx))?;
        recv(rx).await
    }
    async fn bounds(&self, stream: &StreamKey) -> Result<Bounds> {
        let (tx, rx) = oneshot::channel();
        self.submit(Command::Bounds(stream.clone(), tx))?;
        recv(rx).await
    }
    async fn read_range(
        &self,
        stream: &StreamKey,
        after: u64,
        through: u64,
        limits: PageLimits,
    ) -> Result<Page> {
        if limits.max_records == 0 || limits.max_bytes == 0 {
            return Err(invalid("page limits must be positive"));
        }
        if limits.max_records > self.limits.page_records
            || limits.max_bytes > self.limits.page_bytes
        {
            return Err(Error::CapacityExceeded);
        }
        if after > through {
            return Err(invalid("after must not exceed through"));
        }
        let (tx, rx) = oneshot::channel();
        self.submit(Command::Read(stream.clone(), after, through, limits, tx))?;
        recv(rx).await
    }
    async fn close(&self) -> Result<()> {
        let (reply_tx, reply_rx) = oneshot::channel();
        let first = {
            let _gate = self.inner.gate.lock().map_err(|_| Error::OwnershipLost)?;
            let first = self
                .inner
                .shared
                .state
                .compare_exchange(OPEN, CLOSING, Ordering::AcqRel, Ordering::Acquire)
                .is_ok();
            if first {
                match self.inner.tx.try_send(Command::Close(reply_tx)) {
                    Ok(()) => {}
                    Err(mpsc::error::TrySendError::Full(command)) => {
                        // The detached sender makes shutdown cancellation-safe. Once
                        // state changes to CLOSING, a dropped close future cannot
                        // prevent the close command from following accepted work.
                        let sender = self.inner.tx.clone();
                        thread::spawn(move || {
                            let _ = sender.blocking_send(command);
                        });
                    }
                    Err(mpsc::error::TrySendError::Closed(_)) => return self.closed_result(),
                }
            }
            first
        };
        if first {
            return recv(reply_rx).await;
        }
        self.wait_stopped().await;
        self.closed_result()
    }
}
impl SqliteStore {
    fn submit(&self, command: Command) -> Result<()> {
        let _gate = self.inner.gate.lock().map_err(|_| Error::OwnershipLost)?;
        match self.inner.shared.state.load(Ordering::Acquire) {
            OPEN => self.inner.tx.try_send(command).map_err(|e| match e {
                mpsc::error::TrySendError::Full(_) => Error::Overloaded,
                _ => Error::OwnershipLost,
            }),
            CLOSING | CLOSED => Err(Error::Closed),
            _ => Err(Error::OwnershipLost),
        }
    }
    async fn wait_stopped(&self) {
        loop {
            let notified = self.inner.shared.stopped.notified();
            if matches!(
                self.inner.shared.state.load(Ordering::Acquire),
                CLOSED | FAULTED
            ) {
                return;
            }
            notified.await;
        }
    }
    fn closed_result(&self) -> Result<()> {
        match self.inner.shared.state.load(Ordering::Acquire) {
            CLOSED => Ok(()),
            FAULTED => Err(Error::OwnershipLost),
            _ => Err(Error::Closed),
        }
    }
}
async fn recv<T>(rx: oneshot::Receiver<Result<T>>) -> Result<T> {
    rx.await.unwrap_or(Err(Error::OwnershipLost))
}

fn worker(
    path: PathBuf,
    options: SqliteOptions,
    ownership: Ownership,
    mut rx: mpsc::Receiver<Command>,
    shared: Arc<Shared>,
    ready: oneshot::Sender<Result<()>>,
) {
    let conn = match open_connection(&path, &options) {
        Ok(c) => {
            let _ = ready.send(Ok(()));
            c
        }
        Err(e) => {
            let _ = ready.send(Err(e));
            shared.state.store(FAULTED, Ordering::Release);
            shared.stopped.notify_waiters();
            return;
        }
    };
    let mut conn = Some(conn);
    let mut failure_injection = options.failure_injection;
    let mut close_reply = None;
    let mut fatal = false;
    while let Some(command) = rx.blocking_recv() {
        match command {
            Command::Create(id, tx) => {
                let _ = tx.send(create_stream(conn.as_mut().unwrap(), id));
            }
            Command::Append(stream, event, tx) => {
                let (r, f) = append(
                    conn.as_mut().unwrap(),
                    stream,
                    event,
                    &mut failure_injection,
                    options.max_record_bytes,
                );
                let _ = tx.send(r);
                if f {
                    fatal = true;
                    break;
                }
            }
            Command::Lookup(stream, id, tx) => {
                let _ = tx.send(lookup(
                    conn.as_ref().unwrap(),
                    &stream,
                    &id,
                    options.max_record_bytes,
                ));
            }
            Command::Bounds(stream, tx) => {
                let _ = tx.send(bounds(conn.as_ref().unwrap(), &stream));
            }
            Command::Read(stream, after, through, limits, tx) => {
                let _ = tx.send(read_page(
                    conn.as_ref().unwrap(),
                    &stream,
                    after,
                    through,
                    limits,
                    options.max_record_bytes,
                ));
            }
            Command::Close(tx) => {
                close_reply = Some(tx);
                break;
            }
        }
    }
    if fatal {
        while let Ok(command) = rx.try_recv() {
            fail(command);
        }
    }
    let close_result = conn
        .take()
        .unwrap()
        .close()
        .map_err(|(_, e)| write_error("close", e));
    drop(ownership);
    shared.state.store(
        if fatal || close_result.is_err() {
            FAULTED
        } else {
            CLOSED
        },
        Ordering::Release,
    );
    shared.stopped.notify_waiters();
    if let Some(tx) = close_reply {
        let _ = tx.send(close_result);
    }
}
fn fail(command: Command) {
    let e = || Error::RuntimeFaulted("SQLite connection cannot be safely reused".into());
    match command {
        Command::Create(_, tx) => {
            let _ = tx.send(Err(e()));
        }
        Command::Append(_, _, tx) => {
            let _ = tx.send(Err(e()));
        }
        Command::Lookup(_, _, tx) => {
            let _ = tx.send(Err(e()));
        }
        Command::Bounds(_, tx) => {
            let _ = tx.send(Err(e()));
        }
        Command::Read(_, _, _, _, tx) => {
            let _ = tx.send(Err(e()));
        }
        Command::Close(tx) => {
            let _ = tx.send(Err(e()));
        }
    }
}

fn open_connection(path: &Path, options: &SqliteOptions) -> Result<Connection> {
    let conn = Connection::open(path).map_err(|e| write_error("open database", e))?;
    conn.set_prepared_statement_cache_capacity(8);
    conn.busy_timeout(options.busy_timeout)
        .map_err(|e| write_error("set busy timeout", e))?;
    let encoding: String = conn
        .pragma_query_value(None, "encoding", |row| row.get(0))
        .map_err(|e| corrupt("read database encoding", e))?;
    if !encoding.eq_ignore_ascii_case("UTF-8") {
        return Err(Error::StoreCorrupt(format!(
            "storage format requires UTF-8 database encoding, found {encoding}"
        )));
    }
    // Reject foreign and newer formats before pragmas that persistently change
    // database state. Opening SQLite may still perform its own crash recovery.
    inspect_existing_format(&conn)?;
    conn.pragma_update(None, "journal_mode", "DELETE")
        .map_err(|e| write_error("set journal mode", e))?;
    conn.pragma_update(None, "synchronous", "FULL")
        .map_err(|e| write_error("set synchronous mode", e))?;
    conn.pragma_update(None, "foreign_keys", true)
        .map_err(|e| write_error("enable foreign keys", e))?;
    conn.pragma_update(None, "cache_size", -(options.sqlite_cache_kib as i64))
        .map_err(|e| write_error("set cache size", e))?;
    conn.pragma_update(None, "max_page_count", options.max_database_pages)
        .map_err(|e| write_error("set database quota", e))?;
    conn.pragma_update(None, "temp_store", "MEMORY")
        .map_err(|e| write_error("set temp store", e))?;
    initialize_schema(&conn)?;
    verify_configuration(&conn, options)?;
    Ok(conn)
}
fn initialize_schema(conn: &Connection) -> Result<()> {
    if inspect_existing_format(conn)? {
        return Ok(());
    }
    // ADR 0003's reproducible probe is examples/sqlite_schema_probe.rs. Results
    // vary with payload size, and no workload mix is selected. The ordinary
    // rowid table is the simpler SQLite baseline when neither layout wins all
    // measured cases.
    conn.execute_batch("BEGIN IMMEDIATE;
      CREATE TABLE IF NOT EXISTS event_stream_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),format_version INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS event_streams(stream_key INTEGER PRIMARY KEY,public_id TEXT NOT NULL UNIQUE,incarnation BLOB NOT NULL CHECK(length(incarnation)=16),floor BLOB NOT NULL CHECK(length(floor)=8),tail BLOB NOT NULL CHECK(length(tail)=8));
      CREATE TABLE IF NOT EXISTS event_records(stream_key INTEGER NOT NULL,offset BLOB NOT NULL CHECK(length(offset)=8),event_id TEXT NOT NULL,schema_id TEXT NOT NULL,schema_version INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(stream_key,offset),UNIQUE(stream_key,event_id),FOREIGN KEY(stream_key) REFERENCES event_streams(stream_key));
      INSERT OR IGNORE INTO event_stream_metadata(singleton,format_version) VALUES(1,1); COMMIT;")
        .map_err(|e| write_error("initialize schema", e))?;
    Ok(())
}

/// Returns true when this is an existing supported event-stream database.
fn inspect_existing_format(conn: &Connection) -> Result<bool> {
    let metadata_exists: bool = conn
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM sqlite_schema WHERE type='table' AND name='event_stream_metadata')",
            [],
            |row| row.get(0),
        )
        .map_err(|e| corrupt("inspect storage format", e))?;
    if metadata_exists {
        let version: Option<i64> = conn
            .query_row(
                "SELECT CASE WHEN typeof(format_version)='integer' THEN format_version END FROM event_stream_metadata WHERE singleton=1",
                [],
                |row| row.get(0),
            )
            .map_err(|e| corrupt("read format version", e))?;
        let version = version
            .ok_or_else(|| Error::StoreCorrupt("format version is not an integer".into()))?;
        let version = u32::try_from(version)
            .map_err(|_| Error::StoreCorrupt("format version is out of range".into()))?;
        if version != SQLITE_FORMAT_VERSION {
            return Err(Error::UnsupportedFormat(version));
        }
        let required_tables: u32 = conn
            .query_row(
                "SELECT count(*) FROM sqlite_schema WHERE type='table' AND name IN ('event_stream_metadata','event_streams','event_records')",
                [],
                |row| row.get(0),
            )
            .map_err(|e| corrupt("validate storage schema", e))?;
        if required_tables != 3 {
            return Err(Error::StoreCorrupt(
                "format metadata exists but required tables are missing".into(),
            ));
        }
        return Ok(true);
    }
    let application_tables: u32 = conn
        .query_row(
            "SELECT count(*) FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'",
            [],
            |row| row.get(0),
        )
        .map_err(|e| corrupt("inspect empty database", e))?;
    if application_tables != 0 {
        return Err(Error::StoreCorrupt(
            "database has tables but no event-stream format metadata".into(),
        ));
    }
    Ok(false)
}
fn verify_configuration(conn: &Connection, options: &SqliteOptions) -> Result<()> {
    let engine: String = conn
        .query_row("SELECT sqlite_version()", [], |row| row.get(0))
        .map_err(|e| write_error("read SQLite engine version", e))?;
    if engine != rusqlite::version() {
        return Err(Error::InvalidConfig(format!(
            "SQLite engine version mismatch: connection={engine}, binding={}",
            rusqlite::version()
        )));
    }
    let journal: String = conn
        .pragma_query_value(None, "journal_mode", |r| r.get(0))
        .map_err(|e| write_error("read journal mode", e))?;
    let sync: i64 = conn
        .pragma_query_value(None, "synchronous", |r| r.get(0))
        .map_err(|e| write_error("read synchronous", e))?;
    let fk: i64 = conn
        .pragma_query_value(None, "foreign_keys", |r| r.get(0))
        .map_err(|e| write_error("read foreign keys", e))?;
    let cache_size: i64 = conn
        .pragma_query_value(None, "cache_size", |r| r.get(0))
        .map_err(|e| write_error("read cache size", e))?;
    let max_pages: u32 = conn
        .pragma_query_value(None, "max_page_count", |r| r.get(0))
        .map_err(|e| write_error("read database quota", e))?;
    let temp_store: i64 = conn
        .pragma_query_value(None, "temp_store", |r| r.get(0))
        .map_err(|e| write_error("read temp store", e))?;
    let busy_timeout: i64 = conn
        .pragma_query_value(None, "busy_timeout", |r| r.get(0))
        .map_err(|e| write_error("read busy timeout", e))?;
    if max_pages != options.max_database_pages {
        return Err(Error::CapacityExceeded);
    }
    if !journal.eq_ignore_ascii_case("delete")
        || sync != 2
        || fk != 1
        || cache_size != -(options.sqlite_cache_kib as i64)
        || temp_store != 2
        || busy_timeout != options.busy_timeout.as_millis() as i64
    {
        return Err(Error::InvalidConfig(format!("effective SQLite settings differ: journal_mode={journal}, synchronous={sync}, foreign_keys={fk}, cache_size={cache_size}, temp_store={temp_store}, busy_timeout={busy_timeout}")));
    }
    Ok(())
}

fn create_stream(conn: &mut Connection, id: StreamId) -> Result<StreamKey> {
    if let Some(v) = conn
        .query_row(
            "SELECT CASE WHEN length(incarnation)=16 THEN incarnation END FROM event_streams WHERE public_id=?1",
            params![id.as_str()],
            |r| r.get::<_, Vec<u8>>(0),
        )
        .optional()
        .map_err(|e| corrupt("read stream", e))?
    {
        return Ok(StreamKey {
            id,
            incarnation: decode_incarnation(&v)?,
        });
    }
    let incarnation = super::new_incarnation();
    conn.execute(
        "INSERT INTO event_streams(public_id,incarnation,floor,tail) VALUES(?1,?2,?3,?3)",
        params![id.as_str(), incarnation.0.as_slice(), be(0).as_slice()],
    )
    .map_err(|e| write_error("create stream", e))?;
    Ok(StreamKey { id, incarnation })
}
fn stream_row(conn: &Connection, stream: &StreamKey) -> Result<(i64, u64, u64)> {
    let row = conn
        .query_row(
            "SELECT stream_key,
                    CASE WHEN length(incarnation)=16 THEN incarnation END,
                    CASE WHEN length(floor)=8 THEN floor END,
                    CASE WHEN length(tail)=8 THEN tail END
             FROM event_streams WHERE public_id=?1",
            params![stream.id.as_str()],
            |r| {
                Ok((
                    r.get::<_, i64>(0)?,
                    r.get::<_, Vec<u8>>(1)?,
                    r.get::<_, Vec<u8>>(2)?,
                    r.get::<_, Vec<u8>>(3)?,
                ))
            },
        )
        .optional()
        .map_err(|e| corrupt("read stream state", e))?
        .ok_or(Error::StreamNotFound)?;
    if decode_incarnation(&row.1)? != stream.incarnation {
        return Err(Error::InvalidCursor(
            "stream incarnation does not match".into(),
        ));
    }
    let floor = decode_offset(&row.2)?;
    let tail = decode_offset(&row.3)?;
    if floor > tail {
        return Err(Error::StoreCorrupt(
            "stream floor is greater than its tail".into(),
        ));
    }
    Ok((row.0, floor, tail))
}
fn append(
    conn: &mut Connection,
    stream: StreamKey,
    event: NewEvent,
    failure_injection: &mut Option<SqliteFailureInjection>,
    max_record_bytes: usize,
) -> (Result<AppendReceipt>, bool) {
    let retry_id = event.id.clone();
    let result = (|| {
        let tx = conn
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| write_error("begin append", e))?;
        let (key, _, tail) = stream_row(&tx, &stream)?;
        if let Some(record) = lookup_key(&tx, &stream, key, &event.id, max_record_bytes)? {
            let same = record.event.schema == event.schema && record.event.payload == event.payload;
            tx.rollback().map_err(|e| write_error("finish retry", e))?;
            return if same {
                Ok(AppendReceipt {
                    record,
                    kind: AppendKind::Deduplicated,
                })
            } else {
                Err(Error::IdempotencyConflict { event_id: event.id })
            };
        }
        let offset = tail.checked_add(1).ok_or(Error::OffsetOverflow)?;
        if matches!(
            failure_injection,
            Some(SqliteFailureInjection::BeforeRecordInsert)
        ) {
            *failure_injection = None;
            return injected_rollback(tx, "before record insert");
        }
        if let Err(e)=tx.execute("INSERT INTO event_records(stream_key,offset,event_id,schema_id,schema_version,payload) VALUES(?1,?2,?3,?4,?5,?6)",params![key,be(offset).as_slice(),event.id.as_str(),event.schema.id.as_str(),i64::from(event.schema.version),event.payload.as_bytes()]){return rollback(tx,"insert event",e);}
        if matches!(
            failure_injection,
            Some(SqliteFailureInjection::AfterRecordInsert)
        ) {
            *failure_injection = None;
            return injected_rollback(tx, "after record insert");
        }
        if let Err(e) = tx.execute(
            "UPDATE event_streams SET tail=?1 WHERE stream_key=?2",
            params![be(offset).as_slice(), key],
        ) {
            return rollback(tx, "update tail", e);
        }
        if matches!(
            failure_injection,
            Some(SqliteFailureInjection::BeforeCommit)
        ) {
            *failure_injection = None;
            return injected_rollback(tx, "after tail update");
        }
        if let Some(SqliteFailureInjection::PauseBeforeCommit(delay)) = *failure_injection {
            *failure_injection = None;
            thread::sleep(delay);
        }
        let record = Arc::new(Record {
            cursor: Cursor::new(stream.clone(), offset),
            event,
        });
        tx.commit()
            .map(|_| AppendReceipt {
                record,
                kind: AppendKind::Inserted,
            })
            .and_then(|receipt| {
                if matches!(
                    failure_injection,
                    Some(SqliteFailureInjection::AfterCommitAcknowledgementLost)
                ) {
                    *failure_injection = None;
                    Err(rusqlite::Error::InvalidQuery)
                } else if let Some(SqliteFailureInjection::PauseAfterCommitAcknowledgementLost(
                    delay,
                )) = *failure_injection
                {
                    *failure_injection = None;
                    thread::sleep(delay);
                    Err(rusqlite::Error::InvalidQuery)
                } else {
                    Ok(receipt)
                }
            })
            .map_err(|_| Error::CommitUnknown {
                event_id: retry_id.clone(),
            })
    })();
    match result {
        Err(Error::CommitUnknown { .. }) => {
            match lookup(conn, &stream, &retry_id, max_record_bytes) {
                Ok(Some(record)) => (
                    Ok(AppendReceipt {
                        record,
                        kind: AppendKind::Inserted,
                    }),
                    false,
                ),
                Ok(None) => (
                    Err(Error::StoreWriteFailed(
                        "append commit failed and no record committed".into(),
                    )),
                    false,
                ),
                Err(_) => (Err(Error::CommitUnknown { event_id: retry_id }), true),
            }
        }
        other @ Err(Error::StoreCorrupt(_)) => (other, true),
        other => (other, false),
    }
}
fn injected_rollback<T>(tx: rusqlite::Transaction<'_>, position: &str) -> Result<T> {
    tx.rollback()
        .map_err(|e| Error::StoreCorrupt(format!("injected rollback failed at {position}: {e}")))?;
    Err(Error::StoreWriteFailed(format!(
        "injected failure {position}"
    )))
}
fn rollback<T>(tx: rusqlite::Transaction<'_>, action: &str, error: rusqlite::Error) -> Result<T> {
    let original = write_error(action, error);
    // SQLITE_FULL and some I/O failures can make SQLite roll back before the
    // statement returns. Autocommit then proves that no transaction remains.
    if tx.is_autocommit() {
        return Err(original);
    }
    match tx.rollback() {
        Ok(()) => Err(original),
        Err(e) => Err(Error::StoreCorrupt(format!(
            "{original}; rollback also failed: {e}"
        ))),
    }
}
fn lookup(
    conn: &Connection,
    stream: &StreamKey,
    id: &EventId,
    max_record_bytes: usize,
) -> Result<Option<Arc<Record>>> {
    let (key, _, _) = stream_row(conn, stream)?;
    lookup_key(conn, stream, key, id, max_record_bytes)
}
fn lookup_key(
    conn: &Connection,
    stream: &StreamKey,
    key: i64,
    id: &EventId,
    max_record_bytes: usize,
) -> Result<Option<Arc<Record>>> {
    conn.query_row(
        LOOKUP_RECORD_SQL,
        params![key, id.as_str(), record_limit(max_record_bytes)],
        |r| decode_row(r, stream, max_record_bytes),
    )
    .optional()
    .map_err(|e| corrupt("lookup event", e))?
    .transpose()
    .map(|record| record.map(Arc::new))
}
fn bounds(conn: &Connection, stream: &StreamKey) -> Result<Bounds> {
    let (_, floor, tail) = stream_row(conn, stream)?;
    Ok(Bounds {
        floor: Cursor::new(stream.clone(), floor),
        tail: Cursor::new(stream.clone(), tail),
    })
}
fn read_page(
    conn: &Connection,
    stream: &StreamKey,
    after: u64,
    through: u64,
    limits: PageLimits,
    max_record_bytes: usize,
) -> Result<Page> {
    let (key, floor, tail) = stream_row(conn, stream)?;
    let bounds = Bounds {
        floor: Cursor::new(stream.clone(), floor),
        tail: Cursor::new(stream.clone(), tail),
    };
    if after < floor {
        return Err(Error::HistoryUnavailable { bounds });
    }
    if after > tail || through > tail {
        return Err(Error::CursorAhead { tail: bounds.tail });
    }
    if after == through {
        let c = Cursor::new(stream.clone(), after);
        return Ok(Page {
            records: vec![],
            next_after: c,
            through: Cursor::new(stream.clone(), through),
            complete: true,
        });
    }
    let mut stmt = conn
        .prepare_cached(READ_RECORD_SQL)
        .map_err(|e| corrupt("prepare range", e))?;
    let limit = i64::try_from(limits.max_records).map_err(|_| Error::CapacityExceeded)?;
    let mut rows = stmt
        .query(params![
            key,
            be(after).as_slice(),
            be(through).as_slice(),
            limit,
            record_limit(max_record_bytes),
        ])
        .map_err(|e| corrupt("start range", e))?;
    let mut records = Vec::with_capacity(limits.max_records.min(64));
    let mut bytes = 0usize;
    let mut byte_limited = false;
    let mut expected = after.checked_add(1).ok_or(Error::OffsetOverflow)?;
    while let Some(row) = rows.next().map_err(|e| corrupt("step range", e))? {
        let record = Arc::new(
            decode_row(row, stream, max_record_bytes)
                .map_err(|e| corrupt("decode range row", e))??,
        );
        if record.cursor.offset != expected {
            return Err(Error::StoreCorrupt(format!(
                "history gap: expected {expected}, found {}",
                record.cursor.offset
            )));
        }
        let size = record.event.accounted_bytes();
        if bytes.saturating_add(size) > limits.max_bytes {
            if records.is_empty() {
                return Err(Error::CapacityExceeded);
            }
            byte_limited = true;
            break;
        }
        bytes += size;
        if record.cursor.offset != u64::MAX {
            expected = record.cursor.offset + 1;
        }
        records.push(record);
    }
    if records.is_empty() {
        return Err(Error::StoreCorrupt(format!(
            "missing record after {after} through {through}"
        )));
    }
    let next = records.last().unwrap().cursor.offset;
    if next != through && records.len() < limits.max_records && !byte_limited {
        return Err(Error::StoreCorrupt(format!(
            "missing record after {next} through {through}"
        )));
    }
    Ok(Page {
        records,
        next_after: Cursor::new(stream.clone(), next),
        through: Cursor::new(stream.clone(), through),
        complete: next == through,
    })
}
fn decode_row(
    row: &rusqlite::Row<'_>,
    stream: &StreamKey,
    max_record_bytes: usize,
) -> rusqlite::Result<Result<Record>> {
    let event_len: i64 = row.get(0)?;
    let schema_len: i64 = row.get(1)?;
    let payload_len: i64 = row.get(2)?;
    Ok((|| {
        let event_len = usize::try_from(event_len)
            .map_err(|_| Error::StoreCorrupt("negative event identifier length".into()))?;
        let schema_len = usize::try_from(schema_len)
            .map_err(|_| Error::StoreCorrupt("negative schema identifier length".into()))?;
        let payload_len = usize::try_from(payload_len)
            .map_err(|_| Error::StoreCorrupt("negative payload length".into()))?;
        if event_len == 0
            || event_len > MAX_IDENTIFIER_BYTES
            || schema_len == 0
            || schema_len > MAX_IDENTIFIER_BYTES
        {
            return Err(Error::StoreCorrupt(
                "stored identifier length is invalid".into(),
            ));
        }
        if payload_len
            .saturating_add(event_len)
            .saturating_add(schema_len)
            .saturating_add(128)
            > max_record_bytes
        {
            return Err(Error::StoreCorrupt(
                "stored record exceeds the configured allocation bound".into(),
            ));
        }
        let offset: Option<Vec<u8>> = row.get(3).map_err(|e| corrupt("read offset", e))?;
        let offset =
            offset.ok_or_else(|| Error::StoreCorrupt("offset is not an eight-byte blob".into()))?;
        let event: Option<String> = row
            .get(4)
            .map_err(|e| corrupt("read event identifier", e))?;
        let event = event.ok_or_else(|| {
            Error::StoreCorrupt("stored event identifier failed allocation guards".into())
        })?;
        let schema: Option<String> = row
            .get(5)
            .map_err(|e| corrupt("read schema identifier", e))?;
        let schema = schema.ok_or_else(|| {
            Error::StoreCorrupt("stored schema identifier failed allocation guards".into())
        })?;
        let version: Option<i64> = row.get(6).map_err(|e| corrupt("read schema version", e))?;
        let version = version
            .ok_or_else(|| Error::StoreCorrupt("schema version is not an integer".into()))?;
        let payload: Option<Vec<u8>> = row.get(7).map_err(|e| corrupt("read payload", e))?;
        let payload = payload
            .ok_or_else(|| Error::StoreCorrupt("stored payload failed allocation guards".into()))?;
        Ok(Record {
            cursor: Cursor::new(stream.clone(), decode_offset(&offset)?),
            event: NewEvent {
                id: EventId::new(event).map_err(|_| {
                    Error::StoreCorrupt("stored event identifier is invalid".into())
                })?,
                schema: SchemaRef {
                    id: SchemaId::new(schema).map_err(|_| {
                        Error::StoreCorrupt("stored schema identifier is invalid".into())
                    })?,
                    version: u32::try_from(version)
                        .map_err(|_| Error::StoreCorrupt("schema version out of range".into()))?,
                },
                payload: Payload::copy_from_slice(&payload),
            },
        })
    })())
}
fn be(v: u64) -> [u8; 8] {
    v.to_be_bytes()
}
fn record_limit(max_record_bytes: usize) -> i64 {
    i64::try_from(max_record_bytes).unwrap_or(i64::MAX)
}
fn decode_offset(v: &[u8]) -> Result<u64> {
    Ok(u64::from_be_bytes(v.try_into().map_err(|_| {
        Error::StoreCorrupt("offset is not eight bytes".into())
    })?))
}
fn decode_incarnation(v: &[u8]) -> Result<IncarnationId> {
    Ok(IncarnationId(v.try_into().map_err(|_| {
        Error::StoreCorrupt("incarnation is not 16 bytes".into())
    })?))
}
fn corrupt(action: &str, e: rusqlite::Error) -> Error {
    Error::StoreCorrupt(format!("{action}: {e}"))
}
fn write_error(action: &str, e: rusqlite::Error) -> Error {
    if let rusqlite::Error::SqliteFailure(code, _) = &e {
        if matches!(
            code.code,
            ErrorCode::DatabaseCorrupt | ErrorCode::NotADatabase
        ) {
            return corrupt(action, e);
        }
        if code.code == ErrorCode::DiskFull {
            return Error::CapacityExceeded;
        }
    }
    Error::StoreWriteFailed(format!("{action}: {e}"))
}
