use super::{
    Error, EventReader, EventRuntime, EventSink, EventStore, EventSubscription, PersistenceProfile,
    Result, ShutdownReport, StartPosition, StoreCapabilities, SubscriptionOptions,
    UnresolvedAppend,
};
use crate::domain::*;
use async_trait::async_trait;
use std::{
    collections::{HashMap, VecDeque},
    future::Future,
    sync::{
        atomic::{AtomicBool, AtomicUsize, Ordering},
        Arc, Mutex as StdMutex, Weak,
    },
    time::{Duration, Instant},
};
use tokio::sync::{oneshot, Mutex, Notify, OwnedSemaphorePermit, Semaphore};

/// Finite runtime budgets. Byte limits charge `NewEvent::accounted_bytes()`.
#[derive(Clone, Debug)]
pub struct RuntimeConfig {
    pub max_event_bytes: usize,
    pub minimum_persistence: PersistenceProfile,
    pub max_queued_appends: usize,
    pub max_queued_append_bytes: usize,
    pub max_stream_queued_appends: usize,
    pub max_stream_queued_bytes: usize,
    pub max_admission_waiters: usize,
    pub max_admission_waiter_bytes: usize,
    pub admission_timeout: Duration,
    pub max_coordinators: usize,
    pub storage_workers: usize,
    pub work_per_stream_turn: usize,
    pub max_concurrent_reads: usize,
    pub max_read_waiters: usize,
    pub read_admission_timeout: Duration,
    pub max_subscriptions: usize,
    pub max_stream_subscriptions: usize,
    pub max_page_records: usize,
    pub max_page_bytes: usize,
    pub max_buffered_page_bytes: usize,
    pub subscriber_sweep_interval: Duration,
    pub subscribers_per_sweep: usize,
    pub diagnostic_capacity: usize,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            max_event_bytes: 1024 * 1024,
            minimum_persistence: PersistenceProfile::Ephemeral,
            max_queued_appends: 1024,
            max_queued_append_bytes: 16 * 1024 * 1024,
            max_stream_queued_appends: 128,
            max_stream_queued_bytes: 4 * 1024 * 1024,
            max_admission_waiters: 1024,
            max_admission_waiter_bytes: 16 * 1024 * 1024,
            admission_timeout: Duration::from_secs(5),
            max_coordinators: 1024,
            storage_workers: 1,
            work_per_stream_turn: 1,
            max_concurrent_reads: 1,
            max_read_waiters: 1024,
            read_admission_timeout: Duration::from_secs(5),
            max_subscriptions: 1024,
            max_stream_subscriptions: 128,
            max_page_records: 256,
            max_page_bytes: 1024 * 1024,
            max_buffered_page_bytes: 16 * 1024 * 1024,
            subscriber_sweep_interval: Duration::from_millis(250),
            subscribers_per_sweep: 64,
            diagnostic_capacity: 256,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeLifecycle {
    Ready,
    Draining,
    Faulted,
    Closed,
}

#[derive(Clone, Debug)]
pub enum DiagnosticKind {
    AppendAccepted,
    AppendInserted,
    AppendDeduplicated,
    AppendRejected,
    ReadPage,
    SubscriberEnded,
    RuntimeFaulted,
    Shutdown,
}

#[derive(Clone, Debug)]
pub struct DiagnosticSample {
    pub kind: DiagnosticKind,
    pub detail: &'static str,
}

#[derive(Clone, Debug)]
pub struct RuntimeDiagnostics {
    pub lifecycle: RuntimeLifecycle,
    pub persistence: PersistenceProfile,
    pub accepts_writes: bool,
    pub queued_appends: usize,
    pub queued_append_bytes: usize,
    pub admission_waiters: usize,
    pub active_subscriptions: usize,
    /// Append calls admitted into the owned runtime queue since open.
    pub append_accepted: u64,
    /// Append calls rejected before admission since open.
    pub append_rejected: u64,
    /// Accepted calls completed with an inserted receipt since open.
    pub append_inserted: u64,
    /// Accepted calls completed with a deduplicated receipt since open.
    pub append_deduplicated: u64,
    /// Accepted calls completed with an error since open.
    pub append_failed: u64,
    pub peak_queued_appends: usize,
    pub peak_queued_append_bytes: usize,
    pub samples: Vec<DiagnosticSample>,
}

pub struct Runtime<S: EventStore> {
    inner: Arc<Inner<S>>,
}

impl<S: EventStore> Clone for Runtime<S> {
    fn clone(&self) -> Self {
        self.inner.handles.fetch_add(1, Ordering::Relaxed);
        Self {
            inner: self.inner.clone(),
        }
    }
}

impl<S: EventStore> Drop for Runtime<S> {
    fn drop(&mut self) {
        if self.inner.handles.fetch_sub(1, Ordering::AcqRel) != 1
            || self.inner.drop_started.swap(true, Ordering::AcqRel)
        {
            return;
        }
        let handle = self.inner.executor.clone();
        let inner = self.inner.clone();
        handle.spawn(async move {
            let mut state = inner.state.lock().await;
            if matches!(
                state.lifecycle,
                RuntimeLifecycle::Ready | RuntimeLifecycle::Faulted
            ) {
                state.lifecycle = RuntimeLifecycle::Draining;
                end_all_subscriptions(&mut state, Error::Closed);
            }
            drop(state);
            inner.changed.notify_waiters();
            spawn_finalizer(inner);
        });
    }
}

struct Inner<S: EventStore> {
    executor: tokio::runtime::Handle,
    store: Arc<S>,
    capabilities: StoreCapabilities,
    config: RuntimeConfig,
    state: Mutex<State>,
    changed: Notify,
    read_slots: Arc<Semaphore>,
    read_waiters: Arc<Semaphore>,
    page_bytes: Arc<Semaphore>,
    handles: AtomicUsize,
    drop_started: AtomicBool,
}

struct State {
    lifecycle: RuntimeLifecycle,
    fault: Option<String>,
    coordinators: HashMap<StreamKey, Arc<Coordinator>>,
    ready: VecDeque<StreamKey>,
    queued_count: usize,
    queued_bytes: usize,
    waiter_count: usize,
    waiter_bytes: usize,
    subscriptions: usize,
    active_io: usize,
    unresolved: HashMap<(StreamKey, EventId), usize>,
    append_accepted: u64,
    append_rejected: u64,
    append_inserted: u64,
    append_deduplicated: u64,
    append_failed: u64,
    peak_queued_appends: usize,
    peak_queued_append_bytes: usize,
    close_started: bool,
    samples: VecDeque<DiagnosticSample>,
}

struct Coordinator {
    key: StreamKey,
    write_gate: Arc<Mutex<()>>,
    state: StdMutex<CoordinatorState>,
    wake: Notify,
}

struct CoordinatorState {
    queue: VecDeque<PendingAppend>,
    queued_bytes: usize,
    scheduled: bool,
    in_flight: usize,
    observed_floor: u64,
    observed_tail: u64,
    generation: u64,
    subscriptions: Vec<Weak<SubscriptionShared>>,
    subscription_reservations: usize,
}

struct PendingAppend {
    event: NewEvent,
    bytes: usize,
    result: oneshot::Sender<Result<AppendReceipt>>,
}

struct SubscriptionShared {
    state: StdMutex<SharedSubscriptionState>,
}

struct SharedSubscriptionState {
    last_delivered: Cursor,
    created: Instant,
    behind_since: Option<Instant>,
    ended: Option<Error>,
    terminal_delivered: bool,
    registered: bool,
    buffer: VecDeque<Arc<Record>>,
    page_permit: Option<OwnedSemaphorePermit>,
    max_lag_records: u64,
    max_lag_duration: Duration,
    catch_up_grace: Duration,
}

struct AdmissionWaiterGuard<S: EventStore> {
    inner: Arc<Inner<S>>,
    bytes: usize,
    coordinator: StreamKey,
    active: bool,
}

struct SubscriptionReservationGuard<S: EventStore> {
    inner: Arc<Inner<S>>,
    coordinator: Arc<Coordinator>,
    active: bool,
}

impl<S: EventStore> SubscriptionReservationGuard<S> {
    fn disarm(&mut self) {
        self.active = false;
    }
}

impl<S: EventStore> Drop for SubscriptionReservationGuard<S> {
    fn drop(&mut self) {
        if !self.active {
            return;
        }
        let inner = self.inner.clone();
        let coordinator = self.coordinator.clone();
        let executor = inner.executor.clone();
        executor.spawn(async move {
            let mut state = inner.state.lock().await;
            state.subscriptions = state.subscriptions.saturating_sub(1);
            let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
            cs.subscription_reservations = cs.subscription_reservations.saturating_sub(1);
            drop(cs);
            cleanup_coordinator(&mut state, &coordinator.key);
            inner.changed.notify_waiters();
        });
    }
}

impl<S: EventStore> AdmissionWaiterGuard<S> {
    fn disarm(&mut self) {
        self.active = false;
    }
}

impl<S: EventStore> Drop for AdmissionWaiterGuard<S> {
    fn drop(&mut self) {
        if !self.active {
            return;
        }
        let inner = self.inner.clone();
        let bytes = self.bytes;
        let key = self.coordinator.clone();
        let executor = inner.executor.clone();
        executor.spawn(async move {
            let mut state = inner.state.lock().await;
            state.waiter_count = state.waiter_count.saturating_sub(1);
            state.waiter_bytes = state.waiter_bytes.saturating_sub(bytes);
            cleanup_coordinator(&mut state, &key);
            inner.changed.notify_waiters();
        });
    }
}

pub struct RuntimeSubscription<S: EventStore> {
    inner: Arc<Inner<S>>,
    coordinator: Arc<Coordinator>,
    shared: Arc<SubscriptionShared>,
    last_delivered: Cursor,
    replay_high: u64,
    options: SubscriptionOptions,
}

impl RuntimeConfig {
    fn validate_shape(&self) -> Result<()> {
        let nonzero = [
            self.max_event_bytes,
            self.max_queued_appends,
            self.max_queued_append_bytes,
            self.max_stream_queued_appends,
            self.max_stream_queued_bytes,
            self.max_admission_waiters,
            self.max_admission_waiter_bytes,
            self.max_coordinators,
            self.storage_workers,
            self.work_per_stream_turn,
            self.max_concurrent_reads,
            self.max_read_waiters,
            self.max_subscriptions,
            self.max_stream_subscriptions,
            self.max_page_records,
            self.max_page_bytes,
            self.max_buffered_page_bytes,
            self.subscribers_per_sweep,
            self.diagnostic_capacity,
        ];
        if nonzero.contains(&0)
            || self.admission_timeout.is_zero()
            || self.subscriber_sweep_interval.is_zero()
            || self.read_admission_timeout.is_zero()
        {
            return Err(Error::InvalidConfig(
                "runtime limits must be nonzero".into(),
            ));
        }
        if self.max_stream_queued_appends > self.max_queued_appends
            || self.max_stream_queued_bytes > self.max_queued_append_bytes
            || self.max_stream_subscriptions > self.max_subscriptions
        {
            return Err(Error::InvalidConfig(
                "per-stream limits must fit global limits".into(),
            ));
        }
        if self.max_event_bytes > self.max_stream_queued_bytes
            || self.max_event_bytes > self.max_queued_append_bytes
            || self.max_event_bytes > self.max_admission_waiter_bytes
        {
            return Err(Error::InvalidConfig(
                "one maximum-size event must fit every append byte budget".into(),
            ));
        }
        if self.max_buffered_page_bytes > u32::MAX as usize {
            return Err(Error::InvalidConfig(
                "buffered page byte budget exceeds semaphore range".into(),
            ));
        }
        Ok(())
    }

    fn validate(&self, capabilities: &StoreCapabilities) -> Result<()> {
        self.validate_shape()?;
        if self.max_event_bytes > capabilities.max_record_bytes {
            return Err(Error::InvalidConfig(
                "runtime event limit exceeds store capability".into(),
            ));
        }
        if capabilities.persistence < self.minimum_persistence {
            return Err(Error::InvalidConfig(
                "store persistence is weaker than the required profile".into(),
            ));
        }
        if self.max_page_bytes < self.max_event_bytes
            || self.max_buffered_page_bytes < self.max_page_bytes
        {
            return Err(Error::InvalidConfig(
                "a page must fit one maximum-size event".into(),
            ));
        }
        if self.storage_workers > capabilities.max_concurrent_writes
            || self.max_concurrent_reads > capabilities.max_concurrent_reads
        {
            return Err(Error::InvalidConfig(
                "runtime storage concurrency exceeds store capability".into(),
            ));
        }
        Ok(())
    }
}

impl<S: EventStore> Runtime<S> {
    pub async fn open(options: S::Options, config: RuntimeConfig) -> Result<Self> {
        config.validate_shape()?;
        let executor = tokio::runtime::Handle::current();
        let store = Arc::new(S::open(options).await?);
        let capabilities = store.capabilities();
        if let Err(error) = config.validate(&capabilities) {
            let _ = store.close().await;
            return Err(error);
        }
        let inner = Arc::new(Inner {
            executor,
            store,
            capabilities,
            read_slots: Arc::new(Semaphore::new(config.max_concurrent_reads)),
            read_waiters: Arc::new(Semaphore::new(config.max_read_waiters)),
            page_bytes: Arc::new(Semaphore::new(config.max_buffered_page_bytes)),
            handles: AtomicUsize::new(1),
            drop_started: AtomicBool::new(false),
            config,
            state: Mutex::new(State {
                lifecycle: RuntimeLifecycle::Ready,
                fault: None,
                coordinators: HashMap::new(),
                ready: VecDeque::new(),
                queued_count: 0,
                queued_bytes: 0,
                waiter_count: 0,
                waiter_bytes: 0,
                subscriptions: 0,
                active_io: 0,
                unresolved: HashMap::new(),
                append_accepted: 0,
                append_rejected: 0,
                append_inserted: 0,
                append_deduplicated: 0,
                append_failed: 0,
                peak_queued_appends: 0,
                peak_queued_append_bytes: 0,
                close_started: false,
                samples: VecDeque::new(),
            }),
            changed: Notify::new(),
        });
        for _ in 0..inner.config.storage_workers {
            tokio::spawn(worker(inner.clone()));
        }
        tokio::spawn(subscription_sweeper(Arc::downgrade(&inner)));
        Ok(Self { inner })
    }

    pub async fn diagnostics(&self) -> RuntimeDiagnostics {
        let state = self.inner.state.lock().await;
        RuntimeDiagnostics {
            lifecycle: state.lifecycle,
            persistence: self.inner.capabilities.persistence,
            accepts_writes: state.lifecycle == RuntimeLifecycle::Ready,
            queued_appends: state.queued_count,
            queued_append_bytes: state.queued_bytes,
            admission_waiters: state.waiter_count,
            active_subscriptions: state.subscriptions,
            append_accepted: state.append_accepted,
            append_rejected: state.append_rejected,
            append_inserted: state.append_inserted,
            append_deduplicated: state.append_deduplicated,
            append_failed: state.append_failed,
            peak_queued_appends: state.peak_queued_appends,
            peak_queued_append_bytes: state.peak_queued_append_bytes,
            samples: state.samples.iter().cloned().collect(),
        }
    }

    async fn enqueue(
        &self,
        stream: &StreamKey,
        event: NewEvent,
        wait: bool,
    ) -> Result<AppendReceipt> {
        let bytes = event.accounted_bytes();
        if bytes > self.inner.config.max_event_bytes {
            let mut state = self.inner.state.lock().await;
            state.append_rejected = state.append_rejected.saturating_add(1);
            return Err(Error::PayloadTooLarge);
        }
        let deadline = Instant::now() + self.inner.config.admission_timeout;
        let mut registered_waiter = false;
        let mut waiter_guard: Option<AdmissionWaiterGuard<S>> = None;
        loop {
            let notified = self.inner.changed.notified();
            let mut state = self.inner.state.lock().await;
            if let Err(error) = ensure_ready(&state) {
                state.append_rejected = state.append_rejected.saturating_add(1);
                return Err(error);
            }
            let coordinator = match state.coordinators.get(stream).cloned() {
                Some(c) => c,
                None => {
                    if state.coordinators.len() >= self.inner.config.max_coordinators {
                        if !wait {
                            state.append_rejected = state.append_rejected.saturating_add(1);
                            return Err(Error::Overloaded);
                        }
                        if !registered_waiter {
                            if let Err(error) =
                                register_waiter(&mut state, &self.inner.config, bytes)
                            {
                                state.append_rejected = state.append_rejected.saturating_add(1);
                                return Err(error);
                            }
                            registered_waiter = true;
                            waiter_guard = Some(AdmissionWaiterGuard {
                                inner: self.inner.clone(),
                                bytes,
                                coordinator: stream.clone(),
                                active: true,
                            });
                        }
                        drop(state);
                        if tokio::time::timeout_at(deadline.into(), notified)
                            .await
                            .is_err()
                        {
                            drop(waiter_guard.take());
                            let mut state = self.inner.state.lock().await;
                            state.append_rejected = state.append_rejected.saturating_add(1);
                            return Err(Error::AdmissionTimeout);
                        }
                        continue;
                    }
                    let c = Arc::new(Coordinator {
                        key: stream.clone(),
                        write_gate: Arc::new(Mutex::new(())),
                        state: StdMutex::new(CoordinatorState {
                            queue: VecDeque::new(),
                            queued_bytes: 0,
                            scheduled: false,
                            in_flight: 0,
                            observed_floor: 0,
                            observed_tail: 0,
                            generation: 0,
                            subscriptions: Vec::new(),
                            subscription_reservations: 0,
                        }),
                        wake: Notify::new(),
                    });
                    state.coordinators.insert(stream.clone(), c.clone());
                    c
                }
            };
            let accepted = {
                let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
                let capacity = state.queued_count < self.inner.config.max_queued_appends
                    && state
                        .queued_bytes
                        .checked_add(bytes)
                        .is_some_and(|n| n <= self.inner.config.max_queued_append_bytes)
                    && cs.queue.len() + cs.in_flight < self.inner.config.max_stream_queued_appends
                    && cs
                        .queued_bytes
                        .checked_add(bytes)
                        .is_some_and(|n| n <= self.inner.config.max_stream_queued_bytes);
                if capacity {
                    if registered_waiter {
                        state.waiter_count -= 1;
                        state.waiter_bytes -= bytes;
                        if let Some(guard) = &mut waiter_guard {
                            guard.disarm();
                        }
                    }
                    let (sender, receiver) = oneshot::channel();
                    cs.queue.push_back(PendingAppend {
                        event: event.clone(),
                        bytes,
                        result: sender,
                    });
                    cs.queued_bytes += bytes;
                    state.queued_count += 1;
                    state.queued_bytes += bytes;
                    state.append_accepted = state.append_accepted.saturating_add(1);
                    state.peak_queued_appends = state.peak_queued_appends.max(state.queued_count);
                    state.peak_queued_append_bytes =
                        state.peak_queued_append_bytes.max(state.queued_bytes);
                    *state
                        .unresolved
                        .entry((stream.clone(), event.id.clone()))
                        .or_default() += 1;
                    if !cs.scheduled && cs.in_flight == 0 {
                        cs.scheduled = true;
                        state.ready.push_back(stream.clone());
                    }
                    Some(receiver)
                } else {
                    None
                }
            };
            if let Some(receiver) = accepted {
                sample(
                    &mut state,
                    &self.inner.config,
                    DiagnosticKind::AppendAccepted,
                    "accepted",
                );
                drop(state);
                self.inner.changed.notify_waiters();
                return receiver.await.unwrap_or(Err(Error::RuntimeFaulted(
                    "append worker stopped before reporting an outcome".into(),
                )));
            }
            if !wait {
                state.append_rejected = state.append_rejected.saturating_add(1);
                sample(
                    &mut state,
                    &self.inner.config,
                    DiagnosticKind::AppendRejected,
                    "overloaded",
                );
                cleanup_coordinator(&mut state, stream);
                return Err(Error::Overloaded);
            }
            if !registered_waiter {
                if let Err(error) = register_waiter(&mut state, &self.inner.config, bytes) {
                    state.append_rejected = state.append_rejected.saturating_add(1);
                    return Err(error);
                }
                registered_waiter = true;
                waiter_guard = Some(AdmissionWaiterGuard {
                    inner: self.inner.clone(),
                    bytes,
                    coordinator: stream.clone(),
                    active: true,
                });
            }
            drop(state);
            if tokio::time::timeout_at(deadline.into(), notified)
                .await
                .is_err()
            {
                drop(waiter_guard.take());
                let mut state = self.inner.state.lock().await;
                state.append_rejected = state.append_rejected.saturating_add(1);
                return Err(Error::AdmissionTimeout);
            }
        }
    }

    fn validate_cursor(cursor: &Cursor, stream: &StreamKey) -> Result<()> {
        if cursor.version != CURSOR_VERSION {
            return Err(Error::InvalidCursor("unsupported cursor version".into()));
        }
        if cursor.stream != *stream {
            return Err(Error::InvalidCursor(
                "cursor identifies another stream".into(),
            ));
        }
        Ok(())
    }

    fn validate_page(&self, page: PageLimits) -> Result<()> {
        if page.max_records == 0
            || page.max_bytes == 0
            || page.max_records > self.inner.config.max_page_records
            || page.max_bytes > self.inner.config.max_page_bytes
            || page.max_bytes < self.inner.config.max_event_bytes
        {
            return Err(Error::InvalidConfig(
                "page limits exceed runtime budget".into(),
            ));
        }
        Ok(())
    }
}

#[async_trait]
impl<S: EventStore> EventSink for Runtime<S> {
    async fn append(&self, stream: &StreamKey, event: NewEvent) -> Result<AppendReceipt> {
        self.enqueue(stream, event, true).await
    }
}

#[async_trait]
impl<S: EventStore> EventReader for Runtime<S> {
    async fn create_stream(&self, id: &StreamId) -> Result<StreamKey> {
        let store = self.inner.store.clone();
        let id = id.clone();
        tracked_read(self.inner.clone(), 0, async move {
            store.create_if_absent(&id).await
        })
        .await
        .map(|(value, _)| value)
    }

    async fn bounds(&self, stream: &StreamKey) -> Result<Bounds> {
        let store = self.inner.store.clone();
        let stream = stream.clone();
        tracked_read(
            self.inner.clone(),
            0,
            async move { store.bounds(&stream).await },
        )
        .await
        .map(|(value, _)| value)
    }

    async fn read_after(
        &self,
        after: &Cursor,
        limits: PageLimits,
        through: Option<&Cursor>,
    ) -> Result<Page> {
        Self::validate_cursor(after, &after.stream)?;
        self.validate_page(limits)?;
        let bounds = self.bounds(&after.stream).await?;
        if after.offset < bounds.floor.offset {
            return Err(Error::HistoryUnavailable { bounds });
        }
        if after.offset > bounds.tail.offset {
            return Err(Error::CursorAhead { tail: bounds.tail });
        }
        let upper = match through {
            Some(cursor) => {
                Self::validate_cursor(cursor, &after.stream)?;
                if cursor.offset < after.offset {
                    return Err(Error::InvalidCursor("through precedes after".into()));
                }
                if cursor.offset > bounds.tail.offset {
                    return Err(Error::CursorAhead { tail: bounds.tail });
                }
                cursor.offset
            }
            None => bounds.tail.offset,
        };
        let store = self.inner.store.clone();
        let stream = after.stream.clone();
        let after_offset = after.offset;
        let (page, _page_permit) = tracked_read(self.inner.clone(), limits.max_bytes, async move {
            store.read_range(&stream, after_offset, upper, limits).await
        })
        .await?;
        let mut state = self.inner.state.lock().await;
        sample(
            &mut state,
            &self.inner.config,
            DiagnosticKind::ReadPage,
            "history page",
        );
        Ok(page)
    }
}

#[async_trait]
impl<S: EventStore> EventRuntime for Runtime<S> {
    type Subscription = RuntimeSubscription<S>;

    async fn try_append(&self, stream: &StreamKey, event: NewEvent) -> Result<AppendReceipt> {
        self.enqueue(stream, event, false).await
    }

    async fn subscribe(
        &self,
        stream: &StreamKey,
        options: SubscriptionOptions,
    ) -> Result<Self::Subscription> {
        self.validate_page(options.page)?;
        if options.max_lag_records == 0 || options.max_lag_duration.is_zero() {
            return Err(Error::InvalidConfig(
                "subscription lag limits must be nonzero".into(),
            ));
        }
        let coordinator = {
            let mut state = self.inner.state.lock().await;
            ensure_ready(&state)?;
            if state.subscriptions >= self.inner.config.max_subscriptions {
                return Err(Error::Overloaded);
            }
            let coordinator = if let Some(c) = state.coordinators.get(stream).cloned() {
                c
            } else {
                if state.coordinators.len() >= self.inner.config.max_coordinators {
                    return Err(Error::Overloaded);
                }
                let c = Arc::new(Coordinator {
                    key: stream.clone(),
                    write_gate: Arc::new(Mutex::new(())),
                    state: StdMutex::new(CoordinatorState {
                        queue: VecDeque::new(),
                        queued_bytes: 0,
                        scheduled: false,
                        in_flight: 0,
                        observed_floor: 0,
                        observed_tail: 0,
                        generation: 0,
                        subscriptions: Vec::new(),
                        subscription_reservations: 0,
                    }),
                    wake: Notify::new(),
                });
                state.coordinators.insert(stream.clone(), c.clone());
                c
            };
            {
                let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
                cs.subscriptions.retain(|weak| {
                    weak.upgrade().is_some_and(|sub| {
                        sub.state
                            .lock()
                            .expect("subscription lock poisoned")
                            .registered
                    })
                });
                if cs.subscriptions.len() + cs.subscription_reservations
                    >= self.inner.config.max_stream_subscriptions
                {
                    return Err(Error::Overloaded);
                }
                cs.subscription_reservations += 1;
            }
            state.subscriptions += 1;
            coordinator
        };
        let mut reservation = SubscriptionReservationGuard {
            inner: self.inner.clone(),
            coordinator: coordinator.clone(),
            active: true,
        };
        let _gate = coordinator.write_gate.lock().await;
        let store = self.inner.store.clone();
        let bounds_stream = stream.clone();
        let bounds = tracked_read(self.inner.clone(), 0, async move {
            store.bounds(&bounds_stream).await
        })
        .await?
        .0;
        let start = match &options.start {
            StartPosition::Beginning => bounds.floor.clone(),
            StartPosition::Future => bounds.tail.clone(),
            StartPosition::After(cursor) => {
                Self::validate_cursor(cursor, stream)?;
                if cursor.offset < bounds.floor.offset {
                    return Err(Error::HistoryUnavailable { bounds });
                }
                if cursor.offset > bounds.tail.offset {
                    return Err(Error::CursorAhead { tail: bounds.tail });
                }
                cursor.clone()
            }
        };
        let shared = Arc::new(SubscriptionShared {
            state: StdMutex::new(SharedSubscriptionState {
                last_delivered: start.clone(),
                created: Instant::now(),
                behind_since: (bounds.tail.offset > start.offset).then(Instant::now),
                ended: None,
                terminal_delivered: false,
                registered: true,
                buffer: VecDeque::new(),
                page_permit: None,
                max_lag_records: options.max_lag_records,
                max_lag_duration: options.max_lag_duration,
                catch_up_grace: options.catch_up_grace,
            }),
        });
        {
            let state = self.inner.state.lock().await;
            ensure_ready(&state)?;
            let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
            cs.subscription_reservations -= 1;
            cs.observed_floor = bounds.floor.offset;
            cs.observed_tail = cs.observed_tail.max(bounds.tail.offset);
            cs.subscriptions.push(Arc::downgrade(&shared));
            reservation.disarm();
        }
        drop(_gate);
        Ok(RuntimeSubscription {
            inner: self.inner.clone(),
            coordinator,
            shared,
            last_delivered: start,
            replay_high: bounds.tail.offset,
            options,
        })
    }

    async fn shutdown(&self, deadline: Duration) -> Result<ShutdownReport> {
        {
            let mut state = self.inner.state.lock().await;
            match state.lifecycle {
                RuntimeLifecycle::Closed => {
                    return Ok(ShutdownReport {
                        closed: true,
                        unresolved: Vec::new(),
                    })
                }
                RuntimeLifecycle::Faulted | RuntimeLifecycle::Ready => {
                    state.lifecycle = RuntimeLifecycle::Draining
                }
                RuntimeLifecycle::Draining => {}
            }
            end_all_subscriptions(&mut state, Error::Closed);
            sample(
                &mut state,
                &self.inner.config,
                DiagnosticKind::Shutdown,
                "draining",
            );
        }
        self.inner.changed.notify_waiters();
        // This task owns close even if the caller drops or times out shutdown.
        spawn_finalizer(self.inner.clone());
        let until = Instant::now() + deadline;
        loop {
            let notified = self.inner.changed.notified();
            {
                let state = self.inner.state.lock().await;
                if state.lifecycle == RuntimeLifecycle::Closed {
                    return Ok(ShutdownReport {
                        closed: true,
                        unresolved: unresolved_appends(&state),
                    });
                }
                if state.lifecycle == RuntimeLifecycle::Faulted && state.close_started {
                    return Err(Error::RuntimeFaulted(
                        state
                            .fault
                            .clone()
                            .unwrap_or_else(|| "store close failed".into()),
                    ));
                }
            }
            if tokio::time::timeout_at(until.into(), notified)
                .await
                .is_err()
            {
                let state = self.inner.state.lock().await;
                let report = ShutdownReport {
                    closed: false,
                    unresolved: unresolved_appends(&state),
                };
                drop(state);
                return Ok(report);
            }
        }
    }
}

#[async_trait]
impl<S: EventStore> EventSubscription for RuntimeSubscription<S> {
    async fn next(&mut self) -> Option<Result<Arc<Record>>> {
        loop {
            {
                let mut shared = self
                    .shared
                    .state
                    .lock()
                    .expect("subscription lock poisoned");
                if let Some(error) = shared.ended.clone() {
                    release_subscription_page(&mut shared);
                    if !shared.terminal_delivered {
                        shared.terminal_delivered = true;
                        return Some(Err(error));
                    }
                    return None;
                }
                if let Some(record) = shared.buffer.pop_front() {
                    self.last_delivered = record.cursor.clone();
                    shared.last_delivered = record.cursor.clone();
                    if shared.buffer.is_empty() {
                        release_subscription_page(&mut shared);
                    }
                    return Some(Ok(record));
                }
            }
            if let Some(error) = lag_error(
                &self.shared,
                &self.options,
                self.coordinator_observed_bounds(),
            ) {
                self.end(error);
                continue;
            }
            let generation_before = self
                .coordinator
                .state
                .lock()
                .expect("coordinator lock poisoned")
                .generation;
            let store = self.inner.store.clone();
            let stream = self.coordinator.key.clone();
            let mut bounds_call = Box::pin(tracked_read(self.inner.clone(), 0, async move {
                store.bounds(&stream).await
            }));
            let mut wake_observed = false;
            let bounds_result = loop {
                let wake = self.coordinator.wake.notified();
                tokio::pin!(wake);
                wake.as_mut().enable();
                tokio::select! {
                    result = &mut bounds_call => break result.map(|(bounds, _)| bounds),
                    _ = &mut wake => {
                        if subscription_ended(&self.shared) { break Err(Error::Closed); }
                        wake_observed = true;
                    }
                }
            };
            let bounds = match bounds_result {
                Ok(bounds) => bounds,
                Err(error) => {
                    if !subscription_ended(&self.shared) {
                        self.end(error);
                    }
                    continue;
                }
            };
            let through = if self.last_delivered.offset < self.replay_high {
                self.replay_high
            } else {
                bounds.tail.offset
            };
            if through > self.last_delivered.offset {
                let store = self.inner.store.clone();
                let stream = self.coordinator.key.clone();
                let after = self.last_delivered.offset;
                let limits = self.options.page;
                let mut page_call = Box::pin(tracked_read(
                    self.inner.clone(),
                    limits.max_bytes,
                    async move { store.read_range(&stream, after, through, limits).await },
                ));
                let page_result = loop {
                    tokio::select! {
                        result = &mut page_call => break result,
                        _ = self.coordinator.wake.notified() => {
                            if subscription_ended(&self.shared) { break Err(Error::Closed); }
                        }
                    }
                };
                match page_result {
                    Ok((page, _)) if page.records.is_empty() => {
                        self.end(Error::StoreCorrupt(
                            "empty subscription page below requested through cursor".into(),
                        ));
                    }
                    Ok((page, permit)) => {
                        let mut shared = self
                            .shared
                            .state
                            .lock()
                            .expect("subscription lock poisoned");
                        if shared.ended.is_none() {
                            shared.buffer = page.records.into();
                            if !shared.buffer.is_empty() {
                                shared.page_permit = permit;
                            }
                        }
                    }
                    Err(error) => self.end(error),
                }
                continue;
            }
            if wake_observed {
                continue;
            }
            // Register before the final generation check. A commit either changes
            // generation or wakes this enabled waiter, so the transition to sleep
            // cannot lose a notification.
            let notified = self.coordinator.wake.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            let generation_now = self
                .coordinator
                .state
                .lock()
                .expect("coordinator lock poisoned")
                .generation;
            if generation_now != generation_before || subscription_ended(&self.shared) {
                continue;
            }
            notified.await;
        }
    }

    fn last_delivered(&self) -> &Cursor {
        &self.last_delivered
    }
}

impl<S: EventStore> RuntimeSubscription<S> {
    fn end(&self, error: Error) {
        if end_subscription(&self.shared, error) {
            schedule_subscription_deregistration(self.inner.clone(), self.coordinator.key.clone());
        }
    }

    fn coordinator_observed_bounds(&self) -> Bounds {
        let cs = self
            .coordinator
            .state
            .lock()
            .expect("coordinator lock poisoned");
        Bounds {
            floor: Cursor::new(self.coordinator.key.clone(), cs.observed_floor),
            tail: Cursor::new(self.coordinator.key.clone(), cs.observed_tail),
        }
    }
}

impl<S: EventStore> Drop for RuntimeSubscription<S> {
    fn drop(&mut self) {
        let was_registered = {
            let mut shared = self
                .shared
                .state
                .lock()
                .expect("subscription lock poisoned");
            release_subscription_page(&mut shared);
            std::mem::replace(&mut shared.registered, false)
        };
        if was_registered {
            schedule_subscription_deregistration(self.inner.clone(), self.coordinator.key.clone());
        }
    }
}

async fn tracked_read<S, T, F>(
    inner: Arc<Inner<S>>,
    page_bytes: usize,
    operation: F,
) -> Result<(T, Option<OwnedSemaphorePermit>)>
where
    S: EventStore,
    T: Send + 'static,
    F: Future<Output = Result<T>> + Send + 'static,
{
    let waiter = inner
        .read_waiters
        .clone()
        .try_acquire_owned()
        .map_err(|_| Error::Overloaded)?;
    let until = Instant::now() + inner.config.read_admission_timeout;
    let (read_permit, page_permit) = tokio::time::timeout_at(until.into(), async {
        {
            let state = inner.state.lock().await;
            ensure_ready(&state)?;
        }
        // Page reads acquire resources in one order and retain each acquired
        // permit. Keeping the same queued acquire future across lifecycle wakes
        // preserves semaphore fairness instead of handing a permit to the next
        // waiter and racing to reacquire it.
        let page_permit = if page_bytes == 0 {
            None
        } else {
            let page = inner
                .page_bytes
                .clone()
                .acquire_many_owned(page_bytes as u32);
            tokio::pin!(page);
            Some(loop {
                let changed = inner.changed.notified();
                tokio::pin!(changed);
                match tokio::select! {
                    permit = &mut page => Some(permit.map_err(|_| Error::Closed)?),
                    _ = &mut changed => None,
                } {
                    Some(permit) => break permit,
                    None => {
                        let state = inner.state.lock().await;
                        ensure_ready(&state)?;
                    }
                }
            })
        };
        let read = inner.read_slots.clone().acquire_owned();
        tokio::pin!(read);
        let read_permit = loop {
            let changed = inner.changed.notified();
            tokio::pin!(changed);
            match tokio::select! {
                permit = &mut read => Some(permit.map_err(|_| Error::Closed)?),
                _ = &mut changed => None,
            } {
                Some(permit) => break permit,
                None => {
                    let state = inner.state.lock().await;
                    ensure_ready(&state)?;
                }
            }
        };
        Ok::<_, Error>((read_permit, page_permit))
    })
    .await
    .map_err(|_| Error::AdmissionTimeout)??;
    {
        let mut state = inner.state.lock().await;
        ensure_ready(&state)?;
        state.active_io += 1;
    }
    drop(waiter);
    let (sender, receiver) = oneshot::channel();
    let completion_inner = inner.clone();
    tokio::spawn(async move {
        let result = match tokio::spawn(operation).await {
            Ok(result) => result,
            Err(join) => Err(Error::RuntimeFaulted(format!(
                "store read task failed: {join}"
            ))),
        };
        drop(read_permit);
        let mut state = completion_inner.state.lock().await;
        state.active_io = state.active_io.saturating_sub(1);
        if let Err(
            error @ (Error::OwnershipLost | Error::StoreCorrupt(_) | Error::RuntimeFaulted(_)),
        ) = &result
        {
            let detail = error.to_string();
            state.fault.get_or_insert(detail);
            if state.lifecycle == RuntimeLifecycle::Ready {
                state.lifecycle = RuntimeLifecycle::Faulted;
            }
            end_all_subscriptions(
                &mut state,
                Error::RuntimeFaulted("store can no longer continue safely".into()),
            );
        }
        drop(state);
        completion_inner.changed.notify_waiters();
        let result = result.map(|value| (value, page_permit));
        let _ = sender.send(result);
    });
    receiver.await.unwrap_or_else(|_| {
        Err(Error::RuntimeFaulted(
            "tracked storage operation stopped without an outcome".into(),
        ))
    })
}

async fn worker<S: EventStore>(inner: Arc<Inner<S>>) {
    loop {
        let notified = inner.changed.notified();
        let coordinator = {
            let mut state = inner.state.lock().await;
            match state.ready.pop_front() {
                Some(key) => state.coordinators.get(&key).cloned(),
                None if matches!(state.lifecycle, RuntimeLifecycle::Closed) => return,
                None => None,
            }
        };
        let Some(coordinator) = coordinator else {
            notified.await;
            continue;
        };
        for _ in 0..inner.config.work_per_stream_turn {
            let pending = {
                let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
                let pending = cs.queue.pop_front();
                if pending.is_some() {
                    cs.in_flight += 1;
                }
                pending
            };
            let Some(pending) = pending else {
                break;
            };
            let prior_fault = {
                let mut state = inner.state.lock().await;
                state.active_io += 1;
                state
                    .fault
                    .as_ref()
                    .map(|fault| Error::RuntimeFaulted(fault.clone()))
            };
            let result = if let Some(error) = prior_fault {
                Err(error)
            } else {
                let gate = coordinator.write_gate.clone().lock_owned().await;
                let store = inner.store.clone();
                let stream = coordinator.key.clone();
                let event = pending.event.clone();
                match tokio::spawn(async move {
                    let _gate = gate;
                    store.append_atomic(&stream, event).await
                })
                .await
                {
                    Ok(result) => result,
                    Err(join) => Err(Error::RuntimeFaulted(format!(
                        "store append task failed: {join}"
                    ))),
                }
            };
            let mut resolved_record = None;
            let final_result = if matches!(result, Err(Error::CommitUnknown { .. })) {
                let store = inner.store.clone();
                let stream = coordinator.key.clone();
                let event_id = pending.event.id.clone();
                let lookup =
                    tokio::spawn(async move { store.lookup_event(&stream, &event_id).await }).await;
                match lookup {
                    Ok(Ok(Some(record))) if record.event == pending.event => {
                        resolved_record = Some(record);
                        result
                    }
                    Ok(Ok(Some(_))) => Err(Error::IdempotencyConflict {
                        event_id: pending.event.id.clone(),
                    }),
                    Ok(Ok(None) | Err(_)) | Err(_) => result,
                }
            } else {
                result
            };
            {
                let mut state = inner.state.lock().await;
                state.active_io -= 1;
                state.queued_count -= 1;
                state.queued_bytes -= pending.bytes;
                let committed = {
                    let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
                    cs.in_flight -= 1;
                    cs.queued_bytes -= pending.bytes;
                    let committed = match &final_result {
                        Ok(receipt) if receipt.kind == AppendKind::Inserted => {
                            Some(receipt.record.clone())
                        }
                        _ => resolved_record,
                    };
                    if let Some(ref record) = committed {
                        cs.observed_tail = cs.observed_tail.max(record.cursor.offset);
                        cs.generation = cs.generation.wrapping_add(1);
                        for weak in &cs.subscriptions {
                            if let Some(sub) = weak.upgrade() {
                                let mut ss = sub.state.lock().expect("subscription lock poisoned");
                                if ss.last_delivered.offset < cs.observed_tail
                                    && ss.behind_since.is_none()
                                {
                                    ss.behind_since = Some(Instant::now());
                                }
                            }
                        }
                        coordinator.wake.notify_waiters();
                    }
                    committed
                };
                if !matches!(final_result, Err(Error::CommitUnknown { .. })) || committed.is_some()
                {
                    let unresolved_key = (coordinator.key.clone(), pending.event.id.clone());
                    if let Some(count) = state.unresolved.get_mut(&unresolved_key) {
                        *count -= 1;
                        if *count == 0 {
                            state.unresolved.remove(&unresolved_key);
                        }
                    }
                } else {
                    state.lifecycle = RuntimeLifecycle::Faulted;
                    state.fault = Some("an uncertain commit could not be resolved".into());
                    sample(
                        &mut state,
                        &inner.config,
                        DiagnosticKind::RuntimeFaulted,
                        "commit unknown",
                    );
                    end_all_subscriptions(
                        &mut state,
                        Error::RuntimeFaulted("an uncertain commit could not be resolved".into()),
                    );
                }
                if matches!(
                    final_result,
                    Err(Error::OwnershipLost | Error::StoreCorrupt(_) | Error::RuntimeFaulted(_))
                ) {
                    state.lifecycle = RuntimeLifecycle::Faulted;
                    state.fault = Some(final_result.as_ref().unwrap_err().to_string());
                    sample(
                        &mut state,
                        &inner.config,
                        DiagnosticKind::RuntimeFaulted,
                        "store fault",
                    );
                    end_all_subscriptions(
                        &mut state,
                        Error::RuntimeFaulted("store can no longer continue safely".into()),
                    );
                }
                match &final_result {
                    Ok(r) if r.kind == AppendKind::Inserted => {
                        state.append_inserted = state.append_inserted.saturating_add(1);
                        sample(
                            &mut state,
                            &inner.config,
                            DiagnosticKind::AppendInserted,
                            "inserted",
                        );
                    }
                    Ok(_) => {
                        state.append_deduplicated = state.append_deduplicated.saturating_add(1);
                        sample(
                            &mut state,
                            &inner.config,
                            DiagnosticKind::AppendDeduplicated,
                            "deduplicated",
                        );
                    }
                    Err(_) => {
                        state.append_failed = state.append_failed.saturating_add(1);
                        sample(
                            &mut state,
                            &inner.config,
                            DiagnosticKind::AppendRejected,
                            "append failed",
                        );
                    }
                }
            }
            let _ = pending.result.send(final_result);
            inner.changed.notify_waiters();
        }
        let mut state = inner.state.lock().await;
        let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
        if !cs.queue.is_empty() {
            state.ready.push_back(coordinator.key.clone());
        } else {
            cs.scheduled = false;
        }
        drop(cs);
        cleanup_coordinator(&mut state, &coordinator.key);
        drop(state);
        inner.changed.notify_waiters();
    }
}

async fn subscription_sweeper<S: EventStore>(inner: Weak<Inner<S>>) {
    let Some(first) = inner.upgrade() else {
        return;
    };
    let interval = first.config.subscriber_sweep_interval;
    drop(first);
    let mut cursor = 0usize;
    loop {
        tokio::time::sleep(interval).await;
        let Some(inner) = inner.upgrade() else {
            return;
        };
        let coordinators: Vec<_> = {
            let state = inner.state.lock().await;
            if state.lifecycle == RuntimeLifecycle::Closed {
                return;
            }
            state.coordinators.values().cloned().collect()
        };
        if coordinators.is_empty() {
            continue;
        }
        let mut remaining = inner.config.subscribers_per_sweep;
        let mut checked_coordinators = 0usize;
        while remaining > 0 && checked_coordinators < coordinators.len() {
            let coordinator = &coordinators[cursor % coordinators.len()];
            cursor = cursor.wrapping_add(1);
            checked_coordinators += 1;
            let (floor, tail, subscriptions) = {
                let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
                cs.subscriptions.retain(|weak| {
                    weak.upgrade().is_some_and(|sub| {
                        sub.state
                            .lock()
                            .expect("subscription lock poisoned")
                            .registered
                    })
                });
                let take = remaining.min(cs.subscriptions.len());
                let subscriptions = cs
                    .subscriptions
                    .iter()
                    .take(take)
                    .filter_map(Weak::upgrade)
                    .collect::<Vec<_>>();
                if !cs.subscriptions.is_empty() {
                    cs.subscriptions.rotate_left(take);
                }
                remaining -= take;
                (cs.observed_floor, cs.observed_tail, subscriptions)
            };
            let mut expired = 0usize;
            for subscription in subscriptions {
                let mut ss = subscription
                    .state
                    .lock()
                    .expect("subscription lock poisoned");
                if tail == ss.last_delivered.offset {
                    ss.behind_since = None;
                } else if ss.behind_since.is_none() {
                    ss.behind_since = Some(Instant::now());
                }
                let now = Instant::now();
                let behind = tail.saturating_sub(ss.last_delivered.offset);
                let lag_duration = ss
                    .behind_since
                    .map_or(Duration::ZERO, |since| now.duration_since(since));
                if ss.ended.is_none()
                    && now.duration_since(ss.created) >= ss.catch_up_grace
                    && (behind > ss.max_lag_records || lag_duration > ss.max_lag_duration)
                {
                    let bounds = Bounds {
                        floor: Cursor::new(coordinator.key.clone(), floor),
                        tail: Cursor::new(coordinator.key.clone(), tail),
                    };
                    ss.ended = Some(Error::SubscriberLagged {
                        last_delivered: ss.last_delivered.clone(),
                        bounds: Box::new(bounds),
                    });
                    release_subscription_page(&mut ss);
                    if std::mem::replace(&mut ss.registered, false) {
                        expired += 1;
                    }
                    coordinator.wake.notify_waiters();
                }
            }
            if expired > 0 {
                let mut state = inner.state.lock().await;
                state.subscriptions = state.subscriptions.saturating_sub(expired);
                sample(
                    &mut state,
                    &inner.config,
                    DiagnosticKind::SubscriberEnded,
                    "lagged",
                );
                cleanup_coordinator(&mut state, &coordinator.key);
            }
        }
    }
}

fn lag_error(
    shared: &SubscriptionShared,
    options: &SubscriptionOptions,
    bounds: Bounds,
) -> Option<Error> {
    let now = Instant::now();
    let mut ss = shared.state.lock().expect("subscription lock poisoned");
    if bounds.tail.offset <= ss.last_delivered.offset {
        ss.behind_since = None;
        return None;
    }
    let behind = bounds.tail.offset - ss.last_delivered.offset;
    let since = *ss.behind_since.get_or_insert(now);
    if now.duration_since(ss.created) >= options.catch_up_grace
        && (behind > options.max_lag_records
            || now.duration_since(since) > options.max_lag_duration)
    {
        Some(Error::SubscriberLagged {
            last_delivered: ss.last_delivered.clone(),
            bounds: Box::new(bounds),
        })
    } else {
        None
    }
}

fn end_subscription(shared: &SubscriptionShared, error: Error) -> bool {
    let mut ss = shared.state.lock().expect("subscription lock poisoned");
    if ss.ended.is_none() {
        ss.ended = Some(error);
    }
    release_subscription_page(&mut ss);
    std::mem::replace(&mut ss.registered, false)
}

fn schedule_subscription_deregistration<S: EventStore>(inner: Arc<Inner<S>>, key: StreamKey) {
    let executor = inner.executor.clone();
    executor.spawn(async move {
        let mut state = inner.state.lock().await;
        state.subscriptions = state.subscriptions.saturating_sub(1);
        cleanup_coordinator(&mut state, &key);
        inner.changed.notify_waiters();
    });
}

fn release_subscription_page(state: &mut SharedSubscriptionState) {
    state.buffer = VecDeque::new();
    state.page_permit.take();
}

fn subscription_ended(shared: &SubscriptionShared) -> bool {
    shared
        .state
        .lock()
        .expect("subscription lock poisoned")
        .ended
        .is_some()
}

fn register_waiter(state: &mut State, config: &RuntimeConfig, bytes: usize) -> Result<()> {
    if state.waiter_count >= config.max_admission_waiters
        || state
            .waiter_bytes
            .checked_add(bytes)
            .is_none_or(|n| n > config.max_admission_waiter_bytes)
    {
        return Err(Error::Overloaded);
    }
    state.waiter_count += 1;
    state.waiter_bytes += bytes;
    Ok(())
}

fn ensure_ready(state: &State) -> Result<()> {
    match state.lifecycle {
        RuntimeLifecycle::Ready => Ok(()),
        RuntimeLifecycle::Faulted => Err(Error::RuntimeFaulted(
            state
                .fault
                .clone()
                .unwrap_or_else(|| "runtime faulted".into()),
        )),
        RuntimeLifecycle::Draining | RuntimeLifecycle::Closed => Err(Error::Closed),
    }
}

fn cleanup_coordinator(state: &mut State, key: &StreamKey) {
    let remove = state.coordinators.get(key).is_some_and(|coordinator| {
        let mut cs = coordinator.state.lock().expect("coordinator lock poisoned");
        cs.subscriptions.retain(|weak| {
            weak.upgrade().is_some_and(|sub| {
                sub.state
                    .lock()
                    .expect("subscription lock poisoned")
                    .registered
            })
        });
        cs.queue.is_empty()
            && cs.in_flight == 0
            && cs.subscriptions.is_empty()
            && cs.subscription_reservations == 0
            && !cs.scheduled
    });
    if remove {
        state.coordinators.remove(key);
    }
}

fn end_all_subscriptions(state: &mut State, error: Error) {
    let mut ended = 0usize;
    for coordinator in state.coordinators.values() {
        let cs = coordinator.state.lock().expect("coordinator lock poisoned");
        for weak in &cs.subscriptions {
            if let Some(subscription) = weak.upgrade() {
                let mut ss = subscription
                    .state
                    .lock()
                    .expect("subscription lock poisoned");
                if ss.ended.is_none() {
                    ss.ended = Some(error.clone());
                }
                release_subscription_page(&mut ss);
                if std::mem::replace(&mut ss.registered, false) {
                    ended += 1;
                }
            }
        }
        coordinator.wake.notify_waiters();
    }
    state.subscriptions = state.subscriptions.saturating_sub(ended);
}

fn sample(state: &mut State, config: &RuntimeConfig, kind: DiagnosticKind, detail: &'static str) {
    if state.samples.len() == config.diagnostic_capacity {
        state.samples.pop_front();
    }
    state.samples.push_back(DiagnosticSample { kind, detail });
}

fn unresolved_appends(state: &State) -> Vec<UnresolvedAppend> {
    state
        .unresolved
        .keys()
        .map(|(stream, event_id)| UnresolvedAppend {
            stream: stream.clone(),
            event_id: event_id.clone(),
        })
        .collect()
}

fn spawn_finalizer<S: EventStore>(inner: Arc<Inner<S>>) {
    let executor = inner.executor.clone();
    executor.spawn(async move {
        loop {
            let notified = inner.changed.notified();
            let should_close = {
                let mut state = inner.state.lock().await;
                if state.lifecycle == RuntimeLifecycle::Closed || state.close_started {
                    return;
                }
                if state.queued_count == 0 && state.active_io == 0 {
                    state.close_started = true;
                    true
                } else {
                    false
                }
            };
            if should_close {
                let store = inner.store.clone();
                let result = match tokio::spawn(async move { store.close().await }).await {
                    Ok(result) => result,
                    Err(join) => Err(Error::RuntimeFaulted(format!(
                        "store close task failed: {join}"
                    ))),
                };
                let mut state = inner.state.lock().await;
                if result.is_ok() {
                    state.lifecycle = RuntimeLifecycle::Closed;
                } else {
                    state.lifecycle = RuntimeLifecycle::Faulted;
                    state.fault = result.err().map(|e| e.to_string());
                }
                inner.changed.notify_waiters();
                return;
            }
            notified.await;
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::infrastructure::{MemoryStore, MemoryStoreOptions};

    fn test_event(id: &str) -> NewEvent {
        NewEvent {
            id: EventId::new(id).unwrap(),
            schema: SchemaRef {
                id: SchemaId::new("test.bytes").unwrap(),
                version: 1,
            },
            payload: Payload::copy_from_slice(b"one"),
        }
    }

    fn test_subscription(start: StartPosition, page: PageLimits) -> SubscriptionOptions {
        SubscriptionOptions {
            start,
            page,
            max_lag_records: 100,
            max_lag_duration: Duration::from_secs(1),
            catch_up_grace: Duration::ZERO,
        }
    }

    #[tokio::test]
    async fn draining_last_record_releases_page_capacity_and_allocation() {
        let config = RuntimeConfig {
            max_event_bytes: 1024,
            max_page_records: 4,
            max_page_bytes: 4096,
            max_buffered_page_bytes: 4096,
            ..RuntimeConfig::default()
        };
        let runtime = Runtime::<MemoryStore>::open(MemoryStoreOptions::default(), config.clone())
            .await
            .unwrap();
        let key = runtime
            .create_stream(&StreamId::new("drained-page").unwrap())
            .await
            .unwrap();
        for number in 0..4 {
            runtime
                .append(&key, test_event(&format!("event-{number}")))
                .await
                .unwrap();
        }
        let mut subscription = runtime
            .subscribe(
                &key,
                test_subscription(
                    StartPosition::Beginning,
                    PageLimits {
                        max_records: 4,
                        max_bytes: 4096,
                    },
                ),
            )
            .await
            .unwrap();

        for _ in 0..3 {
            subscription.next().await.unwrap().unwrap();
        }
        {
            let state = subscription.shared.state.lock().unwrap();
            assert_eq!(state.buffer.len(), 1);
            assert!(state.buffer.capacity() > 0);
            assert!(state.page_permit.is_some());
        }
        assert_eq!(runtime.inner.page_bytes.available_permits(), 0);

        subscription.next().await.unwrap().unwrap();
        let state = subscription.shared.state.lock().unwrap();
        assert!(state.buffer.is_empty());
        assert_eq!(state.buffer.capacity(), 0);
        assert!(state.page_permit.is_none());
        assert_eq!(
            runtime.inner.page_bytes.available_permits(),
            config.max_buffered_page_bytes
        );
    }

    #[derive(Clone)]
    struct CompleteEmptyOptions {
        reads: Arc<AtomicUsize>,
    }

    struct CompleteEmptyStore {
        key: StreamKey,
        reads: Arc<AtomicUsize>,
    }

    #[async_trait]
    impl EventStore for CompleteEmptyStore {
        type Options = CompleteEmptyOptions;

        async fn open(options: Self::Options) -> Result<Self> {
            Ok(Self {
                key: StreamKey {
                    id: StreamId::new("complete-empty").unwrap(),
                    incarnation: IncarnationId([9; 16]),
                },
                reads: options.reads,
            })
        }

        fn capabilities(&self) -> StoreCapabilities {
            StoreCapabilities {
                persistence: PersistenceProfile::Ephemeral,
                format_version: 1,
                max_record_bytes: 1024 * 1024,
                max_concurrent_reads: 1,
                max_concurrent_writes: 1,
                ownership: "complete-empty test store",
            }
        }

        async fn create_if_absent(&self, id: &StreamId) -> Result<StreamKey> {
            if id == &self.key.id {
                Ok(self.key.clone())
            } else {
                Err(Error::StreamNotFound)
            }
        }

        async fn append_atomic(&self, _: &StreamKey, _: NewEvent) -> Result<AppendReceipt> {
            Err(Error::StoreWriteFailed("read-only test store".into()))
        }

        async fn lookup_event(&self, _: &StreamKey, _: &EventId) -> Result<Option<Arc<Record>>> {
            Ok(None)
        }

        async fn bounds(&self, _: &StreamKey) -> Result<Bounds> {
            Ok(Bounds {
                floor: Cursor::new(self.key.clone(), 0),
                tail: Cursor::new(self.key.clone(), 1),
            })
        }

        async fn read_range(
            &self,
            _: &StreamKey,
            after: u64,
            through: u64,
            _: PageLimits,
        ) -> Result<Page> {
            self.reads.fetch_add(1, Ordering::Relaxed);
            let records = Vec::with_capacity(256);
            Ok(Page {
                records,
                next_after: Cursor::new(self.key.clone(), after),
                through: Cursor::new(self.key.clone(), through),
                complete: true,
            })
        }

        async fn close(&self) -> Result<()> {
            Ok(())
        }
    }

    #[tokio::test]
    async fn complete_empty_page_is_terminal_and_releases_subscription_quota() {
        let reads = Arc::new(AtomicUsize::new(0));
        let config = RuntimeConfig {
            max_event_bytes: 1024,
            max_subscriptions: 1,
            max_stream_subscriptions: 1,
            max_page_bytes: 4096,
            max_buffered_page_bytes: 4096,
            ..RuntimeConfig::default()
        };
        let runtime = Runtime::<CompleteEmptyStore>::open(
            CompleteEmptyOptions {
                reads: reads.clone(),
            },
            config.clone(),
        )
        .await
        .unwrap();
        let key = runtime
            .create_stream(&StreamId::new("complete-empty").unwrap())
            .await
            .unwrap();
        let options = test_subscription(
            StartPosition::Beginning,
            PageLimits {
                max_records: 4,
                max_bytes: 4096,
            },
        );
        let mut first = runtime.subscribe(&key, options.clone()).await.unwrap();

        let error = tokio::time::timeout(Duration::from_millis(250), first.next())
            .await
            .expect("empty page must not cause a retry loop")
            .unwrap()
            .unwrap_err();
        assert!(
            matches!(error, Error::StoreCorrupt(message) if message.contains("empty subscription page"))
        );
        assert!(first.next().await.is_none());
        assert_eq!(reads.load(Ordering::Relaxed), 1);
        {
            let state = first.shared.state.lock().unwrap();
            assert!(!state.registered);
            assert_eq!(state.buffer.capacity(), 0);
            assert!(state.page_permit.is_none());
        }
        assert_eq!(
            runtime.inner.page_bytes.available_permits(),
            config.max_buffered_page_bytes
        );

        let second = tokio::time::timeout(Duration::from_secs(1), async {
            loop {
                match runtime.subscribe(&key, options.clone()).await {
                    Ok(subscription) => break subscription,
                    Err(Error::Overloaded) => tokio::task::yield_now().await,
                    Err(error) => panic!("unexpected second subscription error: {error}"),
                }
            }
        })
        .await
        .expect("terminal subscription must release its admission slot");
        assert_eq!(reads.load(Ordering::Relaxed), 1);
        drop(second);
        drop(first);
    }

    #[tokio::test]
    async fn ending_subscription_releases_page_capacity_and_allocation() {
        let page_bytes = Arc::new(Semaphore::new(32));
        let permit = page_bytes.clone().acquire_many_owned(16).await.unwrap();
        let stream = StreamKey {
            id: StreamId::new("terminal-capacity").unwrap(),
            incarnation: IncarnationId([1; 16]),
        };
        let mut buffer = VecDeque::with_capacity(32);
        buffer.push_back(Arc::new(Record {
            cursor: Cursor::new(stream.clone(), 1),
            event: NewEvent {
                id: EventId::new("one").unwrap(),
                schema: SchemaRef {
                    id: SchemaId::new("test.bytes").unwrap(),
                    version: 1,
                },
                payload: Payload::copy_from_slice(b"one"),
            },
        }));
        let shared = SubscriptionShared {
            state: StdMutex::new(SharedSubscriptionState {
                last_delivered: Cursor::new(stream, 0),
                created: Instant::now(),
                behind_since: None,
                ended: None,
                terminal_delivered: false,
                registered: true,
                buffer,
                page_permit: Some(permit),
                max_lag_records: 1,
                max_lag_duration: Duration::from_secs(1),
                catch_up_grace: Duration::ZERO,
            }),
        };

        assert!(end_subscription(&shared, Error::Closed));

        let state = shared.state.lock().unwrap();
        assert_eq!(state.buffer.capacity(), 0);
        assert!(state.page_permit.is_none());
        assert!(!state.registered);
        assert!(matches!(state.ended, Some(Error::Closed)));
        assert_eq!(page_bytes.available_permits(), 32);
    }
}
